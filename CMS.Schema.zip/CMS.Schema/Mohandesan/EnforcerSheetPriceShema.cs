﻿using System;
using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
   public  class EnforcerSheetPriceViewModel
    {
        public List<Fields> fields  { get; set; }
        

        public List<SheetMetterShcema> sheetMetters { get; set; }
        public List<SheetPriceSchema> prices { get; set; }
        public List<SheetPriceSchema> Design { get; set; }


    }
}
