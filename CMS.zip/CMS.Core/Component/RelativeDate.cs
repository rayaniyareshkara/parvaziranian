﻿using System;

namespace CMS.Core.Component
{
    public static class RelativeDate
    {
        public static string GetRelativeDate(this DateTime yourDate)
        {
            const int SECOND = 1;
            const int MINUTE = 60 * SECOND;
            const int HOUR = 60 * MINUTE;
            const int DAY = 24 * HOUR;
            const int MONTH = 30 * DAY;

            var ts = new TimeSpan(DateTime.UtcNow.Ticks - yourDate.Ticks);
            double delta = Math.Abs(ts.TotalSeconds);

            if (delta < 1 * MINUTE)
                return ts.Seconds == 1 ? "همین الان" : ts.Seconds + " همین الان";

            if (delta < 2 * MINUTE)
                return "یک دقیقه پیش";

            if (delta < 45 * MINUTE)
                return ts.Minutes + " دقیقه پیش";

            if (delta < 90 * MINUTE)
                return "یک ساعت پیش";

            if (delta < 24 * HOUR)
                return ts.Hours + " ساعت پیش ";

            if (delta < 48 * HOUR)
                return "دیروز";

            if (delta < 30 * DAY)
                return ts.Days + " روز پیش";

            if (delta < 12 * MONTH)
            {
                int months = Convert.ToInt32(Math.Floor((double)ts.Days / 30));
                return months <= 1 ? "یک ماه پیش" : months + " ماه پیش ";
            }
            else
            {
                int years = Convert.ToInt32(Math.Floor((double)ts.Days / 365));
                return years <= 1 ? "یک سال پیش" : years + " سال پیش";
            }
        }

        public static string GetRelativeDateNew(this DateTime yourDate)
        {
            const int SECOND = 1;
            const int MINUTE = 60 * SECOND;
            const int HOUR = 60 * MINUTE;
            const int DAY = 24 * HOUR;
            const int MONTH = 30 * DAY;

            var ts = new TimeSpan(yourDate.Ticks - DateTime.UtcNow.Ticks);
            var delta = Math.Abs(ts.TotalSeconds);

            if (delta < 1 * MINUTE)
                return ts.Seconds == 1 ? "همین الان" : ts.Seconds + " همین الان";

            if (delta < 2 * MINUTE)
                return "یک دقیقه بعد";

            if (delta < 45 * MINUTE)
                return ts.Minutes + " دقیقه بعد";

            if (delta < 90 * MINUTE)
                return "یک ساعت پیش";

            if (delta < 24 * HOUR)
                return ts.Hours + " ساعت بعد ";

            if (delta < 48 * HOUR)
                return "دیروز";

            if (delta < 30 * DAY)
                return ts.Days + " روز بعد";

            if (delta < 12 * MONTH)
            {
                int months = Convert.ToInt32(Math.Floor((double)ts.Days / 30));
                return months <= 1 ? "یک ماه بعد" : months + " ماه بعد ";
            }
            else
            {
                int years = Convert.ToInt32(Math.Floor((double)ts.Days / 365));
                return years <= 1 ? "یک سال بعد" : years + " سال بعد";
            }
        }

    }
}
