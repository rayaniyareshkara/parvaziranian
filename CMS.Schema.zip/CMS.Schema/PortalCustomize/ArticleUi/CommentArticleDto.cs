﻿using System;

namespace CMS.Schema.PortalCustomize.ArticleUi
{
    public class CommentArticleDto
    {
        public int ArticleId { get; set; }

        public int Id { get; set; }

        public int? ParentId { get; set; }

        public string Comment { get; set; }

        public DateTime CreationTime { get; set; }
    }
}
