﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class QuizAnswerSchema
    {
        public int QuizId { get; set; }
        public List<QAnswer> MyAnswer { get; set; }
    }
    public class QAnswer { 
        public string Answer { get; set; }
        public int Id { get; set; }
       
    }
}
