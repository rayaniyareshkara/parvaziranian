﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
 public   class DetailResultSchema
    {
        public string CourseName { get; set; }
        public int Max { get; set; }
        public int Score { get; set; }

    }
}
