﻿
namespace CMS.Schema.Hotel
{
   public  class HotelInfoReservationSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public int TotalDay { get; set; }
        public int PersonCount { get; set; }
    }
}
