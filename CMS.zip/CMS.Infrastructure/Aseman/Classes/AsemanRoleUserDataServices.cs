﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
    public class AsemanRoleUserDataServices : ConversionMain<AsemanRoleUser, int>, IAsemanRoleUser
    {
        public AsemanRoleUserDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<AsemanRoleUser, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
