﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CMS.Schema.Portal
{
    
    public class Tinymce
    {
        [AllowHtml]
        public string contentHtml { get; set; }
        public string txtSubject { get; set; }
        public string txtEmail { get; set; }
    }
}