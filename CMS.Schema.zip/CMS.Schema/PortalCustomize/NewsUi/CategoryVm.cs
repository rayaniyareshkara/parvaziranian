﻿namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class CategoryVm
    {
        public string Title { get; set; }

        public string Count { get; set; }

        public string Url { get; set; }
    }
}
