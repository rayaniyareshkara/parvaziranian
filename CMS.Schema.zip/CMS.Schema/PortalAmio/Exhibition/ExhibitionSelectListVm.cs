﻿namespace CMS.Schema.PortalAmio.Exhibition
{
    public class ExhibitionSelectListVm
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public string Lang { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

        public string Location { get; set; }

        public string Time { get; set; }

        public string Status { get; set; }
    }
}
