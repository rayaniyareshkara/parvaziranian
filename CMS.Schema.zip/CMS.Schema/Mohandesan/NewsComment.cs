﻿
using System;

namespace CMS.Schema.Mohandesan
{
    public class NewsComment 
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Text { get; set; }
        public int? Target { get; set; }

        public string Name { get; set; }
        public string Mobile { get; set; }
        public string Image { get; set; }
        public DateTime myDate { get; set; }

    }
}
