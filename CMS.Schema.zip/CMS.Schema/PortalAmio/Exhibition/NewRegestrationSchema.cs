﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
    public class NewRegestrationSchema
    {
        public int ExhibitionID { get; set; }
        public string CompanyNameFa { get; set; }
        public string CompanyNameEn { get; set; }
        public string NationalID { get; set; }
        public string EconomyCode { get; set; }
        public string ActivityFieldFa { get; set; }
        public string ActivityFieldEn { get; set; }
        public string ProductsFa { get; set; }
        public string ProductsEn { get; set; }
        public int countryId { get; set; }
        public int ProvinceId { get; set; }
        public int CityId { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string PostCode { get; set; }
        public string MDrictorNameFa { get; set; }
        public string MDrictorNameEn { get; set; }
        public string MdrictorMobile { get; set; }
        public string MDirectorNationalCode { get; set; }
        public string MDirectorEmail { get; set; }
        public string AgentNameFa { get; set; }
        public string AgentNameEn { get; set; }
        public string AgentMobile { get; set; }
        public string AgentNationalCode { get; set; }
        public string AgentEmail { get; set; }
        public int SaloonPlaceRequestReal { get; set; }
        public int SaloonPlaceRequestDollar { get; set; }
        public int BildingModel { get; set; }
        public string TitlePersian { get; set; }
        public string TitleEnglish { get; set; }
        public string KnowledgeBasedCode { get; set; }
        public bool SaloonPlaceModelNormal { get; set; }
        public bool SaloonPlaceModelSpetial { get; set; }
        public bool SaloonPlaceModelspanser { get; set; }
        public int OpenPlaceRequestReal { get; set; }
        public int OpenPlaceRequestDollar { get; set; }
        public bool OPenPlaceModelSpetial { get; set; }
        public bool OPenPlaceModelNormal { get; set; }
        public int BuildingTypeId { get; set; }
        public string SiteAddress { get; set; }

    }
}
