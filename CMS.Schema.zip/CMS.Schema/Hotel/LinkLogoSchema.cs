﻿
namespace CMS.Schema.Hotel
{
    public class LinkLogoSchema
    {
        public string lang { get; set; }
        public string link { get; set; }
    }
}
