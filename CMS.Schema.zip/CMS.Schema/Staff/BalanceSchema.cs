﻿
using System;

namespace CMS.Schema.Staff
{
    public class BalanceSchema
    {
        public int Id { get; set; }
        public Guid UserId { get; set; }
        public string UserName { get; set; }
        public string Phone { get; set; }
        public int Balance { get; set; }
        public int LastBalance { get; set; }
    }

    public class BalanceLogSchema
    {
        public int Id { get; set; }
        public Guid UserId { get; set; }
        public int BalanceId { get; set; }
        public string UserName { get; set; }
        public int? Balance { get; set; }
        public string Description { get; set; }
        public string DateTime { get; set; }
    }
}
