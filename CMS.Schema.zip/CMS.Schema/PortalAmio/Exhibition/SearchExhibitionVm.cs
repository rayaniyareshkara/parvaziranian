﻿using CMS.Schema.Global;

namespace CMS.Schema.PortalAmio.Exhibition
{
    public class SearchExhibitionVm : GlobalGridSchema
    {
    }
}
