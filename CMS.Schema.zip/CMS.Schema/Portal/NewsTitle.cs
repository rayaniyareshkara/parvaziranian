﻿using System;

namespace CMS.Schema.Portal
{
    public class NewsTitle
    {
        public int Id { get; set; }
        public int IntId { get; set; }
        public string Language { get; set; }
        public string Header { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public string LanguageInit { get; set; }
        public DateTime? InsertedDate { get; set; }
        public string Url { get; set; } 
        public string Lead { get; set; }
        public string Rotter { get; set;}

    }
}
