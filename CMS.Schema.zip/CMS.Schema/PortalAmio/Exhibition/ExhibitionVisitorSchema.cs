﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
   public  class ExhibitionVisitorSchema
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }
        public string JobTitle { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public int ExhibitionId { get; set; }
        public int CategoryId { get; set; }
        public int VisitTypeID { get; set; }

    }
    public class PavionVisitorSchema
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }
        public string JobTitle { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public int PavionId { get; set; }      
        public int VisitTypeID { get; set; }

    }
}
