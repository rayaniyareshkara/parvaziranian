﻿using System.ComponentModel.DataAnnotations;


namespace CMS.Schema.Enum.Notification
{
    public enum StatusNotificationEnum :byte
    {
        [Display(Name = "مشاهده نشده")]
        NotBeenSeen = 1,
        [Display(Name = "مشاهده شد")]
        BeenSeen = 2,
    }

}
