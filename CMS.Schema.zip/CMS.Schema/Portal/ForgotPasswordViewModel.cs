﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = @"ایمیل")]
        public string Email { get; set; }
    }

}
