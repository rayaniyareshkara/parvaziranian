﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;



namespace CMS.Infrastructure.Aseman.Classes
{
 public   class MasterDegreeDataServices : ConversionMain<MasterDegree, int>, IMasterDegree
    {
        public MasterDegreeDataServices(EntitysModelCMS context) : base(context)
        {
        }

        public override Expression<Func<MasterDegree, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
