﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
    public class ExamListSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public string CenterName { get; set; } 
        public string ExaminerName { get; set; }
        public int Status { get; set; }
        public string   StatusName { get; set; }
        public DateTime?   AcceptStartDate { get; set; }
        public DateTime?   AcceptEndDate { get; set; }
        public string   StartDate { get; set; }
        public string   EndDate { get; set; }
        public string Code { get; set; }
        public string Type { get; set; }




    }
}
