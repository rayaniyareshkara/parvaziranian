﻿

using System.Collections.Generic;

namespace CMS.Schema.Hall
{
    public class HallMenuSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int HotelId { get; set; }
        public bool IsActive { get; set; }
        public int Price { get; set; }
        public List<MenuInfo> Info { get; set; } = new List<MenuInfo>();
    }
}
