﻿using CMS.Core.Component;
using CMS.Schema.Admin;
using System;
using System.Data.Entity.Core.Objects;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CMS.Core.Attribute
{
    public class _AdminStaffPermissionAuthorize : ActionFilterAttribute, IActionFilter
    {
        private readonly string PageId;
        private readonly string Root;
        private readonly string Code;
        private CMS.FrameWork.Model.EntitysModelCMS db = new FrameWork.Model.EntitysModelCMS();
        private readonly PermissonEnum Type;
        public _AdminStaffPermissionAuthorize(string pageCode, PermissonEnum Type, string Root = "view")
        {
            try
            {
                this.Root = Root.ToLower();
                this.PageId = pageCode.ToLower();
                this.Type = Type;
                if (SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }) != null)
                {
                    var activeId = Guid.Parse(SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }).ActiveCode);
                    this.Code = activeId.ToString();
                }
            }
            catch (Exception)
            {
                SetCookie.DeleteCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS });
            }
        }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                
                var hasPermision = db.Database
                    .SqlQuery<bool>("exec [Management].[CheckNewPermissions] @Code , @IP , @pageCode , @Oper , @Date", 
                    new SqlParameter("@Code", this.Code),
                    new SqlParameter("@IP", ""),
                    new SqlParameter("@pageCode", this.PageId),
                    new SqlParameter("@Oper", Type.ToString()) ,
                    new SqlParameter("@Date", DateTime.Now)).LastOrDefault();//db.CheckNewPermissions(this.Code, filterContext.HttpContext.Request.UserHostAddress, PageId, Type.ToString());
               
                if (hasPermision == false)
                {
                    if (Root == "view")
                    {
                        var viewResult = new ViewResult
                        {
                            ViewName = "~/Areas/staff/Views/Error/Error403.cshtml",
                        };
                        filterContext.Result = viewResult;
                    }
                    else if (Root == "json")
                    {
                        var Result = new JsonResult
                        {
                            Data = new { status = "!ok" , error  = "دسترسی ندارید" },
                          
                            JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                        };
                        filterContext.Result = Result;
                    }
                    else
                    {

                        var viewResult = new PartialViewResult
                        {
                            ViewName = "~/Areas/staff/Views/Error/ChildError403.cshtml",
                        };

                        filterContext.Result = viewResult;
                    }
                }


            }
            catch (Exception )
            {
                // filterContext.Result = new RedirectResult("/fa/Account/Login?returnUrl=" + filterContext.HttpContext.Request.CurrentExecutionFilePath);
            }

            base.OnActionExecuting(filterContext);

        }
    }
}
