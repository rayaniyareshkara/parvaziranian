﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
  public  class SurveyAnswerSchema
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Description { get; set; }
        public int SurveyId { get; set; }
        public string SurveyName { get; set; }
        public int Status { get; set; }
        public string StatusName { get; set; }

       
    }
}
