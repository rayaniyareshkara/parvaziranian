﻿
namespace CMS.Schema.Mohandesan
{
    public class CartItemSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int Price { get; set; }
        public int Count { get; set; }
        public string Image { get; set; }
        public int Type { get; set; }
    }

    public class ItemTypePrice
    {
        public const int Project = 10000;
    }
}
