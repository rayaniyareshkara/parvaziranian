﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class StudentRequestSchema
    {
        public int Id { get; set; }
        public int DegreeId { get; set; }
        public int BranchId { get; set; }
        public string DegreeName { get; set; }
        public string BranchName { get; set; } 
        public int StudentId { get; set; }
        public string Username { get; set; }
        public int Status { get; set; }
        public string StutusName { get; set; }




    }
}
