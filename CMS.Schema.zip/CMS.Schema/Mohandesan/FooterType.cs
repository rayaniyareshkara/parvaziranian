﻿
namespace CMS.Schema.Mohandesan
{
    public class FooterType
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Align { get; set; }

    }

    public class Footer
    {
        public int FooterTypeId { get; set; }
        public int Id { get; set; }
        public string Title{ get; set; }
        public string Link { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
    }
}
