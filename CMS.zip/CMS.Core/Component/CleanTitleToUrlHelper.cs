﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;


namespace CMS.Core.Component
{
    public static class CleanTitleToUrlHelper
    {
        public static string CleanTitleToUrl(this string title)
        {
            Regex regex = new Regex("[\\-\\s;,\\.$&*\\(\\)@!~+=\\?؟]");
            title = regex.Replace(title, "-");
            regex = new Regex("[-]{2,}");
            title = regex.Replace(title, "-");
            return title.Trim().Trim('-');
        }
    }
}
