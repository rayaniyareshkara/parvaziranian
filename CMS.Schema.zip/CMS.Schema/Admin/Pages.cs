﻿
namespace CMS.Schema.Admin
{
    public class Pages
    {
        public string Description { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
