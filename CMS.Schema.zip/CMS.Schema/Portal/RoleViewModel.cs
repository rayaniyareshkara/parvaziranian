﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class RoleViewModel
    {
        public string Id { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "{0} را وارد نمایید")]
        [Display(Name = @"نام نقش")]
        public string Name { get; set; }
    }

}
