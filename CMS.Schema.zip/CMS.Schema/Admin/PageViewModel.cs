﻿
namespace CMS.Schema.Admin
{
    using System;
    using System.Collections.Generic;

    public class PageViewModel
    {
        public PageViewModel()
        {
            PageInLanguage = new Dictionary<string, PagesValidated>();
        }

        public Dictionary<string, PagesValidated> PageInLanguage { get; set; }

        public int? GalleryId { get; set; }
    }

}
