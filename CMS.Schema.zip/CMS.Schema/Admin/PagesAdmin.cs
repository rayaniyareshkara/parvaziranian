﻿
using System;

namespace CMS.Schema.Admin
{
    public class PagesAdmin
    {
        public Guid Id { get; set; }
        public string PageTitle { get; set; }
        public string Url { get; set; }
        public bool InMenu { get; set; }
        public bool IsActive { get; set; }
    }
}
