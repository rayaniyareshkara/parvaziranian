﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class CourseTermSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string BranchName { get; set; } 
        public string MasterName { get; set; }
        public string CourseName { get; set; }
        public string DegreeTermName { get; set; }
        public string Status { get; set; }
        public string ClassName { get; set; }
        public int StatusId { get; set; }
      
    }
}
