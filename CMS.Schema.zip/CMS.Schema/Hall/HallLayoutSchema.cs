﻿

namespace CMS.Schema.Hall
{
    public class HallLayoutSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public int? Capacity { get; set; }
        public bool IsActive { get; set; }
    }
}
