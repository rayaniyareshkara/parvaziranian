﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class AnswerHomeWorkShowSchema
    {
        public int Id { get; set; }

        public Guid UserId { get; set; }
        public string Duration { get; set; }
        public string Image { get; set; } 
        public int Status { get; set; }
        public string CreateDate { get; set; }
        public DateTime CreateDateMain { get; set; }
        public string UserName { get; set; }

    }
}
