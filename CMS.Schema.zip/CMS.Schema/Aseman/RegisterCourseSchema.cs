﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class RegisterCourseSchema
    {
        public string Name { get; set; }
        public string Family { get; set; }
        public string Fathername { get; set; }
        public string NationalCode { get; set; }
        public DateTime BirthDate { get; set; }
        public int Nationality { get; set; }
        public string BirthPlace { get; set; }
        public string PusportNumber { get; set; }
        public int PassportCountryId { get; set; }
        public Byte Sex { get; set; }
        public string IdNumber { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string EmergencyNumber { get; set; }
        public int BranchId { get; set; }
        public int DegreeId { get; set; }
        public string Address { get; set; }
        public string Image { get; set; }

        public string BirthCert1 { get; set; }
        public string BirthCert2 { get; set; }
        public string BirthCert3 { get; set; }
        public string NationalCard { get; set; }
        public string DegreeImage { get; set; }
        public string Certificate1 { get; set; }
        public string Certificate2 { get; set; }
        public string Certificate3 { get; set; }
        public string Code { get; set; }
        public bool Notification { get; set; }


    }
}
