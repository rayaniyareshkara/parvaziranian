﻿using System;


namespace CMS.Schema.Portal
{
    public static class ConfigData
    {
        public static string FileAddress = "~/setting.Config";       
        public static Configuration Load()
        {
            if (Main == null)
            {
                Refresh();
            }
            return Main;
        }

        public static Configuration Main { get; set; }

        public static void Refresh()
        {
            try
            {
                ConfigData.Main = FileWork.ReadFile(FileAddress);
                
            }
            catch (Exception)
            {
            }
        }
    }
}