﻿using System;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace CMS.Schema.Portal
{
    public static class Notification
    {
        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>

        //frestadan email

        public static Boolean Send(string emailTo, string subject, string body, out string resualt)
        {
            MailMessage mail = new MailMessage(ConfigData.Main.EmailConfig.EmailAdress, emailTo.Trim())
            {
                Subject = subject,
                Body = body,
                IsBodyHtml = Convert.ToBoolean(ConfigData.Main.EmailConfig.ISBodyHTML),
                BodyEncoding = Encoding.UTF8,
                SubjectEncoding = Encoding.UTF8
            };
            SmtpClient smtp = new SmtpClient
            {
                Host = ConfigData.Main.EmailConfig.Host,
                EnableSsl = Convert.ToBoolean(ConfigData.Main.EmailConfig.EnableSSL),
                UseDefaultCredentials = Convert.ToBoolean(ConfigData.Main.EmailConfig.UseDefultCredential),
                Port = Convert.ToInt32(ConfigData.Main.EmailConfig.SMTPPort)
            };

            NetworkCredential networkCred = new NetworkCredential
            {
                UserName = ConfigData.Main.EmailConfig.EmailAdress,
                Password = ConfigData.Main.EmailConfig.Password
            };
            smtp.Credentials = networkCred;
            smtp.Send(mail);
            resualt = "Job Done!";
            //ferestadan sms
            return true;
        }
    }
}