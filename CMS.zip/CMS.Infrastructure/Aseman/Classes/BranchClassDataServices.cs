﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;


namespace CMS.Infrastructure.Aseman.Classes
{
 public  class BranchClassDataServices : ConversionMain<BranchClass, int>, IBranchClass
    {
        public BranchClassDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<BranchClass, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}

