﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class CourseTermQuizSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public string IsactiveName { get; set; }
        public bool Isactive { get; set; }
        public string ShowQuestionName { get; set; }
        public bool ShowQuestion { get; set; }

        public int CourseTermId { get; set; }
        public string CourseTermName { get; set; }
        public string DegreeTermName { get; set; }
        public string ClassNumber { get; set; }


    }
}
