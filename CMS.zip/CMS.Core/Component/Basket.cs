﻿//using System;
//using System.Web;
//using System.Web.Script.Serialization;
//using CMS.Schema;
//using System.Linq;
//using CMS.Schema.Admin;
//using System.Collections.Generic;
//using CMS.FrameWork.Model;

//using Newtonsoft.Json;

//namespace CMS.Core.Component
//{

//    public enum CartType
//    {
//        ROOM = 100,
//        EVENT = 102,
//        SERVICE = 103,
//    }
//    public class Basket
//    {


//        private EncodeAndDecode encoder = new EncodeAndDecode();
//        public string AddToBasket(int Id, int Count = 1, CartType Type = CartType.ROOM, DateTime? Date = null, int? Time = null)
//        {
//            try
//            {
//                var Values = new List<Schema.Admin.Cart>();

//                // get cookie
//                var cookie = HttpContext.Current.Request.Cookies[encoder.Encode(CoockieEnum.CartCookie.ToString())];
//                if (cookie != null)
//                {
//                    Values = JsonConvert.DeserializeObject<List<Schema.Admin.Cart>>(encoder.Decode(cookie.Value));
//                    if (Values == null)
//                        Values = new List<Schema.Admin.Cart>();
//                    var product = Values.Where(s => s.PID == Id && s.Type == (int)Type).FirstOrDefault();
//                    if (product != null)
//                    {
//                        Values.Remove(product);
//                        product.Count = Count;
//                        Values.Add(product);
//                    }

//                    else
//                    {
//                        Values.Add(new Schema.Admin.Cart
//                        {
//                            PID = Id,
//                            Type = (int)Type,
//                            Date = Date,
//                            Time = Time,
//                            Count = Count,
//                        });
//                    }
//                }
//                else
//                {
//                    cookie = new HttpCookie(encoder.Encode(CoockieEnum.CartCookie.ToString()));
//                    Values = new List<Schema.Admin.Cart>();
//                    Values.Add(new Schema.Admin.Cart
//                    {
//                        PID = Id,
//                        Date = Date,
//                        Type = (int)Type,
//                        Time = Time,
//                        Count = Count,
//                    });
//                }

//                // check value of cookie

//                // check this product is in cookir


//                // if in 

//                var _value = encoder.Encode(JsonConvert.SerializeObject(Values));

//                reovePrevCookie(cookie);

//                HttpContext.Current.Response.Cookies.Add(new HttpCookie(cookie.Name, _value) { Expires = DateTime.Now.AddDays(5) });

//                // add product in that


//                return "DONE";

//            }
//            catch (Exception e)
//            {
//                new FrameWork.Statute.Events.EventSite().Other(e, "1111897979797979 - add Cart");
//                return "ERROR";
//            }
//        }

//        private bool reovePrevCookie(HttpCookie cookie)
//        {
//            try
//            {

//                cookie.Expires = DateTime.Now.AddDays(-1);
//                //remove prevCookie
//                HttpContext.Current.Response.Cookies.Add(cookie);
//                return true;
//            }
//            catch (Exception ex)
//            {
//                new FrameWork.Statute.Events.EventSite().Other(ex, "خطا در حذف کوکی basket");
//                return false;
//            }
//        }

//        public string RemoveFromBasket(int Id, int Type)
//        {
//            try
//            {
//                var cookie = HttpContext.Current.Request.Cookies[encoder.Encode(CoockieEnum.CartCookie.ToString())];
//                if (cookie != null && cookie.Value != null)
//                {
//                    var Values = JsonConvert.DeserializeObject<List<Schema.Admin.Cart>>(encoder.Decode(cookie.Value));
//                    var product = Values.Where(s => s.PID == Id && s.Type == Type).FirstOrDefault();
//                    if (product != null)
//                        Values.Remove(product);
//                    cookie.Value = encoder.Encode(JsonConvert.SerializeObject(Values));

//                    reovePrevCookie(cookie);

//                    HttpContext.Current.Response.Cookies.Add(new HttpCookie(cookie.Name, cookie.Value) { Expires = DateTime.Now.AddDays(5) });
//                }


//                return "DONE";
//            }
//            catch (Exception e)
//            {
//                new FrameWork.Statute.Events.EventSite().Other(e, "1111897979797978 - remove Cart");
//                return "ERROR";
//            }
//        }

//        public int GenerateFactor(Guid UserId, string OrderId, string Amount, string BankType, string Title, int? hotelid, string Description = "", string hotel = "tehran", string Model = "ساده")
//        {
//            try
//            {
//                var Values = new List<Schema.Admin.Cart>();
//                var cookie = HttpContext.Current.Request.Cookies[encoder.Encode(CoockieEnum.CartCookie.ToString())];
//                if (cookie != null)
//                {
//                    Values = JsonConvert.DeserializeObject<List<Schema.Admin.Cart>>(encoder.Decode(cookie.Value));
//                    if (Values == null)
//                        Values = new List<Schema.Admin.Cart>();
//                }
//                else
//                {
//                    cookie = new HttpCookie(encoder.Encode(CoockieEnum.CartCookie.ToString()));
//                }
//                // check value of cookie


//                if (Values.Count <= 0)
//                    return 0;
//                // save factor
//                var db = new EntitysModelCMS();
//                var factor = db.Factors.Add(new FrameWork.Model.Factor
//                {
//                    Amount = Amount,
//                    Bank = BankType,
//                    Date = DateTime.Now,
//                    IsPay = false,
//                    OrderId = OrderId,
//                    Title = Title,
//                    UserId = UserId,
//                    HotelId = hotelid,
//                    Status = "مرحله اولیه",
//                    Type = 1,
//                    Description = "",
//                    IsDeleted = false,
//                    //  IsRead = false,
//                });


//                var cart = db.Carts.Add(new FrameWork.Model.Cart
//                {
//                    Amount = Amount,
//                    Date = DateTime.Now,
//                    Hotel = hotel,
//                    FactorId = factor.Id,
//                });

//                var model = new List<FrameWork.Model.CartItem>();


//                foreach (var item in Values)
//                {
//                    model.Add(new CartItem
//                    {
//                        Count = item.Count,
//                        CartId = cart.Id,
//                        ProductId = item.PID,
//                        Date = item.Date,
//                        Time = item.Time,
//                        ProductType = item.Type,
//                    });
//                }

//                db.CartItems.AddRange(model);

//                db.SaveChanges();

//                return factor.Id;
//            }
//            catch (Exception ex)
//            {
//                new FrameWork.Statute.Events.EventSite().Other(ex);
//                return -1;
//            }
//        }



//        public List<Schema.Admin.Cart> GetItems()
//        {
//            try
//            {

//                List<Schema.Admin.Cart> Items = new List<Schema.Admin.Cart>();

//                var cookie = HttpContext.Current.Request.Cookies[encoder.Encode(CoockieEnum.CartCookie.ToString())];
//                if (cookie != null)
//                {

//                    // check value of cookie
//                    var val = cookie.Value;
//                    if (val != null)
//                        Items = JsonConvert.DeserializeObject<List<Schema.Admin.Cart>>(encoder.Decode(cookie.Value));

//                }



//                return Items;
//            }
//            catch (Exception ex)
//            {
//                new FrameWork.Statute.Events.EventSite().Other(ex, "1111897979797979 - get item from Cart");
//                return new List<Schema.Admin.Cart>();
//            }
//        }

//        public void RemoveAll()
//        {
//            try
//            {
//                if (HttpContext.Current.Request.Cookies[encoder.Encode(CoockieEnum.CartCookie.ToString())] != null)
//                {
//                    var basketCookie = HttpContext.Current.Request.Cookies[encoder.Encode(CoockieEnum.CartCookie.ToString())];
//                    basketCookie.Expires = DateTime.Now.AddDays(-1);
//                    HttpContext.Current.Response.Cookies.Add(new HttpCookie(basketCookie.Name, basketCookie.Value) { Expires = basketCookie.Expires });
//                }
//            }
//            catch (Exception ex)
//            {
//                new FrameWork.Statute.Events.EventSite().Other(ex, "خطا در حذف basketCookie.RemoveAll");
//            }
//        }

//    }
//}
