﻿
namespace CMS.Schema.Component
{
    public enum FileTypes
    {
        Image = 1,
        Pdf = 2,
        Text = 3
    }
}
