﻿namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class NewsDetailsVm
    {
        public string Title { get; set; }

        public string Summery { get; set; }

        public string Image { get; set; }

        public string[] KeyWords { get; set; }

        public string Description { get; set; }

        public int NewsId { get; set; }

        public string Category { get; set; }

        public string PageName { get; set; }

        public string Time { get; set; }

        public string MetaDescription { get; set; }

        public string MetaKeyWord { get; set; }
    }
}
