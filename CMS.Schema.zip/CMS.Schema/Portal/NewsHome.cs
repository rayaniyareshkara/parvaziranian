﻿

namespace CMS.Schema.Portal
{
    public class NewsHome
    {
        public string Title { get; set; }
        public string Header { get; set; }
        public string Summery { get; set; }
    }
}
