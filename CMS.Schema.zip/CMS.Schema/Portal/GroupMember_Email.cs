﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace CMS.Schema.Portal
{
    public class GroupMember_Email
    {
        [Key]
        [ScaffoldColumn(false)]
        public int Id { get; set; }

        [Required(ErrorMessage = "نام را وارد کنید")]
        [Display(Name = "نام")]
        [DisplayName("نام")]
        public string Name { get; set; }

        [Required(ErrorMessage = "نام خانوادگی را وارد کنید")]
        [Display(Name = "نام خانوادگی")]
        [DisplayName("نام خانوادگی")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "ایمیل را وارد کنید")]
        [Display(Name = "ایمیل")]
        [DisplayName("ایمیل")]
        [RegularExpression(@"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", ErrorMessage = "ایمیل را به درستی وارد کنید")]
        public string Email { get; set; }

        [Required(ErrorMessage = "گروه ایمیل را انتخاب کنید")]
        [Display(Name = "گروه")]
        [DisplayName("گروه")]
        public int EmailGroupId { get; set; }



        [Display(Name = "توضیحات")]
        [DisplayName("توضیحات")]
        public string Description { get; set; }

        [ScaffoldColumn(false)]
        public string EmailGroup_Title { get; set; }
    }
}