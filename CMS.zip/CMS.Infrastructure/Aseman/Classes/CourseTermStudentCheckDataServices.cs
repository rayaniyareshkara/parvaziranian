﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class CourseTermStudentCheckDataServices : ConversionMain<CourseTermStudentCheck, int>, ICourseTermStudentCheck
    {
        public CourseTermStudentCheckDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CourseTermStudentCheck, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
