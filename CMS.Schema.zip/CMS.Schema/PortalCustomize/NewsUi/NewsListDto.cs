﻿using System;

namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class NewsListDto
    {
        public string Title { get; set; }

        public string ImageUrl { get; set; }

        public string Summery { get; set; }

        public string Category { get; set; }

        public string Url { get; set; }

        public DateTime CreationTime { get; set; }
    }
}
