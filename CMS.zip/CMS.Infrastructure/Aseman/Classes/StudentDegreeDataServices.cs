﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;


namespace CMS.Infrastructure.Aseman.Classes
{
  public  class StudentDegreeDataServices : ConversionMain<StudentDegree, int>, IStudentDegree
    {
        public StudentDegreeDataServices(EntitysModelCMS context) : base(context)
        {
        }

        public override Expression<Func<StudentDegree, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
