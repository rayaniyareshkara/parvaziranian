﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
   public class CourseTermTimeHomeWorkDataServices : ConversionMain<CourseTermTimeHomeWork, int>, ICourseTermTimeHomeWork
    {
        public CourseTermTimeHomeWorkDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CourseTermTimeHomeWork, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
