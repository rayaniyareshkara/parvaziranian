﻿
using System;

namespace CMS.Schema.Club
{
    public class CustomerClubSchema
    {
        public int Level { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Guid UserID { get; set; }
        public int CustomerId { get; set; }
        public string UserName { get; set; }
        public string Description { get; set; }
        public string BirthDate { get; set; }
        public string BirthPlace { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string FatherName { get; set; }
        public string IdNumber { get; set; }
        public string Address { get; set; }
        public int? CityId { get; set; }
        public int? StateId { get; set; }
        public int? CountryId { get; set; }
        public string Email { get; set; }
        public string PassportNumber { get; set; }
        public int MaritalStatus { get; set; }
    }
}
