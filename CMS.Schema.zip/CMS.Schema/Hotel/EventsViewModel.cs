﻿using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class EventsViewModel
    {
        public EventsSchema Event { get; set; }
        public List<EventsProductSchema> products { get; set; }
    }
}
