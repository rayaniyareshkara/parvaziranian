﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Admin
{
 public   class TypeNewsSchema
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public Guid UserId { get; set; }
        public int LanguageId { get; set; }
        public string Description { get; set; }
        public string ParentId { get; set; }
     
    }
}
