﻿
namespace CMS.Schema.Club
{
   public class WalletCoinSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImgFile { get; set; }
        public string description { get; set; }
        public int balance { get; set; }

    }
}
