﻿
namespace CMS.Schema.Admin
{
    public enum TypePersonalPage
    {
        UsersSite,
        Role
    }
}
