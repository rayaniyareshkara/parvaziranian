﻿
namespace CMS.Schema.Admin
{
    public class Language
    {
        public string Description { get; set; }
        public int Id { get; set; }
        public string Inti { get; set; }
        public bool IsActive { get; set; }
        public bool IsRTL { get; set; }
        public string LanguageName { get; set; }
        public string NameFile { get; set; }
    }
}
