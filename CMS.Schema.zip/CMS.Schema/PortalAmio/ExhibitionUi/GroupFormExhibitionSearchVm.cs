﻿using System.Collections.Generic;
using CMS.Schema.Global;

namespace CMS.Schema.PortalAmio.ExhibitionUi
{
    public class GroupFormExhibitionSearchVm
    {
        public List<DropDownVm> ExhibitionHalls { get; set; }

        public List<DropDownVm> ExhibitionActivities { get; set; }

        public List<DropDownVm> ExhibitionCompany { get; set; }


    }

    
}
