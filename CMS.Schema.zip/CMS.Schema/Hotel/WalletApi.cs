﻿namespace CMS.Schema.Hotel
{
    public class WalletApi
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string UserName { get; set; }
        public string Title { get; set; }
        public string AdminName { get; set; }
        public int Balance { get; set; }
        public string LastDateChange { get; set; }
        
    }

    public class WalletApiLog
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public int Balance { get; set; }
        public string CrsDate { get; set; }
    }
}
