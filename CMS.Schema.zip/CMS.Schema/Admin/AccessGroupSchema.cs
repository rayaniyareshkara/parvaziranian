﻿
namespace CMS.Schema.Admin
{
    public class AccessGroupSchema
    {
        public int Id { get; set; }
        public bool IsDeleted  { get; set; }
        public bool IsInserted { get; set; }
        public int GroupId { get; set; }
        public bool IsSelected { get; set; }
        public bool IsUpdated { get; set; }
    }
}
