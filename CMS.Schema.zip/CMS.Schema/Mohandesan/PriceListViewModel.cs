﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Mohandesan
{
   public  class PriceListViewModel
    {
        public List<Fields> Metters { get; set; }
        public List<Fields> Fields { get; set; }
        public List<Info> LawFirmsPrice { get; set; }
        public List<Info> EnforcersPrice { get; set; }



    }
}
