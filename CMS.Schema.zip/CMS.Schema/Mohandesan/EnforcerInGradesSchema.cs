﻿
namespace CMS.Schema.Mohandesan
{
   public class EnforcerInGradesSchema
    {
        public string Id { get; set; }
        public int FieldId { get; set; }
        public int GradeId { get; set; }
        public int FieldCode { get; set; }
    }
}
