﻿

namespace CMS.Schema.Hotel
{
    public class AttrPerRoomSchema
    {
        public int Id { get; set; }
        public int RoomId { get; set; }
        public int AttrId { get; set; }
        public bool IsChecked { get; set; }
        public string Title { get; set; }
    }
}
