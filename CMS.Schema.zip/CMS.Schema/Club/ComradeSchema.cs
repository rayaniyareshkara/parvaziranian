﻿namespace CMS.Schema.Club
{
    public class ComradeSchema
    {
        public string Name { get; set; }
        public string Family { get; set; }
        public string FatherName { get; set; }

        public string DateOfBirth { get; set; }

        public string Nationality { get; set; }

        public string IdCertificate { get; set; }

        public string NationalCode { get; set; }
        public string Relativity { get; set; }

        public string PlaceOfIssue { get; set; }

        public string PhoneNumber { get; set; }
    }
}
