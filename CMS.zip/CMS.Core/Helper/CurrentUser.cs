﻿using CMS.Core.Component;
using CMS.FrameWork.Model;
using System;
using System.Linq;

namespace CMS.Core.Helper
{
    public class CurrentUser
    {

        public static UsersSite User
        {
            get
            {
                try
                {
                    var CookieCode = Guid.Parse(SetCookie.ValueCookie(new Schema.Coockie
                    {
                        BehinNewsaadCMS = Schema.CoockieEnum.UsersBehinNewsaadCMS
                    }).ActiveCode);
                    var db = new EntitysModelCMS();
                    var active = db.SessionLogins.FirstOrDefault(w => w.ActiveLogin == CookieCode).UsersSiteId;
                    return db.UsersSites.FirstOrDefault(w => w.Id == active);
                }
                catch (Exception ex)
                {
                    new CMS.FrameWork.Statute.Events.EventSite().Other(ex);
                    return null;
                }
            }
        }




        public static bool IsCommitment
        {
            get
            {
                try
                {
                    Guid _userId = SetCookie.ValueCookie(new Schema.Coockie
                    { BehinNewsaadCMS = Schema.CoockieEnum.UsersBehinNewsaadCMS }).UserId;

                    using (var db = new EntitysModelCMS())
                    {
                        bool? commitment = db.Students
                            .Where(w => w.UserId == _userId)
                            .Select(s => s.IsCommitment)
                            .FirstOrDefault();

                        // اگر null بود یعنی هنوز ثبت نشده
                        return commitment.HasValue && commitment.Value;
                    }
                }
                catch (Exception ex)
                {
                    new CMS.FrameWork.Statute.Events.EventSite().Other(ex);

                    // در صورت خطا، دسترسی را ندهد
                    return false;
                }
            }
        }

    }
}
