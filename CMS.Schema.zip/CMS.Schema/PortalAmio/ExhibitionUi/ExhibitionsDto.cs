﻿using System;

namespace CMS.Schema.PortalAmio.ExhibitionUi
{
    public class ExhibitionsDto
    {
        public string Caption { get; set; }

        public string Image { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime CreationTime { get; set; }

        public string Url { get; set; }

        public string Link { get; set; }
    }
}
