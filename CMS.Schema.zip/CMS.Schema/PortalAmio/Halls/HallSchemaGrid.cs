﻿namespace CMS.Schema.PortalAmio.Halls
{
    public class HallSchemaGrid
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public string Place { get; set; }

        public string Time { get; set; }

        public string Status { get; set; }

        public string Lang { get; set; }
    }
}
