﻿namespace CMS.Schema.Hotel
{
    public class DropDownComradeSchema
    {
        public string Title { get; set; }

        public int Id { get; set; }

        public bool IsSelected { get; set; }
    }
}
