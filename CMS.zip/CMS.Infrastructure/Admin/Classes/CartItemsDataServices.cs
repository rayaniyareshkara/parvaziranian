﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Admin.Interfaces;

namespace CMS.Infrastructure.Admin.Classes
{
    public class CartItemsDataServices : ConversionMain<CartItem, int>, ICartItems
    {
        public CartItemsDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CartItem, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
