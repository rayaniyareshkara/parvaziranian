﻿
namespace CMS.Schema.Admin
{
    public class LanguagesSchema
    {
        public bool? Active { get; set; }
        public string Code { get; set; }
        public int Id { get; set; }
        public string Init { get; set; }
        public bool? IsRtl { get; set; }
        public string Name { get; set; }
    }
}
