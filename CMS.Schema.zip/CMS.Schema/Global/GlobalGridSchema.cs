﻿namespace CMS.Schema.Global
{
    public class GlobalGridSchema
    {
        public int Take { get; set; }

        public int Skip { get; set; }

        public int Lang { get; set; }
    }
}
