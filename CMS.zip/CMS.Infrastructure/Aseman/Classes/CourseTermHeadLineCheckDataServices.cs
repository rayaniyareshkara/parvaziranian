﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class CourseTermHeadLineCheckDataServices : ConversionMain<CourseTermHeadLineCheck, int>, ICourseTermHeadLineCheck
    {
        public CourseTermHeadLineCheckDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CourseTermHeadLineCheck, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}