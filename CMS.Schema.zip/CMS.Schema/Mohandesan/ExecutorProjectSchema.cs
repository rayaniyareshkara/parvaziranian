﻿
using System;

namespace CMS.Schema.Mohandesan
{
    public class ExecutorProjectSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int Area { get; set; }
        public int Region { get; set; }
        public int Floors { get; set; }
        public int Price { get; set; }
        public bool Is_Bought { get; set; }
        public string Phone { get; set; }
        public DateTime Date { get; set; }
        public string Neighbourhood { get; set; }
        public int Structure { get; set; }
        public bool IsActive { get; set; }
        public string Description { get; set; }
        public string KDate { get; set; }
        public string Creator { get; set; }
    }
}
