﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class GroupsMembers
    {
        [Key]
        [ScaffoldColumn(false)]
        public int Id { get; set; }

        [Display(Name = "نام")]
        [Required(ErrorMessage = "نام را وارد کنید")]
        public string Name { get; set; }

        [Display(Name = "نام خانوادگی")]
        [Required(ErrorMessage = "نام خانوادگی را وارد کنید")]
        public string LastName { get; set; }

        [Display(Name = "موبایل")]
        [Required(ErrorMessage = "موبایل را وارد کنید")]
        public string Mobile { get; set; }

        [Display(Name = "نام گروه")]
        [Required(ErrorMessage = "گروه را انتخاب کنید")]
        public Nullable<int> SmsGroupId { get; set; }

        [Display(Name = "توضیحات")]
        public string Description { get; set; }

   

        //public List<SelectListItem> itemSmsGroup(string lang)
        //{
        //    List<SelectListItem> lst;

        //    using (ManagementContext db = new Management.ManagementContext())
        //    {
        //        var gm = db.SmsGroups.ToList();
        //        List<SelectListItem> lsl = new List<SelectListItem>();
        //        SelectListItem sl = new SelectListItem();
        //        sl.Text = lang;
        //        sl.Value = "0";
        //        lsl.Add(sl);

        //        foreach (var item in gm)
        //        {
        //            sl = new SelectListItem();
        //            sl.Text = item.GroupName;
        //            sl.Value = item.Id.ToString();
        //            lsl.Add(sl);
        //        }

        //        lst = lsl;
        //    }

        //    return lst;
        //}

        [ScaffoldColumn(false)]
        
        public string smsGroupTitle { get; set; }
    }  
}