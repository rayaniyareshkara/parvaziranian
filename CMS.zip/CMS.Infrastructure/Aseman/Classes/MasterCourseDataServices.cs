﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
    public class MasterCourseDataServices : ConversionMain<MasterCourse, int>, IMasterCourse
    {
        public MasterCourseDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<MasterCourse, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
