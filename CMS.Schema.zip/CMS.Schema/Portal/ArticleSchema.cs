﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Public
{
public    class ArticleSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Body { get; set; }
        public string Header { get; set; }

        public string Image { get; set; }
        public string ImageMobile { get; set; }
        public int View { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime Date { get; set; }
        public string Author { get; set; }
        public string Keys { get; set; }
        public bool IsActive { get; set; }
        public int? CategoryId { get; set; }
    }
}
