﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class CourseTermDataServices : ConversionMain<CourseTerm, int>, ICourseTerm
    {
        public CourseTermDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CourseTerm, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
