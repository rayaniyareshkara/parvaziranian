﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
    public class FinanceDocTypeDataServices : ConversionMain<FinanceDocType, int>, IFinanceDocType
    {
        public FinanceDocTypeDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<FinanceDocType, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}