﻿namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class PopularNewsVm
    {
        public string Title { get; set; }

        public string Image { get; set; }

        public string Url { get; set; }
    }
}
