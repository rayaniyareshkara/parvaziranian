﻿
using System;

namespace CMS.Schema.Staff
{
    public class CalendarDatesByIdSchema
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string PersianDate { get; set; }
    }
}
