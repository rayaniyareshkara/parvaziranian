﻿using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA.Repository;

namespace CMS.Infrastructure.Aseman.Interfaces
{
  public  interface IBranch : IRule<Branch, int>
    {
    }
}
