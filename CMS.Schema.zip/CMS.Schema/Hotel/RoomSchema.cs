﻿
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class RoomSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public List<string> Image { get; set; }
        public string Description { get; set; }
        public string Brief { get; set; }
        public int? HotelId { get; set; }
        public string Pic { get; set; }
        public string Link { get; set; }
        public int? Price { get; set; }
    }
}
