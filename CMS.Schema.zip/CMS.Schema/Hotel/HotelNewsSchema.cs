﻿
using System;

namespace CMS.Schema.Hotel
{
    public class HotelNewsSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public string Embed { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public string  Caption { get; set; }
        public int? galleryId { get; set; }
        public int Comments { get; set; }
        public int? HotelId { get; set; }
        public string Hotel { get; set; }
        public string Body { get; set; }
        public bool All { get; set; }
        public string Keys { get; set; }
        public string MetaNames { get; set; }
        public string MetaDesc { get; set; }

    }
}
