﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
    [Serializable]
    public class MellatShema
    {
        private string _UserName;
        public string UserName {
            get { return Cypher.Decrypt(_UserName); }
            set { _UserName = Cypher.Encrypt(value); }
        }

        private string _Pass;
        public string Password
        {
            get { return Cypher.Decrypt(_Pass); }
            set { _Pass = Cypher.Encrypt(value); }
        }

        private string _TerminalId;
        public string TerminalId
        {
            get { return Cypher.Decrypt(_TerminalId); }
            set { _TerminalId = Cypher.Encrypt(value); }
        }
        private string _Pin;
        public string Pin
        {
            get { return Cypher.Decrypt(_Pin); }
            set { _Pin = Cypher.Encrypt(value); }
        }

        public bool IsActive { get; set; }
    }
}
