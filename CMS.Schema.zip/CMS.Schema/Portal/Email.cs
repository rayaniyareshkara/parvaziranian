﻿using System;

namespace CMS.Schema.Portal
{
    [Serializable]
    public class Email
    {
        //تنظیمات ایمیل
        private string _Host;

        public string Host

        {
            get { return Cypher.Decrypt(_Host); }
            set { _Host = Cypher.Encrypt(value); }
        }

        private string _SMTPPort;

        public string SMTPPort
        {
            get { return Cypher.Decrypt(_SMTPPort); }
            set { _SMTPPort = Cypher.Encrypt(value); }
        }

        private String _EmailAdress;

        public String EmailAdress
        {
            get { return Cypher.Decrypt(_EmailAdress); }
            set { _EmailAdress = Cypher.Encrypt(value); }
        }

        private string _Password;

        public string Password
        {
            get { return Cypher.Decrypt(_Password); }
            set { _Password = Cypher.Encrypt(value); }
        }

        public bool UseDefultCredential { get; set; }

        public bool EnableSSL { get; set; }

        public bool ISBodyHTML { get; set; }

        // پایان تنظیمات ایمیل 
    }
}
