﻿
namespace CMS.Schema.Mohandesan
{
    public class TreatySchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string File { get; set; }
        public string WordFile { get; set; }
        public string MetaKeyword { get; set; }
        public string MetaDescription { get; set; }
        public string MetaName { get; set; }
        public int? GalleryId { get; set; }

        public string TypeId { get; set; }
    }
}
