﻿using CMS.Schema.Hotel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace CMS.Core.Component
{
    public class LinkLogoServices
    {
        public List<LinkLogoSchema> ListLinks;
        private static LinkLogoServices _Instance;
        
        public static LinkLogoServices Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new LinkLogoServices();
                    Data();

                }

                return _Instance;
            }
        }
         
        public static void Data()
        {
            try
            {
               
                var path = HttpContext.Current.Server.MapPath("~/link.json");
                string json = File.ReadAllText(path);
                _Instance.ListLinks = JsonConvert.DeserializeObject<List<LinkLogoSchema>>(json) ?? new List<LinkLogoSchema>();
            }
            catch (Exception)
            {
                _Instance.ListLinks = new List<LinkLogoSchema>();
            }
        }

        public bool NewLink(string link,string lang = "fa")
        {
            try
            {

                var path = HttpContext.Current.Server.MapPath("~/link.json");
                string json = File.ReadAllText(path);
                _Instance.ListLinks = JsonConvert.DeserializeObject<List<LinkLogoSchema>>(json) ?? new List<LinkLogoSchema>();

                var item = _Instance.ListLinks.Where(w => w.lang == lang).FirstOrDefault();

                if (item == null)
                {

                    _Instance.ListLinks.Add(new LinkLogoSchema
                    {
                        lang = lang.ToLower(),
                        link = link?.ToLower() ?? ""
                    });
                }
                else
                {
                    item.lang = lang.ToLower();
                    item.link = link?.ToLower() ?? "";

                }

                System.IO.File.WriteAllText(path, JsonConvert.SerializeObject(_Instance.ListLinks));

                Data();
                return true;

            }
            catch (Exception)
            {

                return false;
            }
          
        }

        public string GetLink(string lang = "fa")
        {
            try
            {
               return _Instance.ListLinks.Where(w => w.lang.ToLower() == lang.ToLower()).FirstOrDefault()?.link ?? "";
            }
            catch (Exception)
            {
                return "";
            }
        }
             

    }
}
