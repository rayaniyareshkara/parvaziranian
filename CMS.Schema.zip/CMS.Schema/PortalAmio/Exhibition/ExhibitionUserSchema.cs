﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
  public  class ExhibitionUserSchema
    {
        public int Id { get; set; }
        public Guid UserId { get; set; }
        public string CompanyName { get; set; }
        public string  Mobile { get; set; }
        public string TypeUser { get; set; }
        public string StateRegister { get; set; }
        public byte StateRegisterID { get; set; }
        public string   Accepted { get; set; }
        public bool AcceptedStatus { get; set; }
        public DateTime Time { get; set; }
        public string TimePersian { get; set; }
    }
}
