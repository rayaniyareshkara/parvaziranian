﻿namespace CMS.Schema.Enum
{
    /// <summary>
    /// if(Value=1)
    /// {
    ///  WebSite="وب سایت"
    /// }
    /// if(value=2)
    /// {
    /// Advertising="تبلیغات"
    /// }
    /// if(value=3)
    /// {
    /// Company="شرکت"
    /// }
    /// if(value=4)
    /// {
    /// Ins="اینستگرام"
    /// }
    /// if(value=5)
    /// {
    /// Agency="آژانس"
    /// }
    /// </summary>
    public enum KnowTheHotelEnum
    {
        WebSite = 1,
        Advertising = 2,
        Company = 3,
        Ins = 4,
        Agency = 5


    }

}
