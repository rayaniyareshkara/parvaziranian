﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class CourseSourceSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string File { get; set; }
        public string Author { get; set; }
        public string Description { get; set; }
        public Guid? MasterUserId { get; set; }
      
        public string MasterName { get; set; }
        public string CourseName { get; set; }
        public string CourseId { get; set; }
        
      
     
    }
}
