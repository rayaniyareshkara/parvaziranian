﻿namespace CMS.Schema.jsTree
{
    public class JsTreeNodeLiAttributes
    {
        public string data { set; get; }
    }
}
