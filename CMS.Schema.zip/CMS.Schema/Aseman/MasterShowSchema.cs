﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class MasterShowSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string MasterHeader{ get; set; }
        public int? MasterId{ get; set; }
        public string Image { get; set; }
      
    }
}
