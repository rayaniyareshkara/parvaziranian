﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Schema.Global;

namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class CommentNewsSubmit : CommentSubmit
    {
        public int NewsId { get; set; }
    }
}
