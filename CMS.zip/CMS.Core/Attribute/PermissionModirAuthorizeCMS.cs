﻿using System;
using System.Web.Mvc;
using CMS.Core.Component;
using System.Linq;
using CMS.Schema.Admin;
using CMS.Schema.Portal;
using System.Web;

namespace CMS.Core.Attribute
{
    public class PermissionModirAuthorizeCMS : ActionFilterAttribute, IActionFilter
    {
        private readonly string PageName;
        private readonly string Root;
        private CMS.FrameWork.Model.EntitysModelCMS db = new FrameWork.Model.EntitysModelCMS();
        private Guid UserId;
        private readonly PermissonEnum Type;
        public PermissionModirAuthorizeCMS(string pageName, PermissonEnum Type, string Root = "view")
        {
            this.Root = Root.ToLower();
            this.PageName = pageName;
            this.Type = Type;
            //   var db = new CMS.FrameWork.Model.EntitysModelCMS();
            if (SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }) != null)
            {
                var activeId = Guid.Parse(SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }).ActiveCode);
                this.UserId = db.UsersActiveCookies.Where(x => x.ActiveId == activeId).FirstOrDefault().UsersSiteId;
            }
        }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            if (SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }) != null)
            {
                var activeId = Guid.Parse(SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }).ActiveCode);
                this.UserId = db.UsersActiveCookies.Where(x => x.ActiveId == activeId).FirstOrDefault().UsersSiteId;
            }
            var GetUserAndPermissins = Component.Permission.Instance.Where(x => x.Id == UserId.ToString() && x.PageName == PageName).Select(s => new PermisstionUserSchema { IsInserted = s.IsInserted, IsDeleted = s.IsDeleted, IsSelected = s.IsSelected, IsUpdated = s.IsUpdated }).ToList();

            var ii = GetUserAndPermissins.Count();

            if (GetUserAndPermissins.Count() > 1)
            {
                GetUserAndPermissins.FirstOrDefault().IsDeleted = GetUserAndPermissins.Any(x => x.IsDeleted == true) ? true : false;

                GetUserAndPermissins.FirstOrDefault().IsInserted = GetUserAndPermissins.Any(x => x.IsInserted == true) ? true : false;

                GetUserAndPermissins.FirstOrDefault().IsSelected = GetUserAndPermissins.Any(x => x.IsSelected == true) ? true : false;
                GetUserAndPermissins.FirstOrDefault().IsUpdated = GetUserAndPermissins.Any(x => x.IsUpdated == true) ? true : false;

            }
            if (GetUserAndPermissins.Any())
            {
                bool hasPermision = false;
                switch (Type)
                {
                    case PermissonEnum.IsActive:
                        break;
                    case PermissonEnum.IsSelect:
                        hasPermision = GetUserAndPermissins.FirstOrDefault().IsSelected == true ? true : false;
                        break;
                    case PermissonEnum.IsDelete:
                        hasPermision = GetUserAndPermissins.FirstOrDefault().IsDeleted == true ? true : false;
                        break;
                    case PermissonEnum.IsUpdate:
                        hasPermision = GetUserAndPermissins.FirstOrDefault().IsUpdated == true ? true : false;
                        break;
                    case PermissonEnum.IsInsert:
                        hasPermision = GetUserAndPermissins.FirstOrDefault().IsInserted == true ? true : false;
                        break;
                    default:
                        hasPermision = false;
                        break;
                }
                if (hasPermision == false)
                {
                //    db.Permission.Add(new FrameWork.Model.Permission { Action = Type.ToString(), UserId = this.UserId, PageName = PageName, Date = DateTime.Now, IP = HttpContext.Current.Request.UserHostAddress });
                //    db.SaveChanges();
                    if (Root == "view")
                    {
                        var viewResult = new ViewResult
                        {
                            ViewName = "~/Areas/Modir/Views/Error/Error403.cshtml",
                        };
                        filterContext.Result = viewResult;


                    }
                    else
                    {
                        var viewResult = new PartialViewResult
                        {
                            ViewName = "~/Areas/Modir/Views/Error/ChildError403.cshtml",
                        };
                        filterContext.Result = viewResult;
                    }

                }
            }
            else
            {
         //       db.Permission.Add(new FrameWork.Model.Permission { Action = Type.ToString(), PageName = PageName, Date = DateTime.Now, IP = HttpContext.Current.Request.UserHostAddress, UserId = this.UserId });
          //      db.SaveChanges();
                if (Root == "view")
                {
                    var viewResult = new ViewResult
                    {
                        ViewName = "~/Areas/Modir/Views/Error/Error403.cshtml",
                    };
                    filterContext.Result = viewResult;
                }
                else
                {
                    var viewResult = new PartialViewResult
                    {
                        ViewName = "~/Areas/Modir/Views/Error/ChildError403.cshtml",
                    };
                    filterContext.Result = viewResult;
                }
            }
            base.OnActionExecuting(filterContext);
        }
    }
}
