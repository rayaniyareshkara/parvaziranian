﻿namespace CMS.Schema.Enum
{
    public static class MessageSmsSchema
    {

        public static string GetMessageSmsForPaymentOfBankReceipt(string userName, int invoiceNumber)
        {
            var message = $"{userName}:از طریق پرداخت فیش بانکی پرداخت شد-نام کاربر پرداخت کننده-{invoiceNumber} مدیر محترم سایت فاکتور ";
            return message;
        }

        public static string GetMessageSmsForPaymentOfBankCheck(string userName, int invoiceNumber)
        {
            var message = $"{userName}:از طریق چک پرداخت شد-نام کاربر پرداخت کننده-{invoiceNumber} مدیر محترم سایت فاکتور ";
            return message;
        }

        public static string GetMessageSmsForAddNewUsers(string userName)
        {
            var message = $"مدیر محترم سایت یک کاربر جدی با شماره کاربری {userName} در سایت ثبت نام کرد";
            return message;
        }

        public static string GetApproveUsers()
        {
            var message = $"اطلاعات شما توسط كارشناس تاييد شد لطفا جهت تاييد متراژ به پروفايل مراجعه نماييدبا تشكر شركت آواي موفق ايرانيان.";
            return message;
        }

        public static string GetConfirmationOfSubmittedDocuments()
        {
            var message = $"جهت پرداخت غرفه به پروفايل مراجعه نماييدبا تشكر شركت آواي موفق ايرانيان.";
            return message;
        }
        public static string GetSecurityCode(this string code)
        {
            var message = $"کد تایید شما برای ورود : {code}{System.Environment.NewLine} هلدینگ هوانوردی  ";
            return message;
        }

        public static string GetConfirmEmail(this string code)
        {
            var message = $"Verification code of your email on Avye Movagh WebSite:{code}";
            return message;
        }

        public static string GetReportPassword(this string password)
        {
            var message = $"کد بازیابی شما برای ورود : { password} {System.Environment.NewLine} هلدینگ هوانوردی ";
            return message;
        }
        public static string GetApproveMap()
        {
            var message = $"لطفا جهت تكميل و ارسال مدارك به پروفايل مراجعه نماييدبا تشكر شركت آواي موفق ايرانيان.";
            return message;
        }
        public static string GetUpdatePlaceRequest()
        {
            var message = $"لطفا جهت پيش پرداخت به سايت مراجعه نماييدبا تشكر شركت آواي موفق ايرانيان.";
            return message;
        }

        public static string GetFinancialConfirmation()
        {
            var message = $"اطلاعات شما توسط كارشناس تاييد شد لطفا جهت تاييد متراژ به پروفايل مراجعه نماييدبا تشكر شركت آواي موفق ايرانيان.";
            return message;
        }

        public static string GetMessageForStatus()
        {
            var message = $"کاربر محترم اطلاعات شما توسط کارشناس تایید شد {System.Environment.NewLine} از طرف شرکت هلدینگ هوانوردی  ";
            return message;
        }
    }
}
