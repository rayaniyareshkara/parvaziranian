﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class ResultQuizSchema
    {
        public int Id { get; set; }
        public string StudentName { get; set; }
        public string StudentFamily { get; set; }
        public string Score { get; set; }
        public List<ResultStudent> DetailList { get; set; }
    }
     public  class ResultStudent
    {  
        public int Id { get; set; }
        public string Title { get; set; }
        public string Answer { get; set; }
      
      
    }
    
}
