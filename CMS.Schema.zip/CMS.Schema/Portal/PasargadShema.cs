﻿

namespace CMS.Schema.Portal
{
    public class PasargadShema
    {
        private string _merceId;
        public string merceId
        {
            get { return Cypher.Decrypt(_merceId); }
            set { _merceId = Cypher.Encrypt(value); }
        }

        private string _username;
        public string username
        {
            get { return Cypher.Decrypt(_username); }
            set { _username = Cypher.Encrypt(value); }
        }


        private string _password;
        public string password
        {
            get { return Cypher.Decrypt(_password); }
            set { _password = Cypher.Encrypt(value); }
        }

        public bool IsActive { get; set; }
    }
}
