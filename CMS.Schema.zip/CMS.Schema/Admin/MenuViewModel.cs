﻿using System.Collections.Generic;

namespace CMS.Schema.Admin
{
    public class MenuViewModel
    {
        public List<LanguagesSchema> Languages { get; set; }
    }
}
