﻿
namespace CMS.Schema.Mohandesan
{
    public class LawfirmExaminationPricesSchema
    {
     
        public int ExFieldId { get; set; }
        public double Price { get; set; }
    }
}
