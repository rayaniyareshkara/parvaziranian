﻿
using System;
using System.Collections.Generic;
namespace CMS.Schema.Hotel
{
    public class RoomReservationSchema
    {
        public RoomReservationSchema()
        {
            features = new List<string>();
            DatePerPrice = new List<Tuple<DateTime, int>>();
        }
        public int  Id { get; set; }
        public List<string> features { get; set; }
        public string Title { get; set; }
        public int hotelid { get; set; }
        public string hotelname { get; set; }
        public int Capacity { get; set; }
        public int Adult_Capacity { get; set; }
        public int Child_Capacity { get; set; }
        public string Size { get; set; }
        public int AdditionalNo { get; set; }
        public List<Tuple<DateTime , int>> DatePerPrice { get; set; }
        public int MaxCount { get; set; }
        public string BedSize { get; set; }
        public string Code { get; set; }
        public int Price { get; set; }
        public string Tour { get; set; }
        public int OrginalPriceDiscount { get; set; }
        public int ReserveAdditionalNo { get; set; }
        public int ReserveChildAdditionalNo { get; set; }
        public string Image { get; set; }
        public bool Extra { get; set; }
        public int PriceExtra { get; set; }
        public int PriceDiscount { get; set; }
        public string AdditionalInfo { get; set; }
        public int CountReserved { get; set; }
        public int Count { get; set; }
    }
}
