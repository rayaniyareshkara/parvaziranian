﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class MasterLibrarySchema
    {
        public int Id { get; set; }
        public string LibraryName { get; set; } 
        public string MasterName { get; set; } 
        public int MasterId { get; set; } 
        public int LibraryId { get; set; }

        
    }
}
