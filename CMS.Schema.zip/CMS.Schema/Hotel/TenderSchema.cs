﻿
using System;
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class TenderSchema
    {
        public int Id { get; set; }
        public string RegisterDate { get; set; }

        public string ReleaseDate { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ExpireDate { get; set; }
        public string Type { get; set; }
        public string Brief { get; set; }

        public List<TenderFileSchema> Files { get; set; } = new List<TenderFileSchema>();

    }
}
