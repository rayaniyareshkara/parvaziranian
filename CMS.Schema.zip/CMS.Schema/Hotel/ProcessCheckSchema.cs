﻿
using System;
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class ProcessCheckSchema
    {
        public ProcessCheckSchema()
        {
            Reserve = new ReserveBoxSchema();
            Guests = new List<Info>();
        }
        public string RejectMessage { get; set; }
        public string Reservator_Name { get; set; }
        public string Reservator_Phone { get; set; }
        public string Reservator_Email { get; set; }
        public string Reservator_Mobile { get; set; }
        public int AdditionalPersonPrice { get; set; }
        public int Status { get; set; }
        public string HotelPhone { get; set; }
        public string HotelMap { get; set; }
        public DateTime? ExpireDate { get; set; }
        public int TotalMin { get; set; }
        public int TotalSecends { get; set; }
        public List<Info> Guests { get; set; }
        public ReserveBoxSchema Reserve { get; set; }
    }
    public class ReserveBoxSchema
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int TotalPrice { get; set; }
        public string Hotel { get; set; }
        public int HotelId { get; set; }
        public List<string> Rooms { get; set; }
        public List<RoomSchema> RoomInfo { get; set; }
        public string HotelAddress { get; set; }
        public string HotelPhone { get; set; }
        public string HotelImage { get; set; }
        public int DiscountMembership { get; set; }
        public int DiscountCode { get; set; }
        public int Tax { get; set; }
    }



}
