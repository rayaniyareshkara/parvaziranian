﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Admin
{
 public   class UserShowSchema
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
    }
}
