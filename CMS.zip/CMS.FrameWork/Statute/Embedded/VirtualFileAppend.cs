﻿using System;
using System.IO;
using System.Web;
using System.Web.Hosting;
using CMS.FrameWork.Statute.Embedded.Repository;

namespace CMS.FrameWork.Statute.Embedded
{
    public class VirtualFileAppend : VirtualFile
    {
        private readonly string _mPath;
        private readonly IViewProvider _viewProvider;

        public VirtualFileAppend(string virtualPath, IViewProvider viewProvider)
            : base(virtualPath)
        {
            if (viewProvider == null) throw new ArgumentNullException("viewProvider");

            _mPath = VirtualPathUtility.ToAppRelative(virtualPath);
            _viewProvider = viewProvider;
        }

        public override Stream Open()
        {
            var returnValue = _viewProvider.Open(_mPath);
            return returnValue;
        }
    }
}
