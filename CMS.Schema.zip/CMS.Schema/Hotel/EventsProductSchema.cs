﻿

namespace CMS.Schema.Hotel
{
    public class EventsProductSchema
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public int Count { get; set; }
        public int Price { get; set; }
        public string Image { get; set; }
        public int SocialViewCount { get; set; }
        public int? CountBuy { get; set; }
        public string TicketDescription { get; set; }
        public int EventId { get; set; }
    }
}
