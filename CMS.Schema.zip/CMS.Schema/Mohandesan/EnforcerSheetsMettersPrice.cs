﻿

using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
    public class EnforcerSheetsMettersPrice
    {
        public int metter_id { get; set; }
        public List<EnforcerPriceSchema> price { get; set; }
      
    }

    public class EnforcerPriceSchema
    {
        public int field_id { get; set; }
        
        public int price { get; set; }
    }
}
