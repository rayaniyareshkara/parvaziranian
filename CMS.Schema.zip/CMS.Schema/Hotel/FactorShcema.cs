﻿
using System;
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class FactorShcema
    {
        public int Id { get; set; }
        public bool Status { get; set; } 
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public string Bank { get; set; }
        public string FullName { get; set; } 
        public int Price { get; set; }
        public List<FactorItemsShcema> Items { get; set; }
    }
    public class FactorItemsShcema
    {
        public int Id { get; set; }
        public int Type { get; set; }
        public int Price { get; set; }
        public int Count { get; set; }
        public string Title { get; set; }
        public string Time { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
    }
}
