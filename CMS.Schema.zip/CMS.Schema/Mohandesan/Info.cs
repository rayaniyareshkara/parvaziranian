﻿
using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
    public class Info
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Phone { get; set; }
        public string Grade { get; set; }
        public List<SheetPriceSchema> prices { get; set; }
    }
}
