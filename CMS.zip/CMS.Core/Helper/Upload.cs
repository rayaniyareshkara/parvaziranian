﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Web;
using System.Web.Helpers;

namespace CMS.Core.Helper
{
    public class Upload
    {
        public string UploadImages(HttpPostedFileBase file, string FolderName, string ext, bool IsWaterMark = true)
        {
            WebImage img = new WebImage(file.InputStream);
            DateTime dt = DateTime.Now;
            string FileName = dt.Year.ToString() + dt.Month.ToString() + dt.Day.ToString() + dt.Hour.ToString() + dt.Minute.ToString() + dt.Second.ToString() + dt.Millisecond.ToString();
            if (IsWaterMark)
            {
                // img.AddImageWatermark(HttpContext.Current.Server.MapPath($@"~/Images/orginal-watermark.png"), img.Width / 7, img.Height / 7, "Left", "Top", 100, 5);
            }

            img.Save(HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Orginal" + "/") + FileName, ext.Replace(".", ""));
            byte[] fileBytes = System.IO.File.ReadAllBytes(HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Orginal" + "/") + FileName+"."+ ext.Replace(".", ""));

            System.Drawing.Image i;
            using (MemoryStream ms = new MemoryStream())
            {
                ms.Write(fileBytes, 0, fileBytes.Length);
                i = System.Drawing.Image.FromStream(ms);
            }

            // Create the thumbnail
            System.Drawing.Image thumbnail = i.GetThumbnailImage(300, 300, () => false, IntPtr.Zero);
            thumbnail.Save(HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Large" + "/") + FileName+"."+ext.Replace(".", ""));
           

             thumbnail = i.GetThumbnailImage(200, 200, () => false, IntPtr.Zero);
            thumbnail.Save(HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Medium" + "/") + FileName+"."+ext.Replace(".", ""));
           
    
            thumbnail = i.GetThumbnailImage(100, 100, () => false, IntPtr.Zero);
            thumbnail.Save(HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Small" + "/") + FileName+"."+ ext.Replace(".", ""));
            //name = AddWaterMark(FileName + ext, HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Orginal" + "/"), newName, "orginal");
            //name = AddWaterMark(FileName + ext, HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Large" + "/"), newName, "large");
            //name = AddWaterMark(FileName + ext, HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Small" + "/"), newName, "Small");
            //name = AddWaterMark(FileName + ext, HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Medium" + "/"), newName, "medium");
            return FileName + ext.Replace(".jpg", ".jpeg");
        }
        private string AddWaterMark(string img, string path, string newName, string p)
        {
            try
            {

                Image watermark = Image.FromFile(path + img);

                Image frame = Image.FromFile(HttpContext.Current.Server.MapPath($@"~/Images/{p}-watermark.png"));


                using (frame)
                {
                    using (var bitmap = new Bitmap(watermark.Width, watermark.Height))
                    {
                        using (var canvas = Graphics.FromImage(bitmap))
                        {
                            canvas.InterpolationMode = InterpolationMode.HighQualityBicubic;
                            canvas.DrawImage(watermark,
                                             new Rectangle(0,
                                                           0,
                                                           watermark.Width, watermark.Height),
                                             new Rectangle(0,
                                                           0,
                                                           watermark.Width,
                                                           watermark.Height),
                                             GraphicsUnit.Pixel);

                            canvas.DrawImage(frame,
                                          new Rectangle(0,
                                                        0,
                                                        watermark.Height / 5, frame.Height / 5),
                                          new Rectangle(0,
                                                        0,
                                                        frame.Height / 5, frame.Height / 5),
                                          GraphicsUnit.Pixel);
                            //canvas.DrawImage(frame,
                            //                 (bitmap.Width ) - (watermark.Width ),
                            //                 (bitmap.Height) - (watermark.Height));
                            canvas.Save();
                        }
                        bitmap.Save(path + newName + "." + System.Drawing.Imaging.ImageFormat.Jpeg,
                                    System.Drawing.Imaging.ImageFormat.Jpeg);
                    }
                }

                return newName + System.Drawing.Imaging.ImageFormat.Jpeg;
            }
            catch
            {
                return img;
            }
        }

        public string UploadFileUser(HttpPostedFileBase file, string folderName)
        {
            //--If File Is Null
            if (file == null)
                return null;

            //<-- Check The Content Type File Submit /(image/jpg- image/png - image/jpeg - /application/pdf)
            var valid = file.IsValidFileSubmitUser();
            if (valid == false)
                return null;
            //<-- Get Content Type File  
            var typeFile = file.GetContentTypeFile();
            var dt = DateTime.Now;

            var fileName = dt.Year.ToString() + dt.Month.ToString() + dt.Day.ToString() +
                              dt.Hour.ToString() + dt.Minute.ToString() + dt.Second.ToString() +
                              dt.Millisecond.ToString() + typeFile;

            file.SaveAs(HttpContext.Current.Server.MapPath("/Images/" + "/" + folderName + "/" + fileName));


            return fileName;


        }
        public string UploadOtherFiles(HttpPostedFileBase file, string FolderName, string ext, bool IsWaterMark = true)
        {

            DateTime dt = DateTime.Now;
            string FileName = dt.Year.ToString() + dt.Month.ToString() + dt.Day.ToString() + dt.Hour.ToString() + dt.Minute.ToString() + dt.Second.ToString() + dt.Millisecond.ToString();
            if (IsWaterMark)
            {
                // img.AddImageWatermark(HttpContext.Current.Server.MapPath($@"~/Images/orginal-watermark.png"), img.Width / 7, img.Height / 7, "Left", "Top", 100, 5);
            }
            //     img.Save(HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Orginal" + "/") + FileName, ext.Replace(".", ""));

            file.SaveAs(HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/") + FileName + ext);


            return FileName + ext;
        }
        public string UploadVideo(HttpPostedFileBase file, string FolderName, string ext, bool IsWaterMark = true)
        {

            DateTime dt = DateTime.Now;
            string FileName = dt.Year.ToString() + dt.Month.ToString() + dt.Day.ToString() + dt.Hour.ToString() + dt.Minute.ToString() + dt.Second.ToString() + dt.Millisecond.ToString();
            if (IsWaterMark)
            {
                // img.AddImageWatermark(HttpContext.Current.Server.MapPath($@"~/Images/orginal-watermark.png"), img.Width / 7, img.Height / 7, "Left", "Top", 100, 5);
            }
            //     img.Save(HttpContext.Current.Server.MapPath("/Images/" + FolderName + "/" + "Orginal" + "/") + FileName, ext.Replace(".", ""));

            file.SaveAs(HttpContext.Current.Server.MapPath("/Video/" + FolderName + "/") + FileName + ext);


            return FileName + ext;
        }

    }
}
