﻿
using System;
using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
    public class HiringSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string KDate { get; set; }
        public DateTime Date { get; set; }
        public List<int> Fields { get; set; }
        public string Cooperation { get; set; }
        public string LawfirmDescription { get; set; }
        public int? Grade { get; set; }
        public int? terend { get; set; }
        public string Experience { get; set; }
        public string EducationName { get; set; }
        public string Salary { get; set; }
        public bool IsConfirm { get; set; }
        public string Address { get; set; }
        public string GradeName { get; set; }
        public string TerendName { get; set; }
        public string Image { get; set; }
        public bool? Gender { get; set; }
        public List<string> FieldsName { get; set; }
        public string militaryservicestatus { get; set; }
        public List<string> Education { get; set; }
        public List<string> Ability { get; set; }
        public string Description { get; set; }
        public string Lawfirm { get; set; }
        public int LawId { get; set; }
    }
}
