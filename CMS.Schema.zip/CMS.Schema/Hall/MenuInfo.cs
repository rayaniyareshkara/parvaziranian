﻿using System.Collections.Generic;

namespace CMS.Schema.Hall
{
    public class MenuInfo
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int Price { get; set; }
    }

    public class MenuReserveTypeSchema
    {
        public int? MenuId { get; set; }
        public int? ServetypeId { get; set; }
        public int? serveplace { get; set; }
        public string endtime { get; set; }
        public string starttime { get; set; }
        
        public int? MealId { get; set; }
        public int? Count { get; set; }
        public string Serve { get; set; }
        public string Menu { get; set; }
        public List<MenuInfo> MenuDatils { get; set; } = new List<MenuInfo>();

    }
}
