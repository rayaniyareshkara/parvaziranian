﻿
namespace CMS.Schema.Portal
{
    public enum FooterType
    {
        Left = 1,
        Right = 2,
        Center = 3,
        Bottom = 4
    }
}
