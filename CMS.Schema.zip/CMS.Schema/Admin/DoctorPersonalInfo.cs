﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Admin
{
    public class DoctorPersonalInfo
    {
        [StringLength(maximumLength: 50, MinimumLength = 3/*, ErrorMessageResourceName = "minandmax", ErrorMessageResourceType = typeof(GlobalResources)*/)]
        //[Required(/*ErrorMessageResourceName = "requiredfield", ErrorMessageResourceType = typeof(GlobalResources)*/)]
        [Display(Name = "name"/*, ResourceType = typeof(GlobalResources)*/)]
        public string Name { get; set; }

        [StringLength(maximumLength: 50, MinimumLength = 3/*, ErrorMessageResourceName = "minandmax", ErrorMessageResourceType = typeof(GlobalResources)*/)]
        //[Required(/*ErrorMessageResourceName = "requiredfield", ErrorMessageResourceType = typeof(GlobalResources)*/)]
        [Display(Name = "family"/*, ResourceType = typeof(GlobalResources)*/)]
        public string Family { get; set; }

        [StringLength(maximumLength: 50, MinimumLength = 3/*, ErrorMessageResourceName = "minandmax", ErrorMessageResourceType = typeof(GlobalResources)*/)]
        //[Required(/*ErrorMessageResourceName = "requiredfield", ErrorMessageResourceType = typeof(GlobalResources)*/)]
        [Display(Name = "specialization"/*, ResourceType = typeof(GlobalResources)*/)]
        public string Specialization { get; set; }

        [StringLength(maximumLength: 50, MinimumLength = 3/*, ErrorMessageResourceName = "minandmax", ErrorMessageResourceType = typeof(GlobalResources)*/)]
        //[Required(/*ErrorMessageResourceName = "requiredfield", ErrorMessageResourceType = typeof(GlobalResources)*/)]
        [Display(Name = "specialty"/*, ResourceType = typeof(GlobalResources)*/)]
        public string Specialty { get; set; }

        [DataType(DataType.MultilineText)]
        //[Display(/*Name = "description", ResourceType = typeof(GlobalResources)*/)]
        public string Description { get; set; }
    }

}
