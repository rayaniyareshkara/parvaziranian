﻿
namespace CMS.Schema.Staff
{
    public class CustomePageSchema
    {
        public int Id { get; set; }
        public string TitlePage { get; set; }

        public int LangId { get; set; }
        
        public string Body { get; set; }
        public string Url { get; set; }
        public string Name { get; set; }
        public bool Is_Menu { get; set; }
        public bool Is_Footer { get; set; }

        public bool IsText { get; set; }

        public string TitleText { get; set; }

        public string DescriptionText { get; set; }

        public string Image { get; set; }
        public string File1 { get; set; }
        public string File1Name { get; set; }
        public string File2 { get; set; }
        public string File2Name { get; set; }
        public string File3 { get; set; }
        public string File3Name { get; set; }
        public string Image2 { get; set; }
        public string Image2Name { get; set; }

    }
}
