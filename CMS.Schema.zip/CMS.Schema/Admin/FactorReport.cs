﻿

using System;

namespace CMS.Schema.Admin
{
    public class FactorReport
    {
        public int FId { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public int Month { get; set; }
    }
}
