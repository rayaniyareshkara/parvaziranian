﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
   public  class SurveyQuestionSchema
    {
        public int Id { get; set; }
        public string Question { get; set; }
        public string Description { get; set; }
        public string Answer1 { get; set; }
        public string Answer2 { get; set; }
        public string Answer3 { get; set; }
        public string Answer4 { get; set; }
        public int SurvayId { get; set; }
        public string SurvayName { get; set; }
    }
}
