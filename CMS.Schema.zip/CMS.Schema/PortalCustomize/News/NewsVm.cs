﻿namespace CMS.Schema.PortalCustomize.News
{
    public class NewsVm
    {
        public int Id { get; set; }

        public string Caption { get; set; }

        public string Time { get; set; }

        public string Category { get; set; }

        public string Lang { get; set; }

        public string Status { get; set; }
    }
}
