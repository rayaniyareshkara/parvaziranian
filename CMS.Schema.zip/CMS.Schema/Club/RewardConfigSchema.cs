﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
   public class RewardConfigSchema
    {
        public int NightValue { get; set; }
        public int NightCoin { get; set; }
        public bool NightIsActive { get; set; }
        public int PayRoomValue { get; set; }
        public int PayRoomCoin { get; set; }
        public bool PayRoomIsActive { get; set; }
        public int PayValue { get; set; }
        public int PayCoin { get; set; }
        public bool PayIsActive { get; set; }
        public int AddFriendValue { get; set; }
        public int AddFriendCoin { get; set; }
        public bool AddFriendIsActive { get; set; }
        public int AnswerValue { get; set; }
        public int AnswerCoin { get; set; }
        public bool AnswerIsActive { get; set; }
        public int CommentValue { get; set; }
        public int CommentCoin { get; set; }
        public bool CommentIsActive { get; set; }
        public int FixProfileValue { get; set; }
        public int FixProfileCoin { get; set; }
        public bool FixProfileIsActive { get; set; }
        public int BuySiteValue { get; set; }
        public int BuySiteCoin { get; set; }
        public bool BuySiteIsActive { get; set; }
    }
}
