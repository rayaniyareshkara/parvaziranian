﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
    public class AccessUsers
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string PageName { get; set; }
        public int? PageId { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsSelected { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? IsUpdated { get; set; }
        public bool? IsInserted { get; set; }
    }
}
