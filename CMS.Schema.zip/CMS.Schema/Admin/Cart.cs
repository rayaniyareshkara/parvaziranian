﻿

using System;

namespace CMS.Schema.Admin
{
    public class Cart
    {
        public int PID { get; set; }
        public int Count { get; set; }
        public DateTime? Date { get; set; }
        public int? Time { get; set; }
        public int Type { get; set; }
    }
}
