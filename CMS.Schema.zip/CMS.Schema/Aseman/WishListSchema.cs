﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class WishListSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Mobile { get; set; } 
        public string Email { get; set; }
        public bool? IsUsed { get; set; }
        public int? DegreeId { get; set; }
        public int? CourseId { get; set; } 
        public string DegreeName { get; set; }
        public string CourseName { get; set; }
        public string StatusName { get; set; }
        public int Status { get; set; }

       
    }
}
