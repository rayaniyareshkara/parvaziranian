﻿using System.Collections.Generic;

namespace CMS.Schema.Portal
{
    public class ListGroupSmsViewModel
    {
        public List<CMS.FrameWork.Model.SmsGroup> lstSmsGroup { get; set; }
        public List<GroupsMembers> lstGroupMembers { get; set; }
    }
}