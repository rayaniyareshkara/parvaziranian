﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class ExaminerAddSchema
    {
        public int Id { get; set; }
        public string Password { get; set; }
        public int  ExamCenterId  { get; set; }
        public Guid UserId { get; set; }
        public bool Isactive { get; set; }
       
    }
}
