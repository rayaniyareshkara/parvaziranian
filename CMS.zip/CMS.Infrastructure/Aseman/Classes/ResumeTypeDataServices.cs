﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
 public class ResumeTypeDataServices : ConversionMain<ResumeType, int>, IResumeType
    {
        public ResumeTypeDataServices(EntitysModelCMS context) : base(context)
        {
        }

        public override Expression<Func<ResumeType, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
