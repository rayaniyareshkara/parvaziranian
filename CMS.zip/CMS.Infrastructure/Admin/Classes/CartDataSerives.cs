﻿
using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Admin.Interfaces;

namespace CMS.Infrastructure.Admin.Classes
{
    public class CartDataSerives : ConversionMain<Cart, int>, ICart
    {
        public CartDataSerives(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<Cart, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
