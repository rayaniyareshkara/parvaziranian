﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Public
{
public    class CategoryShowSchema
    {
        public string Id { get; set; }
        public string Key { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public int Count { get; set; }
    }
}
