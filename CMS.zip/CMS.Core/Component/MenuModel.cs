﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Schema.Admin;
using System.Data;

using CMS.FrameWork.Model;

namespace CMS.Core.Component
{
    public class MenuModel
    {
        public class MenuJson
        {
            public class DataObj
            {
                public DataObj()
                {
                    TitleinLanguages = new Dictionary<string, string>();
                    UrlinLanguages = new Dictionary<string, string>();
                }

                public Guid Id { get; set; }

                public int Order { get; set; }
                public Dictionary<string, string> TitleinLanguages { get; set; }

                public Dictionary<string, string> UrlinLanguages { get; set; }
                public bool? IsUrlEditable { get; set; }
                public List<DataObj> Nodes { get; set; }

                public string Source { get; set; }
                public Guid? SourceKey { get; set; }

                public Guid? ParentId { get; set; }
            }

            public List<DataObj> Data { get; set; }

            public List<string> Inserted { get; set; }

            public List<string> Deleted { get; set; }

            public List<string> MyProperty { get; set; }
        }

        public MenuModel.MenuJson GenerateMenuJson(Menu[] menus, FrameWork.Model.Language[] languages)
        {
            MenuModel.MenuJson menuJson = new MenuModel.MenuJson { Data = RecursiveGenerateNode(menus, languages, null) };
            return menuJson;
        }

        public List<MenuModel.MenuJson.DataObj> RecursiveGenerateNode(Menu[] menus, FrameWork.Model.Language[] languages, Guid? parentId)
        {
            List<MenuModel.MenuJson.DataObj> json = new List<MenuModel.MenuJson.DataObj>();

            var parentMenus = menus.Where(m => m.ParentId == parentId).OrderBy(m => m.Order).GroupBy(g => g.Id).Select(s => s.First()).ToArray();

            foreach (var menu in parentMenus)
            {
                MenuModel.MenuJson.DataObj node = new MenuModel.MenuJson.DataObj
                {
                    Id = menu.Id,
                    IsUrlEditable = !menu.Default,
                    Source = menu.Source,
                    SourceKey = menu.SourceKey
                };
                foreach (var lang in languages)
                {
                    var tmp = menus.FirstOrDefault(m => m.LanguageId == lang.Id && m.Id == menu.Id);
                    if (tmp != null)
                    {
                        node.UrlinLanguages.Add(lang.Id.ToString(), tmp.Url);
                        node.TitleinLanguages.Add(lang.Id.ToString(), tmp.Title);
                    }
                }
                node.Nodes = RecursiveGenerateNode(menus, languages, menu.Id);
                json.Add(node);
            }
            return json;
        }

        //public void UpdateMenues(MenuModel.MenuJson data)
        //{
        //    //var menusToDelete = _context.Menu.Where(m => data.Deleted.Contains(m.Id.ToString()));
        //    //if (menusToDelete.Any())
        //    //{
        //    //    _context.Menu.RemoveRange(menusToDelete);
        //    //    _context.SaveChanges();
        //    //}


        //    //List<MenuSchema> menus = RecursiveConvertDataObjToMenu(data.Data);

        //    //if (menus.Any())
        //    //{
        //    //    _context.Menu.AddOrUpdate(menus.ToArray());
        //    //    _context.SaveChanges();
        //    //}
        //}

        public List<MenuSchema> RecursiveConvertDataObjToMenu(List<MenuModel.MenuJson.DataObj> data)
        {
            var menus = new List<MenuSchema>();
            foreach (var dataObj in data)
            {
                foreach (var lang in dataObj.TitleinLanguages.Keys)
                {
                    MenuSchema menu = new MenuSchema()
                    {
                        Id = dataObj.Id,
                        Url = dataObj.UrlinLanguages[lang],
                        Title = dataObj.TitleinLanguages[lang],
                        Order = dataObj.Order,
                        ParentId = dataObj.ParentId,
                        Source = dataObj.Source,
                        SourceKey = dataObj.SourceKey,
                        Language = Convert.ToInt32(lang)
                    };
                    menus.Add(menu);
                }

                if (dataObj.Nodes != null && dataObj.Nodes.Any())
                {
                    menus.AddRange(RecursiveConvertDataObjToMenu(dataObj.Nodes));
                }
            }

            return menus;
        }


    }
}