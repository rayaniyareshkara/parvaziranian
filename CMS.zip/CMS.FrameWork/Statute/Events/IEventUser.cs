﻿
namespace CMS.FrameWork.Statute.Events
{
    public interface IEventUser
    {
        int Id { get; set; }
        string Message { get; set; }
        string HelpLink { get; set; }
        int HResult { get; set; }
        string Source { get; set; }
        string StackTrace { get; set; }
    }
}
