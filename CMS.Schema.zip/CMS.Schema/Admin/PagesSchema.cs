﻿
namespace CMS.Schema.Admin
{
    using System.Web.Mvc;

    public class PagesSchema
    {
        public System.Guid Id { get; set; }
        public string Url { get; set; }
        public bool InMenu { get; set; }
        public string PageTitle { get; set; }
        [AllowHtml]
        public string Content { get; set; }
        public string Meta { get; set; }
        public int? LanguageId { get; set; }
        public string Tag { get; set; }
        public string charset { get; set; }
        public string description { get; set; }
        public string keywords { get; set; }
        public string author { get; set; }
        public string copyright { get; set; }
        public string robots { get; set; }
        public string content_language { get; set; }
        public int? GalleryId { get; set; }
        public bool IsActive { get; set; }
    }
}
