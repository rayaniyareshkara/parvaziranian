﻿namespace CMS.Schema.PortalCustomize.ArticleUi
{
    public class TagWordVm
    {
        public string Title { get; set; }
    }
}
