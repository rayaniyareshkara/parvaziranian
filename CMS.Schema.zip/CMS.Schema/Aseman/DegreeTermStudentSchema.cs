﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class DegreeTermStudentSchema
    {
        public int Id { get; set; }
        public string Name { get; set; } 
        public string Family { get; set; } 
        public string DegreeName { get; set; } 
        public string BranchName { get; set; } 
        public int StatusId { get; set; } 
        public string Status { get; set; }

        public string Description { get; set; }


    }
}
