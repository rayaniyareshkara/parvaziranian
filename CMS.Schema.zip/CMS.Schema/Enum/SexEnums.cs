﻿namespace CMS.Schema.Enum
{
    public enum SexEnums
    {
        Men = 1,
        Women = 2
    }

}
