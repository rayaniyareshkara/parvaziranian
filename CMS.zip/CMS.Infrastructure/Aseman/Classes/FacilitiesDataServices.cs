﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
    public class FacilitiesDataServices : ConversionMain<Facility, int>, IFacilities
    {
        public FacilitiesDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<Facility, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
