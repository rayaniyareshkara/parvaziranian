﻿
namespace CMS.Schema.Mohandesan
{
    public class LinkSchema
    {
        public int Id { get; set; }
        public string NewLink { get; set; }
        public string PreviewsLink { get; set; }
    }
}
