﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class DegreeTermSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string BranchName { get; set; }
        public string DegreeName { get; set; }
        public string Status { get; set; } 
        public int StatusId { get; set; }


    }
}
