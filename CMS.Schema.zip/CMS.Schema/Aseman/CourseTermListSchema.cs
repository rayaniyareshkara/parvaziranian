﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
    public class CourseTermListSchema
    {
        public int Id { get; set; }
        public string CourseName { get; set; }
        public int CourseId { get; set; }
        public string CourseTermName { get; set; }
        public string Status { get; set; }
        public int StatusId { get; set; }
        public List<SourceDetail> SourceList { get; set; }

    }
    public class SourceDetail
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string File { get; set; }
        public string Description { get; set; }
        public string Owner { get; set; }

    }

}
