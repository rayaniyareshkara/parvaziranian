﻿namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class NewsListPaginationVm
    {
        public string Url { get; set; }

        public string Title { get; set; }

        public string Summery { get; set; }

        public string Image { get; set; }

        public string Category { get; set; }
        public string Time { get; set; }
    }
}
