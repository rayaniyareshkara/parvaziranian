﻿using System;
using System.Globalization;
namespace CMS.Core.Component
{
    public class PersianMonth
    {
        public class ResultDate
        {
            public string Month { get; set; }
            public int Day { get; set; }
            public int Year { get; set; }
        }
        public static readonly string[] Month = { "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند" };

        public static readonly int[] IntMonth = { 1, 2,3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };

        public static string GetMonth(DateTime dt)
        {
            try
            {
                PersianCalendar pc = new PersianCalendar();

                var persianDate = new DateTime(pc.GetYear(dt), pc.GetMonth(dt), pc.GetDayOfMonth(dt));

                return Month[persianDate.Month - 1];
            }
            catch (Exception)
            {

                return Month[0];
            }
        }


        public static ResultDate GToDate(DateTime dt)
        {
            try
            {
                PersianCalendar pc = new PersianCalendar();

                var persianDate = new DateTime(pc.GetYear(dt), pc.GetMonth(dt), pc.GetDayOfMonth(dt));

                return new ResultDate { Day = persianDate.Day , Month = Month[persianDate.Month - 1] , Year = persianDate.Year };
            }
            catch (Exception )
            {
                return new ResultDate { };
            }
        }

        public static int GetNumMonth(DateTime dt)
        {
            try
            {
                PersianCalendar pc = new PersianCalendar();

                var persianDate = new DateTime(pc.GetYear(dt), pc.GetMonth(dt), pc.GetDayOfMonth(dt));

                return IntMonth[persianDate.Month - 1];
            }
            catch (Exception)
            {

                return IntMonth[0];
            }
        }

    }
}
