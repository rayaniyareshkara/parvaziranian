﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
    [Serializable]
    public class bankViewModel
    {
        public bankViewModel()
        {
            this.mellat = new MellatShema();
            this.zarrin = new ZarrinPalSchema();
            this.parsian = new ParsianSchema();
            this.saman = new SamanSchema();
            this.AsanPardakht = new AsanPardakht();
            this.Pasargad = new PasargadShema();

        }
        public MellatShema mellat { get; set; }
        public ZarrinPalSchema zarrin { get; set; }
        public ParsianSchema parsian { get; set; }
        public SamanSchema saman { get; set; }
        public AsanPardakht AsanPardakht { get; set; }
        public PasargadShema Pasargad { get; set; }


        public SamanSchema saman_shiraz { get; set; }
        public SamanSchema saman_tehran { get; set; }
        public SamanSchema saman_bandar { get; set; }
        public SamanSchema saman_khayam { get; set; }
        public SamanSchema saman_ahmad { get; set; }

    }
}
