﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;

using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
   public class LibraryDataServices : ConversionMain<Library, int>, ILibrary
    {
        public LibraryDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<Library, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
