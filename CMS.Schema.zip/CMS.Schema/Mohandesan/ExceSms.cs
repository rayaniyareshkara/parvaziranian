﻿
namespace CMS.Schema.Mohandesan
{
  public  class ExceSmsSchema
    {
        public int Id { get; set; }
        public string Phone { get; set; }
        public string Code { get; set; }
    }
}
