﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CMS.Schema.PortalAmio.Place
{
    public class PlacesCrudVm
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        [DisplayName("عنوان")]
        public string Title { get; set; }
        [DisplayName("فعال/غیرفعال")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public bool Status { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(500, ErrorMessage = "{0} طول نمی تواند بیشتر از 500 حروف باشد")]
        [DisplayName("خلاصه متن")]
        public string Summery { get; set; }
        [DisplayName("آدرس")]
        [StringLength(300, ErrorMessage = "{0} طول نمی تواند بیشتر از 300 حروف باشد")]
        public string Address { get; set; }
        [AllowHtml]
        public string Description { get; set; }
        [DisplayName("عرض جفرافیایی")]
        public string Latitude { get; set; }
        [DisplayName("طول جفرافیایی")]
        public string Longitude { get; set; }
        [DisplayName("تصویر")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]
        public string Image { get; set; }

        [DisplayName("کلمات کلیدی")]
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        public string MetaKeyWord { get; set; }
        [DisplayName("عنوان صفحه")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد ")]
        public string PageTitle { get; set; }
        [DisplayName("توضحیات برای گوگل")]
        [StringLength(500, ErrorMessage = "{0} طول نمی تواند بیشتر از 500 حروف باشد ")]
        public string MetaDescription { get; set; }
        [DisplayName("آدرس")]
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد ")]
        public string Url { get; set; }

        [DisplayName("زبان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int Lang { get; set; }
    }
}
