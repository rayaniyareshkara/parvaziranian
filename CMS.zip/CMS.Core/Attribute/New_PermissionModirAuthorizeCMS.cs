﻿using CMS.Core.Component;
using CMS.Schema.Admin;
using System;
using System.Linq;
using System.Web.Mvc;

namespace CMS.Core.Attribute
{
    public class New_PermissionModirAuthorizeCMS : ActionFilterAttribute, IActionFilter
    {
        private readonly int PageId;
        private readonly string Root;
        private readonly string Code;
        private CMS.FrameWork.Model.EntitysModelCMS db = new FrameWork.Model.EntitysModelCMS();
        private Guid UserId;
        private readonly PermissonEnum Type;
        public New_PermissionModirAuthorizeCMS(int pageId, PermissonEnum Type, string Root = "view")
        {
            try
            {
                this.Root = Root.ToLower();
                this.PageId = pageId;
                this.Type = Type;
                //   var db = new CMS.FrameWork.Model.EntitysModelCMS();
                if (SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }) != null)
                {
                    var activeId = Guid.Parse(SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }).ActiveCode);
                    this.Code = activeId.ToString();
                    this.UserId = db.UsersActiveCookies.Where(x => x.ActiveId == activeId).FirstOrDefault().UsersSiteId;
                }
            }
            catch (Exception)
            {
                SetCookie.DeleteCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS });
            }
        }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                
                    bool hasPermision = (bool)db.CheckPermissions(this.Code, filterContext.HttpContext.Request.UserHostAddress, PageId, Type.ToString()).FirstOrDefault();
                   if (hasPermision == false)
                    {
                        if (Root == "view")
                        {
                            var viewResult = new ViewResult
                            {
                                ViewName = "~/Areas/Modir/Views/Error/Error403.cshtml",
                            };
                            filterContext.Result = viewResult;
                        }
                        else if (Root == "json")
                        {
                            var Result = new JsonResult
                            {
                                Data = "error",
                                JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                            };
                            filterContext.Result = Result;
                        }
                        else
                        {
                            var viewResult = new PartialViewResult
                            {
                                ViewName = "~/Areas/Modir/Views/Error/ChildError403.cshtml",
                            };
                            filterContext.Result = viewResult;
                        }
                    }
                
            
            }
            catch (Exception)
            {
                //filterContext.Result = new RedirectResult("/fa/Account/Login?returnUrl=" + filterContext.HttpContext.Request.CurrentExecutionFilePath);
            }

            base.OnActionExecuting(filterContext);

        }
    }
}
