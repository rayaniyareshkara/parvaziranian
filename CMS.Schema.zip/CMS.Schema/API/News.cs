﻿using System;


namespace CMS.Schema.API
{
    public class News
    {
        public Guid Id{ get; set; }
        public int IntId { get; set; }
        public string Title { get; set; }
        public string Header { get; set; }
        public string  TypeId { get; set; }
        public string Summery { get; set; }
        public string Body { get; set; }

        public string Image { get; set; }

    }
}
