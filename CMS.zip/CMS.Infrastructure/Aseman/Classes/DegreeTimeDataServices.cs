﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class DegreeTimeDataServices : ConversionMain<DegreeTime, int>, IDegreeTime
    {
        public DegreeTimeDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<DegreeTime, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
