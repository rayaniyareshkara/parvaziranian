﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
 public   class ImportExcelSchema
    {
        public string ImImgFile { get; set; }
        public bool smsSend { get; set; }
        public int ClubId { get; set; }
    }
}
