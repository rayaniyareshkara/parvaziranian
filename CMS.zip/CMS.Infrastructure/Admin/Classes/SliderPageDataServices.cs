﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Admin.Interfaces;

namespace CMS.Infrastructure.Admin.Classes
{
 public   class SliderPageDataServices : ConversionMain<SliderPage, int>, ISliderPage
    {
        public SliderPageDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<SliderPage, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
