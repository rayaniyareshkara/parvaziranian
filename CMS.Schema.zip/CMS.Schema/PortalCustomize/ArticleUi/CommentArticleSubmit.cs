﻿using CMS.Schema.Global;

namespace CMS.Schema.PortalCustomize.ArticleUi
{
    public class CommentArticleSubmit : CommentSubmit
    {
        public int ArticleId { get; set; }
    }
}
