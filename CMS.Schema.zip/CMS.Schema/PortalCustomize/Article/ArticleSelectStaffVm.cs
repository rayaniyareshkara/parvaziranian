﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Schema.Global;

namespace CMS.Schema.PortalCustomize.Article
{
    public class ArticleSelectStaffVm : GlobalGridSchema
    {
        public int? CategoryId { get; set; }

    }
}
