﻿
namespace CMS.Schema.Hotel
{
    public class ServiceInfoSchema 
    {
        public int Id { get; set; }
        public int Price { get; set; }
        public int BuyCount  { get; set; }
        public int ComeCount { get; set; }
    }
}
