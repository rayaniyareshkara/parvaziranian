﻿namespace CMS.Schema.PortalAmio.Dashboard
{
    public class CrudRequestStand
    {
        public int Id { get; set; }

        public string FullNameFa { get; set; }

        public string FullNameEn { get; set; }

        public string File { get; set; }

        public int ExhibitionId { get; set; }

        public int StandReserveId { get; set; }
    }

    public class CrudCardIssuanceRequest
    {
        public int Id { get; set; }

        public int Number { get; set; }

        public int ExhibitionId { get; set; }

        public string Description { get; set; }

        public int StandReserveId { get; set; }

    }
}
