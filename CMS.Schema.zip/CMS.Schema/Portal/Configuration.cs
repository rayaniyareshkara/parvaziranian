﻿using System;

namespace CMS.Schema.Portal
{
    [Serializable()]
    public class Configuration
    {
        public Email EmailConfig { get; set; }

        //تنظیمات کلی
        private string _startDate;

        public string StartDate
        {
            get { return Cypher.Decrypt(_startDate); }
            set { _startDate = Cypher.Encrypt(value); }
        }

        private string _contentConnectionString;

        public string ContentConnectionString
        {
            get { return Cypher.Decrypt(_contentConnectionString); }
            set { _contentConnectionString = Cypher.Encrypt(value); }
        }



        private string _logConnectionString;

        public string LogConnectionString
        {
            get { return _logConnectionString; }
            set { _logConnectionString = value; }
        }

        private string _managementConnectionString;

        public string ManagementConnectionString
        {
            get { return _managementConnectionString; }
            set { _managementConnectionString = value; }
        }

        //پایان تنظیمات کلی

        public Sms SmsConfig { get; set; }
        public MellatShema MellatConfig { get; set; }
        public ParsianSchema ParsianConfig { get; set; }
        public ZarrinPalSchema ZarrinConfig { get; set; }
        public SamanSchema SamanConfig { get; set; }
        public SamanSchema saman_shiraz { get; set; }
        public SamanSchema saman_tehran { get; set; }
        public SamanSchema saman_bandar { get; set; }
        public SamanSchema saman_khayam { get; set; }
        public SamanSchema saman_ahmad { get; set; }
        public ExhibitionInFo ExhibitionConfig { get; set; }
        public bool WithoutPay { get; set; }

    }


    
}