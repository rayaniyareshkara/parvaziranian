﻿namespace CMS.Schema.Global
{
    public class SearchLocationBook
    {
        public string Caption { get; set; }

        public bool? Status { get; set; }
    }
}