﻿
namespace CMS.Schema.Hotel
{
    public class HotelRulesSchema
    {
        public int Id { get; set; }
        public string Header { get; set; }
        public string Description { get; set; }
        public int HotelId { get; set; }
        public string Icon { get; set; }
    }
}
