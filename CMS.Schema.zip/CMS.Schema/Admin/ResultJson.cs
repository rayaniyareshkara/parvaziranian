﻿
namespace CMS.Schema.Admin
{
    public class ResultJson
    {
        public string TypeResult { get; set; }
        public string MeesageResult { get; set; }
        public bool ValidEmail { get; set; }
        public bool ValidUserName { get; set; }
        public string UserId { get; set; }
        public string RedirectUrl { get; set; }

    }
}
