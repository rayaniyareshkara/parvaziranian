﻿using CMS.Schema.Global;

namespace CMS.Schema.PortalCustomize.News
{
    public class NewsSelectStaffVm : GlobalGridSchema
    {
        public int? CategoryId { get; set; }
    }
}
