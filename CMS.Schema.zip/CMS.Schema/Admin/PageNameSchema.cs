﻿
namespace CMS.Schema.Admin
{
    public class PageNameSchema
    {
        public int Id { get; set; }
        public int? PageMakerId { get; set; }
        public string PagesNames { get; set; }
        public bool Flag { get; set; }
    }
}
