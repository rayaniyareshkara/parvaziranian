﻿namespace CMS.Schema.PortalCustomize.Article
{
    public class ArticleStaffSchema
    {
        public int Id { get; set; }

        public string Caption { get; set; }

        public string Time { get; set; }

        public string Category { get; set; }

        public string Lang { get; set; }

        public string Status { get; set; }
    }
}
