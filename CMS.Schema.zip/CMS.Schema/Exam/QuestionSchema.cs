﻿using System;

namespace CMS.Schema.Exam
{
 public  class QuestionSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string Code { get; set; }
        public string Image { get; set; }
        public string Video { get; set; }
        public string audio { get; set; }
        public int HeadLineId { get; set; }
        public int TypeId { get; set; }
        public int HardshipId { get; set; }
        public int LanguageId { get; set; }
        public string TypeName { get; set; }


        public DateTime CreateDate { get; set; }
       
    }
}
