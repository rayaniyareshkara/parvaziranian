﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class FinanceTypeSchema
    {
        public int Id { get; set; }
        public string Image { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Amount { get; set; }
        public int? FinaceTypeId { get; set; }
        public string FinaceTypeName { get; set; }
        public bool IsSee { get; set; }
        public Guid UserId { get; set; }
        public string UserName { get; set; }
      
    }
}
