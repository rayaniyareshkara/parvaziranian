﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
    [Serializable]
    public class ParsianSchema
    {
        private string _pin;
        public string pin
        {
            get { return Cypher.Decrypt(_pin); }
            set { _pin = Cypher.Encrypt(value); }
        }

        private string _Password;
        public string Password
        {
            get { return Cypher.Decrypt(_Password); }
            set { _Password = Cypher.Encrypt(value); }
        }
        public bool IsActive { get; set; }
    }
}
