﻿

namespace CMS.Schema.Hall
{
    public class LayoutItemSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int? Capacity { get; set; }
        public string Image { get; set; }
    }
}
