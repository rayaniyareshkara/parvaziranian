﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public  class FinanceDocTypeSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
      
    }
}
