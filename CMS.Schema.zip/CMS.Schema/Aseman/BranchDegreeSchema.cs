﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class BranchDegreeSchema
    {
        public int Id { get; set; }
        public string DegreeName { get; set; }
        public string Description { get; set; }
    }
}
