﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
    public class ExamFrameSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string Code { get; set; }
        public int Duration { get; set; }
        public decimal NegativePoint { get; set; }
        public int MaxPoint { get; set; }
        public int acceptablePoint { get; set; }
        public string RandomQuestion { get; set; }
        public string Maxquestion { get; set; }
        public bool IsRemote { get; set; }
        public string IsInvigilator { get; set; }
        public string Image { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }      
        public int ExamTypeId { get; set; }       
     
        public int ExamHardShipId { get; set; }

        public string ExamHardShipName { get; set; }
        public string ExamTypeName { get; set; }
    }
}
