﻿

namespace CMS.Schema.Hotel
{
    public class PartnersSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public string Link { get; set; }
    }
}
