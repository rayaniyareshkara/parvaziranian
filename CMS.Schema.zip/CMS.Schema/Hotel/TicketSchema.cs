﻿

using System;
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class TicketSchema
    {
        public string FullName { get; set; }
        public string Title { get; set; }
        public DateTime RunDate { get; set; }
        public DateTime BuyDate { get; set; }
        public string Data { get; set; }
        public string Time { get; set; }
        public string Phone { get; set; }
        public string Map { get; set; }
        public int Count { get; set; }
        public int status { get; set; }
        public string TicketCode { get; set; }
        public string Code { get; set; }
        public int Id { get; set; }
        public string NationalCode { get; set; }
        public string Address { get; set; }
        public int Product { get; set; }
        public string Info { get; set; }
        public string Image { get; set; }
        public string Hotel { get; set; }
        public int Price { get; set; }

    }

    public class TicketRoomSchema
    {
        public TicketRoomSchema()
        {
            items = new List<TicketRoomItemsSchema>();
            PercePerDay = new List<Tuple<string, string>>();
        }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public string Title { get; set; }
        public DateTime StartDate { get; set; }
        public string AdditionalDescription { get; set; }
        public string VacherDescription { get; set; }
        public bool LateLeave { get; set; }
        public DateTime EndDate { get; set; }
        public string Fax { get; set; }
        public int Status { get; set; }
        public string Agent { get; set; }
        public string Phone { get; set; }
        public string OrderId { get; set; }
        public string Address { get; set; }
        public string Map { get; set; }
        public DateTime BuyDate { get; set; }
        public bool IsExtensions { get; set; }
        public bool EarlyArrival { get; set; }
        public string Code { get; set; }
        public string Image { get; set; }
        public string Hotel { get; set; }
        public int Price { get; set; }
        public List<TicketRoomItemsSchema> items { get; set; }
        public string Rooms { get; set; }
        public string Guests { get; set; }
        public string Feature { get; set; }
        public string RefAgency { get; set; }
        public List<Tuple<string, string>> PercePerDay { get; set; }
    }



    public class TicketRoomItemsSchema
    {
        public TicketRoomItemsSchema()
        {
            GeuestInfo = new List<Info>();
        }
        public string Title { get; set; }
        public string RoomName { get; set; }
        public int RoomCount { get; set; }
        public string Guests { get; set; }
        public int Price { get; set; }
        public List<Info> GeuestInfo { get; set; }
        public int AdditionalPersonCount { get; set; }
        public int ChildAdditionalPersonCount { get; set; }
        public string Features { get; set; }
        public string Reservator { get; set; }
    }
}
