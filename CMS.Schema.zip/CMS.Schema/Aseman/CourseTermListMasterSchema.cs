﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
    public class CourseTermListMasterSchema
    {
        public int Id { get; set; }
        public string CourseName { get; set; }
        public int CourseId { get; set; }
        public string CourseTermName { get; set; }
        public string DegreeTermName { get; set; }
        public string MasterName { get; set; }
        public string Status { get; set; }
        public string MasterImage { get; set; }
        public bool IsSurvey { get; set; }
        public int StatusId { get; set; }
        public List<ClassDetail> ClassList { get; set; }

    }
    public class ClassDetail
    {
        public int Id { get; set; } 
        public DateTime StartDateMain { get; set; }
        public DateTime EndDateMain { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public int Status { get; set; }
        public string StatusName { get; set; }

    }

}
