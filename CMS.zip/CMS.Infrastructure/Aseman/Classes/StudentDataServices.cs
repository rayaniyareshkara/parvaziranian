﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;



namespace CMS.Infrastructure.Aseman.Classes
{
 public   class StudentDataServices : ConversionMain<Student, int>, IStudent
    {
        public StudentDataServices(EntitysModelCMS context) : base(context)
        {
        }

        public override Expression<Func<Student, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
