﻿
namespace CMS.Schema.Hotel
{
    public class SideBarSchema
    {
        public string Name { get; set; }
        public string Image { get; set; }
        public int TicketCounts { get; set; }
        public int CommentCounts { get; set; }
    }
}
