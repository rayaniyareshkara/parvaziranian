﻿using System;

namespace CMS.Schema.PortalCustomize.Users
{
    public class DetailsTypeRegisterVm
    {
        public Guid UserId { get; set; }

        public string Time { get; set; }

        public string Type { get; set; }
    }
}
