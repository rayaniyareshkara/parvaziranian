﻿
namespace CMS.Schema.Admin
{
    public class Property_AccessPage_Users
    {
        public int Id { get; set; }
        public string PageName { get; set; }
        public string UserSiteRole_UserName { get; set; }
        public bool IsInserted { get; set; }
        public bool IsUpdated { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsRead { get; set; }
        public string UsersSite_Name { get; set; }
        public string RoleName { get; set; }
    }
}
