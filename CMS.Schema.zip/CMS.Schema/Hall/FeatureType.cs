﻿

using System.ComponentModel;

namespace CMS.Schema.Hall
{
    public enum FeatureType
    {
        Feature = 1,
        Service = 2,
        Other = 3,
        Property = 4
    }

    public enum MealType
    {
        [Description("صبحانه")]
        BreakFast = 1,
        [Description("ناهار")]
        Lunch = 2,
        [Description("شام")]
        Dinner = 3,
        [Description("افطار")]
        Iftar = 4,
        [Description("میان وعده صبح")]
        Morning_Snack =5 ,
        [Description("میان وعده عصر")]
        Evening_Snack = 6,
    }

    public enum ServePlace
    {
        [Description("داخل")]
        In = 1,
        [Description("بیرون")]
        Out = 2,
    }

    public enum OtherPlan
    {
        [Description("تور شهری")]
        Tour = 1,
        [Description("اقامت در هتل")]
        BookingHotel = 2,
        [Description("ترانسفر رفت و برگشت ميهمانان( هوايي يا زمينی )")]
        TransferGuest = 3,
    }
}
