﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Admin.Interfaces;

namespace CMS.Infrastructure.Admin.Classes
{
    public class AlbumDataServices : ConversionMain<Album, int> , IAlbum
    {
        public AlbumDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<Album, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
