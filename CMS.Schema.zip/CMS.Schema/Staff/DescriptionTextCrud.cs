﻿namespace CMS.Schema.Staff
{
    public class DescriptionTextCrud
    {
        public int Id { get; set; }

        public string Caption { get; set; }

        public int ExhibitionId { get; set; }

        public int IdRow { get; set; }

        public string Description { get; set; }
    }
}