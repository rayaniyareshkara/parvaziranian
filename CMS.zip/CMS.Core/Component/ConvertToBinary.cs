﻿
namespace CMS.Core.Component
{
    using System.Text;

    public static class ConvertToBinary
    {
        public static byte[] UnicodeStringToByteArray(string source) => Encoding.Unicode.GetBytes(new EncodeAndDecode().Encode(source));
    }
}
