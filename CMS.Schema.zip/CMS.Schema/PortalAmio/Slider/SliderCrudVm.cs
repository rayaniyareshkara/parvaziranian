﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalAmio.Slider
{
    public class SliderCrudVm
    {

        public int Id { get; set; }
        [DataType(DataType.Upload)]
        [Display(Name = "تصویر اسلایدر")]
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]
        public string Image { get; set; }
        [Display(Name = "نمایشگاه")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int ExhibitionId { get; set; }
        [DisplayName("زبان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int Lang { get; set; }
        [Display(Name = "متن دلخواه پایین صفحه")]
        [StringLength(300, ErrorMessage = "{0} طول نمی تواند بیشتر از 300 حروف باشد")]
        public string CustomText { get; set; }
        [Display(Name = "متن دلخواه یک")]
        [StringLength(300, ErrorMessage = "{0} طول نمی تواند بیشتر از 300 حروف باشد")]
        public string CustomHeader { get; set; }
        [Display(Name = "متن دلخواه دو")]
        [StringLength(300, ErrorMessage = "{0} طول نمی تواند بیشتر از 300 حروف باشد")]
        public string CustomHeaderTwo { get; set; }

        public int? IdRow { get; set; }


    }
}
