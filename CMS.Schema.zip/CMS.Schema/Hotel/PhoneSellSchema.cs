﻿
namespace CMS.Schema.Hotel
{
    public class PhoneSellSchema
    {
        public int Id { get; set; }
        public string Event { get; set; }
        public string Description{ get; set; }
        public string Date { get; set; }
        public int Count { get; set; }
    }
}
