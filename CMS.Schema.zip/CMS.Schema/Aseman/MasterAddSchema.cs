﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class MasterAddSchema
    {
        public int Id { get; set; }

        public string NationalCode { get; set; }
        public string IdNumber { get; set; }
        public string FatherName { get; set; }

        public string BirthPlace { get; set; }
        public string PassportNumber { get; set; }
        public int? PassportIssuingCountry { get; set; }
        public string HomeAddress { get; set; }
        public string EmergancyAddress { get; set; }
        public string EmergancyName { get; set; }
        public string EmergancPhone { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyName { get; set; }
        public string CompanyPhone { get; set; }
        public string Image { get; set; }
        public string Image2 { get; set; }
        public string BirthCert1 { get; set; }
        public string BirthCert2 { get; set; }
        public string BirthCert3 { get; set; }
        public string NationalCard { get; set; }
        public string DegreeImage { get; set; }
        public string Resume { get; set; }
        public int? CountryId { get; set; }
        public bool IsActive { get; set; }

        //userssite
        public Guid UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public DateTime? BirthDate { get; set; }
        public string UserName { get; set; }
        public string Title { get; set; }
        public string Header { get; set; }
        public string Password { get; set; }
        public byte Sex { get; set; }     
        public string Description { get; set; }

    }
}
