﻿using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class RegisterCartSchema
    {
        public string FullName { get; set; }

        public string FatherName { get; set; }

        public string IdCertificate { get; set; }


        public string DateOfBirth { get; set; }

        public string PlaceOfBirth { get; set; }


        public string Nationality { get; set; }

        public string Email { get; set; }

        public string Job { get; set; }

        public string PhoneNumber { get; set; }

        public string Address { get; set; }

        public string EntryDate { get; set; }

        public string ExitDate { get; set; }

        public string CarType { get; set; }

        public string LicensePlate { get; set; }

        public string IntentionToTravel { get; set; }

        public int Id { get; set; }

        public int RoomNumber { get; set; }

        public string RoomType { get; set; }

        public string Reception { get; set; }

        public string CompanyName { get; set; }

        public string Book { get; set; }

        public int CountComrade { get; set; }

        public string Prepayment { get; set; }

        public int Counter { get; set; }

        public string Receiver { get; set; }

        public int FamiliarHotelSelected { get; set; }

        public List<int> VehicleSelected { get; set; }

        public string Residence { get; set; }
        public IEnumerable<DropDownComradeSchema> FamiliarHotel { get; set; }
        public IEnumerable<DropDownComradeSchema> Vehicles { get; set; }

    }
}
