﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class ResetPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = @"ایمیل")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = @"رمزعبور")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = @"تکرار رمزعبور")]
        [Compare(@"رمزعبور", ErrorMessage = @"رمز جدید و تکرار رمز جدید تکسان نیست")]
        public string ConfirmPassword { get; set; }

        public string Code { get; set; }
    }

}
