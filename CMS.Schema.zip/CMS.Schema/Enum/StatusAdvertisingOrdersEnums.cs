﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Enum
{
    public enum StatusAdvertisingOrdersEnums : byte
    {
        [Display(Name = "تایید")]
        OnlinePayment = 3,
        [Display(Name = "غیر تایید")]
        PaymentByReceipt = 4
    }

}
