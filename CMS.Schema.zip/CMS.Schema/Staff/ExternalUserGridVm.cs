﻿using System;

namespace CMS.Schema.Staff
{
    public class ExternalUserGridVm
    {
        public Guid UserId  { get; set; }


        public string CompanyName { get; set; }

        public string ContactPerson { get; set; }

        public string SkypeId { get; set; }

        public string WebSite { get; set; }

        public string PhoneNumber { get; set; }

        public string EmailId { get; set; }

        public string StandSize { get; set; }

        public string Country { get; set; }

        public string RelatedPerson { get; set; }
    }
}
