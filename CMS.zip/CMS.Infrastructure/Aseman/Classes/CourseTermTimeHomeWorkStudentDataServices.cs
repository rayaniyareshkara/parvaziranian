﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;

using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
   public class CourseTermTimeHomeWorkStudentDataServices : ConversionMain<CourseTermTimeHomeWorkStudent, int>, ICourseTermTimeHomeWorkStudent
    {
        public CourseTermTimeHomeWorkStudentDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CourseTermTimeHomeWorkStudent, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
