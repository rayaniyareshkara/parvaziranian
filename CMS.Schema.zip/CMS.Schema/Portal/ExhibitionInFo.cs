﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
   [Serializable()]
 public   class ExhibitionInFo
    {
        public int ExhibitionMainId { get; set; }
        public string ExhibitionMainKey { get; set; }
        public int ExhibitionIdEn { get; set; }
        public int ExhibitionIdfa { get; set; }
        public string   DefaultLang { get; set; }

    }
}
