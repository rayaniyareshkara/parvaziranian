﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class HeadLineShowSchema
    {
        public int Id { get; set; } 
        public int HeadLineId { get; set; }
        public int Status { get; set; }
       public string StatusName { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime CreateDate { get; set; }
        public List<headlineSource> HeadLineSourceList { get; set; }
    }
    public class headlineSource
    {
        public int Id { get; set; }
        public string File { get; set; }
     
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
