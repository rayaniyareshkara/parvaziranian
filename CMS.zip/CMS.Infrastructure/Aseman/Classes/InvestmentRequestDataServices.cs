﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class InvestmentRequestDataServices : ConversionMain<InvestmentRequest, int>, IInvestmentRequest
    {
        public InvestmentRequestDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<InvestmentRequest, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
