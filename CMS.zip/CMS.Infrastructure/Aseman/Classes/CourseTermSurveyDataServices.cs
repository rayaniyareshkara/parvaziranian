﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class CourseTermSurveyDataServices : ConversionMain<CourseTermSurvey, int>, ICourseTermSurvey
    {
        public CourseTermSurveyDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CourseTermSurvey, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
