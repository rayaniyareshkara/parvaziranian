﻿using System;

namespace CMS.Schema.PortalCustomize.ArticleUi
{
    public class ArticleLimitedDto
    {
        public string Title { get; set; }

        public string Image { get; set; }

        public string Summery { get; set; }

        public string Url { get; set; }

        public DateTime CreationTime { get; set; }
    }
}
