﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
  public  class QuestionAnswerSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string description { get; set; }     
        public int QuestionId { get; set; }
        public bool IsActive { get; set; }

    }
}
