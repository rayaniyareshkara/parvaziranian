﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public    class HeadLineFileSchema
    {
        public int Id { get; set; }
        public int? Order { get; set; }
        public string   Description { get; set; }
        public string Image { get; set; }
        public string Title { get; set; }
        public int HeadLineId { get; set; }
        public string HeadLineName { get; set; }
    }
}
