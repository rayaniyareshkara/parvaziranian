﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class StudentCommentDataServices : ConversionMain<StudentComment, int>, IStudentComment
    {
        public StudentCommentDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<StudentComment, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
