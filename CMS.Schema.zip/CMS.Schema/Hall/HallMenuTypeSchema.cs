﻿using System.Collections.Generic;

namespace CMS.Schema.Hall
{
    public class HallMenuTypeSchema
    {
        public int Id { get; set; }
        public int Type { get; set; }
        public string Title { get; set; }
        public bool IsMain { get; set; }
    }

    public class HallMenuDetailsSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int Type { get; set; }
        public int Price { get; set; }
        public List<MenuInfo> Info { get; set; } = new List<MenuInfo>();
        public bool IsMain { get; set; }
    }
}
