﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalAmio.Factor
{
    public class PaymentByBankReceiptSchema
    {
        [DisplayName("فاکتور درخواستی")]
        [Required(ErrorMessage = "{0} الزامی است")]

        public int FactorId { get; set; }
        [DisplayName("تصویر فیش بانکی")]
        [Required(ErrorMessage = "{0} الزامی است")]

        public string ImageBankReceipt { get; set; }
        [DisplayName("کد رهگیری")]
        public string BankReceipt { get; set; }
    }
}
