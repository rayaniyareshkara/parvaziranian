﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
  public  class ExhibitionFullSchema
    {
        public int Id { get; set; }
        public string Caption { get; set; }
        public int LanguageId { get; set; }
        public string Summery { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public string RightBannerImage { get; set; }
        public string LeftBannerImage { get; set; }
        public string CenterBannerImage { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string VisitingTime { get; set; }
        public string HoldingSpace { get; set; }
        public int? newsId { get; set; }
        public bool? Slaider { get; set; } 
        public string Url { get; set; }
        public string MetaKeyWord { get; set; }
        public string PageTitle { get; set; }
        public string MetaDescription { get; set; }
        public int ExhibitionTypeId { get; set; }
        public bool? IsRegisterActive { get; set; }
        public DateTime RegistrationStartDate { get; set; }
        public DateTime EndDateOfRegistration { get; set; }
        public int? IdRow { get; set; }
        public string Link { get; set; }
        public int? ExhibitionMainId { get; set; }

        
    

    }
}
