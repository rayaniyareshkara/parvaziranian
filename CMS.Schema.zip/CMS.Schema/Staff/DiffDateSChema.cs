﻿

using System;
using System.Collections.Generic;

namespace CMS.Schema.Staff
{
    public class DiffDateSchema
    {
        public DiffDateSchema()
        {
            Dates = new List<PricePerDateCalendar>();
        }
        public int TotalDays { get; set; }
        public int TotalYear { get; set; }
        public int TotalMonths { get; set; }
        public List<PricePerDateCalendar> Dates { get; set; }
    }
}
