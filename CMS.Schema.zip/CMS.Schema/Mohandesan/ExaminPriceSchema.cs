﻿
namespace CMS.Schema.Mohandesan
{
    public class ExaminPriceSchema
    {
        public double Price { get; set; }
        public int Field { get; set; }
    }
}
