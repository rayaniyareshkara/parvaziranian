﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web.Hosting;

namespace CMS.Schema.Portal
{
    public class FileWork
    {
        public static Configuration ReadFile(string fileName)
        {
            Configuration configurationResult = null;
            if (File.Exists(HostingEnvironment.MapPath(fileName)))
            {
                Stream fileStream = null;
                try
                {
                    fileStream = File.OpenRead(HostingEnvironment.MapPath(fileName));
                    BinaryFormatter deserializer = new BinaryFormatter();
                    configurationResult = (Configuration)deserializer.Deserialize(fileStream);
                }
                catch (Exception)
                {
                    // ignored
                }
                finally
                {
                    fileStream?.Close();
                }
            }
            else
            {
                configurationResult = new Configuration
                {
                    ContentConnectionString = @"metadata=res://*/Content.ContentEF.csdl|res://*/Content.ContentEF.ssdl|res://*/Content.ContentEF.msl;provider=System.Data.SqlClient;provider connection string='data source=.;initial catalog=Sample.Sql;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework'",
                    ManagementConnectionString = @"data source=.;initial catalog=Sample.Sql;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework",
                    LogConnectionString = @"metadata=res://*/Log.LogEF.csdl|res://*/Log.LogEF.ssdl|res://*/Log.LogEF.msl;provider=System.Data.SqlClient;provider connection string='data source=.;initial catalog=Sample.Sql;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework'"
                };
                WriteFile(fileName, configurationResult);
            }

            return configurationResult;
        }

        public static bool WriteFile(string fileName, Configuration tnz)
        {
            MemoryStream memoryStream = null;
            FileStream fileStream = null;
            try
            {
                memoryStream = new MemoryStream();
                BinaryFormatter serializer = new BinaryFormatter();
                serializer.Serialize(memoryStream, tnz);

                fileStream = File.Create(HostingEnvironment.MapPath(fileName));
                memoryStream.WriteTo(fileStream);

                return true;
            }
            catch (Exception )
            {
                return false;
            }
            finally
            {
                fileStream?.Close();
                memoryStream?.Close();
            }
        }
    }
}