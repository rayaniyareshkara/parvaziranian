﻿

namespace CMS.Schema.Mohandesan
{
    public class LawFirmInFieldsViewModel 
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string Grade { get; set; }
        public string Field { get; set; }
        public string TerendName { get; set; }
        public int TerendId { get; set; }
        public int FieldId { get; set; }
        

        public bool IsImplementation { get; set; }
        public bool IsExperiment { get; set; }
        public bool IsConsultant { get; set; }

    }
}

