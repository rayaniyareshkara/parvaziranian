﻿using System;

using System.Linq;
using System.Text;


namespace CMS.Core.Component
{
    public class GenerateKey
    {
        public string[] AllChar = stringSpliter("qazwsxedcrfvtgbyhnujmikolpPLOKIMJUNHYBGTVFRCDEXSWZAQ", 1);
        public string Next(string lastKey, int KeyControl = 0)
        {
            string resault = "Error";
            if (KeyControl == lastKey.Count())
            {
                resault = AllChar[0] + lastKey;
                return resault;
            }

            string count = lastKey.Substring(lastKey.Count() - KeyControl - 1, 1);
            if (count == AllChar[AllChar.Length - 1])
            {
                string NewChar = AllChar[0];
                var aStringBuilder = new StringBuilder(lastKey);
                aStringBuilder.Remove(lastKey.Count() - KeyControl - 1, 1);
                aStringBuilder.Insert(lastKey.Count() - KeyControl - 1, NewChar);
                resault = aStringBuilder.ToString();
                resault = Next(resault, KeyControl + 1);

            }
            else
            {
                string NewChar = AllChar[Array.IndexOf(AllChar, count) + 1];
                var aStringBuilder = new StringBuilder(lastKey);
                aStringBuilder.Remove(lastKey.Count() - KeyControl - 1, 1);
                aStringBuilder.Insert(lastKey.Count() - KeyControl - 1, NewChar);
                resault = aStringBuilder.ToString();
            }
            return resault;

        }
        public static string[] stringSpliter(string source, int step)
        {
            string[] Answer = new string[source.Length / step];
            for (int i = 0; i < source.Length; i += step)
            {
                Answer[i] = source.Substring(i, step);
            }
            return Answer;
        }
    }

    public class GenerateKeyRandom
    {
        public string[] AllChar = StringSplitter("2031584769", 1);
        public string Next(string lastKey, int keyControl = 0)
        {
            var result = "Error";
            if (keyControl == lastKey.Count())
            {
                result = AllChar[0] + lastKey;
                return result;
            }

            var count = lastKey.Substring(lastKey.Count() - keyControl - 1, 1);

            if (count == AllChar[AllChar.Length - 1])
            {
                var newChar = AllChar[0];
                var aStringBuilder = new StringBuilder(lastKey);
                aStringBuilder.Remove(lastKey.Count() - keyControl - 1, 1);
                aStringBuilder.Insert(lastKey.Count() - keyControl - 1, newChar);
                result = aStringBuilder.ToString();
                result = Next(result, keyControl + 1);
            }
            else
            {
                var newChar = AllChar[Array.IndexOf(AllChar, count) + 1];
                var aStringBuilder = new StringBuilder(lastKey);
                aStringBuilder.Remove(lastKey.Count() - keyControl - 1, 1);
                aStringBuilder.Insert(lastKey.Count() - keyControl - 1, newChar);
                result = aStringBuilder.ToString();
            }
            return result;

        }
        private static string[] StringSplitter(string source, int step)
        {
            var answer = new string[source.Length / step];
            for (var i = 0; i < source.Length; i += step)
            {
                answer[i] = source.Substring(i, step);
            }
            return answer;
        }
    }

}
