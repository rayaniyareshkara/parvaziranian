﻿namespace CMS.Schema.PortalCustomize.Article
{
    public class AdvertisingOrderGridSchema
    {

        public string UserName { get; set; }
        public int Id { get; set; }

        public string Exhibition { get; set; }

        public string Location { get; set; }

        public string Time { get; set; }

        public string Status { get; set; }
    }
}
