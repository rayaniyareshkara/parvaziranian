﻿namespace CMS.FrameWork.Statute.Events
{
    using System;
    using System.Linq;
    using System.Xml.Linq;
    using System.Web;

    public class EventSite
    {
        //public event EventSelect SelectEvent;
        //public event EventInsert InsertEvent;
        //public event EventUpdate UpdateEvent;
        //public event EventDelete DeleteEvent;

        public virtual void OnSelect(Exception e, string code = "0")
        {
            var xdoc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));

            int? Id = xdoc.Root.Descendants("SelectError").Select(s => new EventArgsUser { Id = Convert.ToInt32(s.Attribute("Id").Value) }).ToList().OrderByDescending(o => o.Id).FirstOrDefault()?.Id ?? 0;

            xdoc.Element("ErrorList").Elements("Select").FirstOrDefault()
                                     .AddFirst(new XElement("SelectError", e.Message ?? "No Massege",
                                                   new XAttribute("Id", ++Id),
                                                   new XAttribute("CodeError", code),
                                                   new XAttribute("CreateDate", DateTime.Now),
                                                   new XAttribute("Source", e.Source ?? "No Source"),
                                                   new XAttribute("HelpLink", e.HelpLink ?? "No HelpLink"),
                                                   new XAttribute("HResult", (int?)e.HResult ?? 0),
                                                   new XAttribute("StackTrace", e.StackTrace ?? "No StackTrace")));

            xdoc.Save(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));
        }

        public virtual void OnSave(Exception e, string code = "0")
        {
            var xdoc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));

            int? Id = xdoc.Root.Descendants("SaveError").Select(s => new EventArgsUser { Id = Convert.ToInt32(s.Attribute("Id").Value) }).ToList().OrderByDescending(o => o.Id).FirstOrDefault()?.Id ?? 0;

            xdoc.Element("ErrorList").Elements("Save").FirstOrDefault()
                                     .AddFirst(new XElement("SaveError", e.Message ?? "No Massege",
                                                   new XAttribute("Id", ++Id),
                                                   new XAttribute("CodeError", code),
                                                   new XAttribute("CreateDate", DateTime.Now),
                                                   new XAttribute("Source", e.Source ?? "No Source"),
                                                   new XAttribute("HelpLink", e.HelpLink ?? "No HelpLink"),
                                                   new XAttribute("HResult", (int?)e.HResult ?? 0),
                                                   new XAttribute("StackTrace", e.StackTrace ?? "No StackTrace")));


            xdoc.Save(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));
        }

        public virtual void OnUpdate(Exception e, string code = "0")
        {
            var xdoc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));

            int? Id = xdoc.Root.Descendants("UpdateError").Select(s => new EventArgsUser { Id = Convert.ToInt32(s.Attribute("Id").Value) }).ToList().OrderByDescending(o => o.Id).FirstOrDefault()?.Id ?? 0;

            xdoc.Element("ErrorList").Elements("Update").FirstOrDefault()
                                     .AddFirst(new XElement("UpdateError", e.Message ?? "No Massege",
                                                   new XAttribute("Id", ++Id),
                                                   new XAttribute("CodeError", code),
                                                   new XAttribute("CreateDate", DateTime.Now),
                                                   new XAttribute("Source", e.Source ?? "No Source"),
                                                   new XAttribute("HelpLink", e.HelpLink ?? "No HelpLink"),
                                                   new XAttribute("HResult", (int?)e.HResult ?? 0),
                                                   new XAttribute("StackTrace", e.StackTrace ?? "No StackTrace")));

            xdoc.Save(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));
        }

        public virtual void OnDelete(Exception e, string code = "0")
        {
            var xdoc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));

            int? Id = xdoc.Root.Descendants("DeleteError").Select(s => new EventArgsUser { Id = Convert.ToInt32(s.Attribute("Id").Value) }).ToList().OrderByDescending(o => o.Id).FirstOrDefault()?.Id ?? 0;

            xdoc.Element("ErrorList").Elements("Delete").FirstOrDefault()
                                     .AddFirst(new XElement("DeleteError", e.Message ?? "No Massege",
                                                   new XAttribute("Id", ++Id),
                                                   new XAttribute("CodeError", code),
                                                     new XAttribute("CreateDate", DateTime.Now),
                                                   new XAttribute("Source", e.Source ?? "No Source"),
                                                   new XAttribute("HelpLink", e.HelpLink ?? "No HelpLink"),
                                                   new XAttribute("HResult", (int?)e.HResult ?? 0),
                                                   new XAttribute("StackTrace", e.StackTrace ?? "No StackTrace")));


            xdoc.Save(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));
        }

        public virtual void Other(Exception e, string code = "0")
        {
            var xdoc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));

            int? Id = xdoc.Root.Descendants("OtherError").Select(s => new EventArgsUser { Id = Convert.ToInt32(s.Attribute("Id").Value) }).ToList().OrderByDescending(o => o.Id).FirstOrDefault()?.Id ?? 0;

            xdoc.Element("ErrorList").Elements("Other").FirstOrDefault()
                                     .AddFirst(new XElement("OtherError", e.Message ?? "No Massege",
                                                   new XAttribute("Id", ++Id),
                                                   new XAttribute("CodeError", code),
                                                   new XAttribute("CreateDate", DateTime.Now),
                                                   new XAttribute("Source", e.Source ?? "No Source"),
                                                   new XAttribute("HelpLink", e.HelpLink ?? "No HelpLink"),
                                                   new XAttribute("HResult", (int?)e.HResult ?? 0),
                                                   new XAttribute("StackTrace", e.StackTrace ?? "No StackTrace")));


            xdoc.Save(HttpContext.Current.Server.MapPath("~/App_Data/DataBase/ErrorManeger.config"));
        }

    }

}
