﻿using System.Data;
using System.Web.Mvc;

namespace CMS.Core.Component
{
    public class XmlResult : ActionResult
    {
        private readonly string _dt;
        public XmlResult(string dt)
        {
            _dt = dt;
        }
        public override void ExecuteResult(ControllerContext context)
        {
            var response = context.HttpContext.Response;
            response.ContentType = "application/xml";
            response.Write(_dt);
        }
    }
}
