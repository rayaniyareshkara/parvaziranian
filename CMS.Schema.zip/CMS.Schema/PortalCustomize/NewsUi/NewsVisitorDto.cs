﻿namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class NewsVisitorDto
    {
        public string Title { get; set; }

        public string Image { get; set; }

        public string Url { get; set; }
    }
}
