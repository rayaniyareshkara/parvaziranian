﻿using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Admin.Interfaces;
using System;
using System.Linq.Expressions;


namespace CMS.Infrastructure.Admin.Classes
{
    public class NewsCommentDataServices : ConversionMain<NewsComment, int>, INewsComment
    {
        public NewsCommentDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<NewsComment, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
