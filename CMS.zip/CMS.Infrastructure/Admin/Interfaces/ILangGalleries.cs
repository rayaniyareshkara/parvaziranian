﻿using CMS.FrameWork.Statute.DBA.Repository;
using CMS.FrameWork.Model;
using System;

namespace CMS.Infrastructure.Admin.Interfaces
{
    //public interface ILangGalleries : IRule<LangGalleries, int>
    //{
    //}
}
