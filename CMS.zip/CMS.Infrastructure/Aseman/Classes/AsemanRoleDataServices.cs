﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
    public class AsemanRoleDataServices : ConversionMain<AsemanRole, int>, IAsemanRole
    {
        public AsemanRoleDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<AsemanRole, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}

