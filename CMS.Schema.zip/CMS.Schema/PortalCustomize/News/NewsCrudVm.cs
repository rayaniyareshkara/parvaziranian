﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CMS.Schema.PortalCustomize.News
{
    public class NewsCrudVm
    {
        public int Id { get; set; }

        public int? CategoryId { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        [DisplayName("عنوان")]
        public string Caption { get; set; }

        [DisplayName("فعال/غیرفعال")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public bool Status { get; set; }

        [DisplayName("زبان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int Lang { get; set; }
        [StringLength(500, ErrorMessage = "{0} طول نمی تواند بیشتر از 500 حروف باشد")]

        public string Summery { get; set; }
        [AllowHtml]
        public string Description { get; set; }
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]
        public string Image { get; set; }
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        public string TagWords { get; set; }
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        public string MetaTagWords { get; set; }
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد ")]
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("آدرس")]
        public string Url { get; set; }
        [DisplayName("عنوان صفحه")]
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد ")]
        public string PageTitle { get; set; }
        [DisplayName("آدرس")]
        [StringLength(500, ErrorMessage = "{0} طول نمی تواند بیشتر از 500 حروف باشد ")]
        public string MetaDescription { get; set; }
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد ")]
        public string MetaImage { get; set; }


    }
}
