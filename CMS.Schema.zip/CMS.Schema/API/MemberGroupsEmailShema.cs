﻿

namespace CMS.Schema.API
{
    public class MemberGroupsEmailShema
    {
        public int Id { get; set; }
        public int GroupId { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}
