﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class StudentClassSchema
    {
        public int Id { get; set; }
        public int CourseTermStudentCheckId { get; set; }
        public int? StudentId { get; set; }
        public Guid UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int StudentStatus { get; set; }
        public string StudentStatusName { get; set; }
        public int Status { get; set; }
        public string StatusName { get; set; }
    }
}
