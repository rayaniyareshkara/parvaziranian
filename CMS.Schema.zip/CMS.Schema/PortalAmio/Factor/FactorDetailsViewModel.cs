﻿namespace CMS.Schema.PortalAmio.Factor
{
  public  class FactorDetailsViewModel
    {
        public int Id { get; set; }

        public string Image { get; set; }

        public string Type { get; set; }

        public string Title { get; set; }

        public string Status  { get; set; }
    }
}
