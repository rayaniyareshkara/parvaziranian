﻿//using System;
//using System.IO;
//using System.IO.Compression;
//using System.Linq;

//using System.Web;

//namespace CMS.Core.Component
//{


//    public class Backup
//    {
//        private FrameWork.Model.EntitysModelCMS db = new FrameWork.Model.EntitysModelCMS();
//        public string BackUpCMS()
//        {
//            string path = "";
//            try
//            {
//                var date = DateTime.Now;
//                string zipPath = HttpContext.Current.Server.MapPath("~/BackUp/" + date.Year.ToString() + date.Month.ToString() + date.Day.ToString() + date.Hour.ToString() + date.Minute.ToString() + date.Second.ToString() + ".zip");
//                ZipFile.CreateFromDirectory(HttpContext.Current.Server.MapPath("~/Images"), zipPath);
//                using (FileStream zipToOpen = new FileStream(zipPath, FileMode.Open))
//                {
//                    using (ZipArchive archive = new ZipArchive(zipToOpen, ZipArchiveMode.Update))
//                    {
//                        var DBpath = HttpContext.Current.Server.MapPath("~/backUp/" + date.Year.ToString() + date.Month.ToString() + date.Day.ToString() + date.Hour.ToString() + date.Minute.ToString() + date.Second.ToString() + date.Millisecond.ToString() + ".bak");
//                        var res = db.BackupDB(DBpath).FirstOrDefault();
//                        FileInfo backupfile = new FileInfo(res);
//                        ZipArchiveEntry readmeEntry = archive.CreateEntryFromFile(HttpContext.Current.Server.MapPath("~/BackUp/" + backupfile.Name), "SQLbackupCMS.bak");
//                        ZipArchiveEntry readmeEntry2 = archive.CreateEntryFromFile(HttpContext.Current.Server.MapPath("~/setting.Config"), "setting.config");
//                    }
//                }
//                path = zipPath;
//            }
//            catch (Exception ex)
//            {
//                path = "error";
//            }
//            return path;
//        }
//    }
//}
