﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
   public class MainCourseTermDataServices : ConversionMain<MainCourseTerm, int>, IMainCourseTerm
    {
        public MainCourseTermDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<MainCourseTerm, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}

