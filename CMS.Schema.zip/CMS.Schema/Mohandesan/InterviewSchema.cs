﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Mohandesan
{
 public   class InterviewSchema
    {
        public Guid Id { get; set; }
        public string Image { get; set; }
        public string Title { get; set; }
        public string Embed { get; set; }
        public DateTime Date { get; set; }
        public string Category { get; set; }
        public string Header { get; set; }
        public int IntId { get; set; }
        public string Description { get; set; }
        public string Author { get; set; }
        public DateTime ReleaseDate { get; set; }
        public DateTime ExpireDate { get; set; }
        public string Body { get; set; }
        public int? galleryId { get; set; }
        public bool IsActive { get; set; }
        public string TypeNews { get; set; }
        public string MetaKey { get; set; }
        public string MetaName { get; set; }
        public string MetaDesc { get; set; }

        public string Rotter { get; set; }
        public string Tags { get; set; }
        public string Lead { get; set; }
        public List<Rows> MyRows { get; set; }

    }
    public class Rows
    {
        public int Id { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
       
        public int Row { get; set; }


    }
}
