﻿

using System;
using System.Collections.Generic;

namespace CMS.Schema.Hall
{
    public class HallSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public bool IsActive { get; set; }
        public int Capacity { get; set; }
        public string Image { get; set; }
        public string HotelName { get; set; }
        public int Order { get; set; } = 10;
        public string ReserveStartDate { get; set; }
        public string ReservePhone { get; set; }
    }

    public class HallDetailsSchema: HallSchema
    {
        public List<CeremonySchema> Ceremony { get; set; } = new List<CeremonySchema>();
        public List<CeremonySchema> Features { get; set; } = new List<CeremonySchema>();
        public List<CeremonySchema> Services { get; set; } = new List<CeremonySchema>();
        public int HotelId { get; set; }
        public List<PropertySchema> FeatureProperty { get; set; } = new List<PropertySchema>();
        public List<PropertySchema> Property { get; set; } = new List<PropertySchema>();
        public List<string> Gallery { get; set; } = new List<string>();
        public string Description { get; set; }  
        public DateTime? GReserveStartDate { get; set; }
        public List<HallPricingSchema> Pricing { get; set; } = new List<HallPricingSchema>();
        public List<HallLayoutSchema> Layouts { get; set; } = new List<HallLayoutSchema>();
        public List<HallMenuDetailsSchema> Menu { get; set; } = new List<HallMenuDetailsSchema>();
        public List<HallServeTypeSchema> Serve { get; set; } = new List<HallServeTypeSchema>();
        public string File { get; set; }
    }
}
