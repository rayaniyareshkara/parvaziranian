﻿
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class HomaFooterViewModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Align { get; set; }

        public List<FooterSchema> Footers { get; set; }
    }
    public class FooterSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Name { get; set; }
        public int Priority { get; set; }
        public bool IsActive { get; set; }
        public string Link { get; set; }
        public string FooterType { get; set; }
        public int FooterTypeId { get; set; }
        public string Image { get; set; }
        
    }
}
