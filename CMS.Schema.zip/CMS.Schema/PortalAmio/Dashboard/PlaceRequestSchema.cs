﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Dashboard
{
   public class PlaceRequestSchema
    {
        public int Id { get; set; }
        public int Model { get; set; }
        public int OpenPlaceRequestReal { get; set; }
        public int SaloonPlaceRequestReal { get; set; }
        public int OpenPlaceRequestDollar { get; set; }
        public int SaloonPlaceRequestDollar { get; set; }
        public Boolean OPenPlaceModelNormal { get; set; }
        public Boolean OPenPlaceModelSpetial { get; set; }

        public Boolean SaloonPlaceModelNormal { get; set; }
        public Boolean SaloonPlaceModelSpetial { get; set; }
        public Boolean SaloonPlaceModelspanser { get; set; }
        public string DescriptionOpEnPlace { get; set; }
        public int BildingModel { get; set; }
        public string TitlePersian { get; set; }
        public string TitleEnglish { get; set; }
            public int? BildingTypeId { get; set; }
        public string USerDescription { get; set; }
        public int HallId { get; set; }
        public int ExhibitionId { get; set; }

        public int Price { get; set; }

        public int[] StandId { get; set; }

    }

    public class PavionPlaceRequestSchema
    {
        public int Id { get; set; }
        public int Model { get; set; }
        public int OpenPlaceRequestReal { get; set; }
        public int SaloonPlaceRequestReal { get; set; }
        public int OpenPlaceRequestDollar { get; set; }
        public int SaloonPlaceRequestDollar { get; set; }
        public Boolean OPenPlaceModelNormal { get; set; }
        public Boolean OPenPlaceModelSpetial { get; set; }

        public Boolean SaloonPlaceModelNormal { get; set; }
        public Boolean SaloonPlaceModelSpetial { get; set; }
        public Boolean SaloonPlaceModelspanser { get; set; }
        public string DescriptionOpEnPlace { get; set; }
        public int BildingModel { get; set; }
        public string TitlePersian { get; set; }
        public string TitleEnglish { get; set; }
        public int? BildingTypeId { get; set; }
        public string USerDescription { get; set; }
        public int HallId { get; set; }
        public int PavionId { get; set; }

        public int Price { get; set; }

        public int[] StandId { get; set; }

    }
    public class PlaceRequestQuerySchema
    {
        public int Id { get; set; }
        public int Model { get; set; }
        public string ExhibitionName { get; set; }
        public String UserName { get; set; }
        public String Status { get; set; }

        public string CompanyName { get; set; }


    }
}
