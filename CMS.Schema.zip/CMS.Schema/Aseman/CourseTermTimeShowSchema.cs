﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class CourseTermTimeShowSchema
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public int StatusId { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }

    }
}
