﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Globalization;

namespace CMS.Core.Helper
{

    public static class Utility
    {
        public static HtmlString Image(this HtmlHelper helper, string url, string alt, string id, object htmlAttributes)
        {
            TagBuilder builder = new TagBuilder("img");

            builder.Attributes.Add("id", id);
            builder.Attributes.Add("src", url);
            builder.Attributes.Add("alt", alt);
            builder.MergeAttributes(new RouteValueDictionary(htmlAttributes));

            return new HtmlString(builder.ToString(TagRenderMode.SelfClosing));
        }

        public static DateTime ToDatetime(this string date)
        {
            string[] param = date.Split('/', '-');

            PersianCalendar pc = new PersianCalendar();
            return pc.ToDateTime(Convert.ToInt32(param[0]), Convert.ToInt32(param[1]), Convert.ToInt32(param[2]), 0, 0, 0, 0);
        }
        public static string ToPersian(this DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            int year = pc.GetYear(date);
            int month = pc.GetMonth(date);
            int day = pc.GetDayOfMonth(date);
            return new DateTime(year, month, day).ToString("yyyy/MM/dd");
        }

        public static DateTime PersianToGregorian(string persian)
        {
            string[] str = persian.Split(new char[] { '/' });

            PersianCalendar pc = new PersianCalendar();
            DateTime dt = new DateTime();

            try
            {
                dt = pc.ToDateTime(Convert.ToInt32(str[2]), Convert.ToInt32(str[1]), Convert.ToInt32(str[0]), 0, 0, 0, 0);
            }
            catch
            {
                dt = pc.ToDateTime(Convert.ToInt32(str[0]), Convert.ToInt32(str[1]), Convert.ToInt32(str[2]), 0, 0, 0, 0);
            }


            return dt;
        }

        /// <summary>
        /// تبدیل عدد انگلیسی به فارسی
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string EnglishToPersianNumber(this object text)
        {
            try
            {
                if (text == null)
                    return "";

                for (int i = 48; i < 58; i++)
                {
                    text = text.ToString().Replace(Convert.ToChar(i), Convert.ToChar(1728 + i));
                }
                return text.ToString();

            }
            catch (Exception)
            {

                throw;
            }

        }




    }
}
