﻿using System;

namespace CMS.Schema.Portal
{
    public class PropertyUsersRole
    {
        public int UserSiteRoleId { get; set; }
        public Guid UsersSiteId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
