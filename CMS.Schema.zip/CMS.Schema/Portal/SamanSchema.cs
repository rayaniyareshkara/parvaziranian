﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
    [Serializable]
    public class SamanSchema
    {
        private string _UserName;
        public string UserName
        {
            get { return Cypher.Decrypt(_UserName); }
            set { _UserName = Cypher.Encrypt(value); }
        }

        private string _Password;
        public string Password
        {
            get { return Cypher.Decrypt(_Password); }
            set { _Password = Cypher.Encrypt(value); }
        }

        private string _MID;
        public string MID
        {
            get { return Cypher.Decrypt(_MID); }
            set { _MID = Cypher.Encrypt(value); }
        }
        public bool IsActive { get; set; }
    }
}
