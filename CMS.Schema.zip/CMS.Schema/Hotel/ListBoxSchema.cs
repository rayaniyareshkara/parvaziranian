﻿
namespace CMS.Schema.Hotel
{
    public class ListBoxSchema
    {
        public string Value { get; set; }
        public string Text { get; set; }
    }
}
