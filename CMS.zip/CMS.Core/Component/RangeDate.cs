﻿using CMS.Schema.Staff;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Core.Component
{
    public class RangeDate
    {
        public static List<PricePerDateCalendar> DiffDates(DateTime startDate, DateTime endDate)
        {
            var persianCalendar = new System.Globalization.PersianCalendar();

            var range = Enumerable.Range(0, 1 + endDate.Subtract(startDate).Days).Select(offset => startDate.AddDays(offset)).ToList();


            return range.Select(d => new PricePerDateCalendar
            {
                Count = 0,
                Date = d,
                Day = persianCalendar.GetDayOfMonth(d),
                DayName = d.PersionDayOfWeekAsString(),
                GDay = d.Day,
                GMonth = d.Month,
                Month = persianCalendar.GetMonth(d),
                GYear = d.Year,
                Year = persianCalendar.GetYear(d),
                MonthName = PersianMonth.Month[persianCalendar.GetMonth(d) - 1],
                PersianDate = persianCalendar.GetYear(d) + "/" + persianCalendar.GetMonth(d) + "/" + persianCalendar.GetDayOfMonth(d),
            }).ToList();
        }



        public static List<DateTime> GetMonthsBetween(DateTime from, DateTime to)
        {
            if (from > to) return GetMonthsBetween(to, from);

            var monthDiff = Math.Abs((to.Year * 12 + (to.Month - 1)) - (from.Year * 12 + (from.Month - 1)));

            if (from.AddMonths(monthDiff) > to || to.Day < from.Day)
            {
                monthDiff -= 1;
            }

            List<DateTime> results = new List<DateTime>();
            for (int i = monthDiff; i >= 1; i--)
            {
                results.Add(to.AddMonths(-i));
            }

            return results;
        }

        public static List<DateTime> DatesInRanges(DateTime endDate, DateTime startDate) =>
            Enumerable.Range(0, endDate.Subtract(startDate).Days).Select(offset => startDate.AddDays(offset)).ToList();

    }
}
