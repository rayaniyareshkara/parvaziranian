﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Web;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.Xml.Serialization;
using System.IO;

namespace CMS.Core.Component
{
    public class SiteMap
    {
        public void SaveSiteMap(string Title, string TypePage)
        {
            XmlDocument xmlEmloyeeDoc = new XmlDocument();
            xmlEmloyeeDoc.Load(HttpContext.Current.Server.MapPath("/sitemap.xml"));

            XNamespace ns = XNamespace.Get("http://www.sitemaps.org/schemas/sitemap/0.9");

            XmlElement ParentElement = xmlEmloyeeDoc.CreateElement("url", ns.NamespaceName);

            XmlElement loc = xmlEmloyeeDoc.CreateElement( "loc", ns.NamespaceName );

            if (TypePage == "News")
                loc.InnerText = "http://MofidCMS.Com/fa/News/Show/" + Title;
            if (TypePage == "Custome")
                loc.InnerText = "http://MofidCMS.Com" + Title;

            XmlElement lastmod = xmlEmloyeeDoc.CreateElement("lastmod", ns.NamespaceName);
            lastmod.InnerText = DateTime.Now.ToString("yyyy-MM-dd");

            XmlElement changefreq = xmlEmloyeeDoc.CreateElement("changefreq", ns.NamespaceName);
            changefreq.InnerText = "weekly";

            XmlElement priority = xmlEmloyeeDoc.CreateElement("priority", ns.NamespaceName);

            if (TypePage == "Category")
                priority.InnerText = "0.8";
            ParentElement.AppendChild(loc);
            ParentElement.AppendChild(lastmod);
            ParentElement.AppendChild(changefreq);
            ParentElement.AppendChild(priority);
            xmlEmloyeeDoc.DocumentElement.InsertBefore(ParentElement, xmlEmloyeeDoc.DocumentElement.FirstChild);
            var s = xmlEmloyeeDoc.OuterXml.ToString();
            xmlEmloyeeDoc.Save(HttpContext.Current.Server.MapPath("/sitemap.xml"));       
        }
    }
}
