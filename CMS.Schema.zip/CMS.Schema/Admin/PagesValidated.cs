﻿
namespace CMS.Schema.Admin
{
    public class PagesValidated : PagesSchema
    {
        public new string Url { get; set; }
        public new string Content { get; set; }
    }
}
