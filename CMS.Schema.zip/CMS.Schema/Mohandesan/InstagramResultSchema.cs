﻿
namespace CMS.Schema.Mohandesan
{
   public  class InstagramResultSchema
    {
        public string error_type { get; set; }
        public string code { get; set; }
        public string error_message { get; set; }
        
        public user_instagram user { get; set; }

        public string access_token { get; set; }
}

    public class InstagramResultAccessTockenSchema
    {
      
        public user_instagram user { get; set; }

        public string access_token { get; set; }
    }
    public class user_instagram
    {

        public long  id { get; set; }
        public string username { get; set; }
        public string full_name { get; set; }
        public string profile_picture { get; set; }

    }
}
