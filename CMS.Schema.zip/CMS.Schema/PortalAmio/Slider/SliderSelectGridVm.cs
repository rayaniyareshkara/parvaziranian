﻿namespace CMS.Schema.PortalAmio
{
    public class SliderSelectGridVm
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public string Lang { get; set; }
    }
}
