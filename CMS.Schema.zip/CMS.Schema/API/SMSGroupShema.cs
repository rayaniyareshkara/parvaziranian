﻿

namespace CMS.Schema.API
{
    public class SMSGroupShema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
