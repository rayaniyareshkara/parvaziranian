﻿
namespace CMS.Schema.Portal
{
    public enum EnumCookie
    {
        SessionLogin,
        ActiveLoginCode
    }
}
