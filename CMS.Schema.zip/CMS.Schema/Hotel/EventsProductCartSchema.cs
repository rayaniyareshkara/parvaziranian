﻿
namespace CMS.Schema.Hotel
{
    public class EventsProductCartSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int Price { get; set; }
        public int Count { get; set; }
        public string Image { get; set; }
    }
}
