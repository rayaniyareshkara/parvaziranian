﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
   public class SearchSchema
    {
        public string Title { get; set; }
        public int Model { get; set; }
    }
}
