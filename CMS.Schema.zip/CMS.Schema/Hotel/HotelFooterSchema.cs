﻿
namespace CMS.Schema.Hotel
{
     public class HotelFooterSchema 
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Value { get; set; }
        public string Hotel { get; set; }
        public int? HotelId { get; set; }
    }
}
