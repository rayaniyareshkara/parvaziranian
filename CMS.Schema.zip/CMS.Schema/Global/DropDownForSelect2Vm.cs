﻿namespace CMS.Schema.Global
{
    public class DropDownForSelect2Vm
    {
        public int id { get; set; }

        public string text { get; set; }
    }
}
