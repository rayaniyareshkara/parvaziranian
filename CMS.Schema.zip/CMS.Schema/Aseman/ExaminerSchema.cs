﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public   class ExaminerSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public Guid UserId { get; set; }
        public string   CenterName { get; set; }
    }
}
