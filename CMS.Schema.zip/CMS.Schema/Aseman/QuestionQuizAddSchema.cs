﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class QuestionQuizAddSchema
    { 
        public int Id { get; set; }
        public int QuizId { get; set; }
        public int CourseTermId { get; set; }

        public string Title { get; set; }
        public string Description { get; set; }

        public string Answer1 { get; set; }
        public string Answer2 { get; set; }
        public string Answer3 { get; set; }
        public string Answer4 { get; set; }
        public string Image { get; set; }

       
    }
}
