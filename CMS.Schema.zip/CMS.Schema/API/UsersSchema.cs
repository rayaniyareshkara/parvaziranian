﻿
namespace CMS.Schema.API
{
    using System.Runtime.Serialization;

    public class UsersSchema
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string LastName { get; set; }
        public string FristName { get; set; }
        public string Email { get; set; }
        public string Image { get; set; }
    }
}
