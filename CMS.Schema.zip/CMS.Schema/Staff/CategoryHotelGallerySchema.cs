﻿
namespace CMS.Schema.Staff
{
    public class CategoryHotelGallerySchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
        public string Tour { get; set; }
        public bool IsRoot { get; set; }
    }
}
