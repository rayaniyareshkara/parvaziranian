﻿
namespace CMS.Schema.Staff
{
    public class DiscountGroupSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string StartDate { get; set; }
        public string ExpireDate { get; set; }
        public int Amount { get; set; }
        public int AmountCeiling { get; set; }
        public int Cash { get; set; }
        public int CashCeiling { get; set; }
        public int Count { get; set; }
    }
}
