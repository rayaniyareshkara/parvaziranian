﻿using System.IO;

namespace CMS.FrameWork.Statute.Embedded.Repository
{
    public interface IViewProvider
    {
        bool FileExists(string virtualPath);
        bool IsEmbeddedResourcePath(string virtualPath);
        Stream Open(string mPath);
    }
}
