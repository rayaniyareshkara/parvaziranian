﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
   public class ProfileSchema
    {
        public int Id { get; set; }
        public Guid UserSiteID { get; set; }
        public string NationalCode { get; set; }
        public string PassportCode { get; set; }
        public string PlaceBirth { get; set; }
        public DateTime DateBirthday { get; set; }
        public bool maritalstatus { get; set; }
        public DateTime DateMarriage { get; set; }
        public string Job { get; set; }
        public string AddressWork { get; set; }
        public string AddressHome { get; set; }
        public string cartype { get; set; }
        public string LicensePlate { get; set; }
        public bool Notify { get; set; }
        public bool IsActive { get; set; }
    }
}
