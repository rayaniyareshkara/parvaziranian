﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Admin.Interfaces;

namespace CMS.Infrastructure.Admin.Classes
{
 public   class SliderDataServices : ConversionMain<Slider, int>, ISlider
    {
        public SliderDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<Slider, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
