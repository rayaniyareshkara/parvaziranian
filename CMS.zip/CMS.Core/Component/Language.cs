﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;

using CMS.Schema.Portal;
using System.IO;

namespace CMS.Core.Component
{
    public class Language
    {
        public List<ResourceSchema> ResourceList { get; set; }

        private static Language _instance { get; set; }

        public static Language Instance
        {
            get
            {
                if (_instance != null) 
                    return _instance;

                _instance = new Language();
                LanguageResource();
                return _instance;
            }
        }
        private Language()
        {

        }

        public static void LanguageResource()
        {
            string[] fileEntries = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/Resource/"));
            XDocument xdoc;
            _instance.ResourceList = new List<ResourceSchema>();

            foreach (var file in fileEntries)
            {
                string[] FileName = Path.GetFileName(file).Split(new char[] { '.' });

                xdoc = XDocument.Load(file);
                var Query = xdoc.Root.Descendants("Element").Select(s => new ResourceSchema
                {
                    Id = Convert.ToInt32(s.Attribute("Id").Value),
                    Name = s.Attribute("Name").Value,
                    Description = s.Value,
                    Suffix = FileName[1]
                }).ToList();

                foreach (var item in Query)
                    _instance.ResourceList.Add(item);
            }

            XDocument xdocMaster = XDocument.Load(HttpContext.Current.Server.MapPath("~/Resource/Master/LanguageMasterXML.xml"));
            var QueryMaster = xdocMaster.Root.Descendants("Element").Select(s => new ResourceSchema
            {
                Id = Convert.ToInt32(s.Attribute("Id").Value),
                Name = s.Attribute("Name").Value,
                Description = s.Value,
                Suffix = "fa"
            }).ToList();


            _instance.ResourceList.AddRange(QueryMaster);
        }
    }
}
