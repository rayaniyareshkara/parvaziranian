﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class MasterBranchSchema
    {
        public int Id { get; set; }
        public int MasterId { get; set; }
        public int MasterUserId { get; set; }
        public int BranchId { get; set; }
        public string MasterName { get; set; }
        public string BranchName { get; set; }
    }
}
