﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
  public  class QuestionModelSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }     
        public bool IsActive { get; set; }
    }
}
