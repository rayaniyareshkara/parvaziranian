﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;



namespace CMS.Infrastructure.Aseman.Classes
{
  public  class MasterResumeDataServices : ConversionMain<MasterResume, int>, IMasterResume
    {
        public MasterResumeDataServices(EntitysModelCMS context) : base(context)
        {
        }

        public override Expression<Func<MasterResume, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
