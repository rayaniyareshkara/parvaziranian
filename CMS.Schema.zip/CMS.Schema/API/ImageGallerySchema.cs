﻿

namespace CMS.Schema.API
{
    public class ImageGallerySchema
    {
        public int Id { get; set; }
        public int AlbumId { get; set; }
        public string FileType { get; set; }
        public string Picture { get; set; }
        public string Alt { get; set; }
        public string Title { get; set; }
        public bool IsActive { get; set; }
        public string Color { get; set; }
        public string Link { get; set; }
        public string Description { get; set; }

    }
}
