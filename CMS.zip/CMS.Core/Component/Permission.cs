﻿using System;
using System.Collections.Generic;
using CMS.Schema.Portal;
using CMS.FrameWork.Model;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Core.Component
{
    public static class Permission
    {
        public static List<PermisstionUserSchema> UsersPermission { get; set; }
        public static List<PermisstionUserSchema> Instance
        {
            get
            {
                if (UsersPermission.Count() == 0)
                {
                    PermissionUsers();
                }
                return UsersPermission;
            }
        }

        public static void PermissionUsers()
        {
            try
            {
                List<PermisstionUserSchema> permissions = new List<PermisstionUserSchema>();
                UsersPermission = new List<PermisstionUserSchema>();
                using (var dbcontext = new EntitysModelCMS())
                {
                    var listaccessgroup = dbcontext.AccessGroups.AsQueryable();
                    foreach (var item in listaccessgroup)
                    {
                        var s = item.Group1.UsersGroups.ToList();
                        foreach (var _item in s)
                        {
                            permissions.Add(new PermisstionUserSchema
                            {
                                Id = _item.User.Id.ToString(),
                                IsDeleted = item.IsDeleted,
                                IsInserted = item.IsInserted,
                                IsSelected = item.IsSelected,
                                IsUpdated = item.IsUpdated,
                                PageId = item.PageId,
                                PageName = item.AdminPage.Name,
                                UserName = _item.User.UserName
                            });
                        }
                    }

                    permissions.AddRange(dbcontext.AccessUsers.Select(x => new PermisstionUserSchema
                    {
                        Id = x.UsersId.ToString(),
                        IsDeleted = x.IsDeleted,
                        IsInserted = x.IsInserted,
                        IsUpdated = x.IsUpdated,
                        IsSelected = x.IsSeleced,
                        PageId = x.PagesId,
                        UserName = x.User.UserName,
                        PageName = x.AdminPage.Name
                    }).ToList());
                }
                UsersPermission.AddRange(permissions);

            }
            catch (Exception ex)
            {
                new FrameWork.Statute.Events.EventSite().Other(ex);
            }
        }
    }
}
