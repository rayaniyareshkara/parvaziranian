﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class StudentCourseReportSchema
    {
        public int? StudentId  { get; set; }
        public Guid UserId { get; set; }
        public string FirestName { get; set; }
        public string LastName { get; set; }
        public int  Status { get; set; }
        public string StatusName { get; set; } 
        public int CountAbsent { get; set; }

    }
}
