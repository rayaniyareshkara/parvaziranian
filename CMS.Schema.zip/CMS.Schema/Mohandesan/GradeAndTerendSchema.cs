﻿
namespace CMS.Schema.Mohandesan
{
  public   class GradeAndTerendSchema
    {
        public int terend { get; set; }
        public int grade { get; set; }
        public int field { get; set; }
    }
}
