﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class BranchAddSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Location { get; set; }
        public string PostCode { get; set; }
        public string Image { get; set; }
        public string VirtualTour { get; set; }
        public string ManagerName { get; set; }
        public string ManagerPhone { get; set; }
        public int GalleryId { get; set; }
        public int CityId { get; set; }      
        public string LanguageId { get; set; }
        public string Description { get; set; }
        public string Body { get; set; }
        public int BranchMainID { get; set; }   
        public bool IsActive { get; set; }
        public List<Phones> Phones { get; set; }

    }
    public class Phones
    {
        public string Text { get; set; }
        public string Number { get; set; }
        public bool IsActive { get; set; }

    }
}
