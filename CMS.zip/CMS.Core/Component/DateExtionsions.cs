﻿using System;
namespace CMS.Core.Component
{
    public static partial class DateTimeExtensions
    {
        public static DateTime FirstDayOfWeek(this DateTime dt)
        {
            var culture = System.Threading.Thread.CurrentThread.CurrentCulture;
            var diff = dt.DayOfWeek - culture.DateTimeFormat.FirstDayOfWeek;

            if (diff < 0)
            {
                diff += 7;
            }

            return dt.AddDays(-diff).Date;
        }

        public static DateTime LastDayOfWeek(this DateTime dt) =>
            dt.FirstDayOfWeek().AddDays(6);

        public static DateTime FirstDayOfMonth(this DateTime dt) =>
            new DateTime(dt.Year, dt.Month, 1);

        public static DateTime LastDayOfMonth(this DateTime dt) =>
            dt.FirstDayOfMonth().AddMonths(1).AddDays(-1);

        public static DateTime FirstDayOfNextMonth(this DateTime dt) =>
            dt.FirstDayOfMonth().AddMonths(1);

        public static DateTime[] FirstDayofYear(this DateTime dt)
        {
            var persian = new System.Globalization.PersianCalendar();
            var yy = persian.GetYear(dt);
            var fitstDay = ConvertDateTime.PersianToGregorian(yy + "/01/01");
            var lastDay = ConvertDateTime.PersianToGregorian(yy + "/12/29");
            return new DateTime[] { fitstDay, lastDay };
        }

    }
}
