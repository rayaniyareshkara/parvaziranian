﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class CourseTermStudentDataServices : ConversionMain<CourseTermStudent, int>, ICourseTermStudent
    {
        public CourseTermStudentDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CourseTermStudent, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
