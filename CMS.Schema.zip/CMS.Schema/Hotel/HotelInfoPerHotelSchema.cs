﻿
namespace CMS.Schema.Hotel
{
    public class HotelInfoPerHotelSchema
    {
        public int Id { get; set; }
        public int InfoId { get; set; }
        public string Info { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int HotelId { get; set; }
    }
}
