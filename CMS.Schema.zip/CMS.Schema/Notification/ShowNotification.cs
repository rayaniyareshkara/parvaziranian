﻿namespace CMS.Schema.Notification
{
    public class ShowNotification
    {
        public string Class { get; set; }

        public string Caption { get; set; }

        public string Link { get; set; }

        public string Time { get; set; }

        public int Id { get; set; }
    }
}
