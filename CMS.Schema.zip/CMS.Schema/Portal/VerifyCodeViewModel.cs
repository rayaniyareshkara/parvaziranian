﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class VerifyCodeViewModel
    {
        [Required]
        public string Provider { get; set; }

        [Required]
        [Display(Name = @"کد")]
        public string Code { get; set; }
        public string ReturnUrl { get; set; }

        [Display(Name = @"مرا بخاطر بسپار")]
        public bool RememberBrowser { get; set; }

        public bool RememberMe { get; set; }
    }

}
