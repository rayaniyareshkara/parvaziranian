﻿
namespace CMS.Schema.Mohandesan
{
    public class ModirGradeSchema
    {
        public int field { get; set; }
        public int grade { get; set; }
        public int terend { get; set; }
    }

    public class ModirSheetSchema
    {
        public int fieldid { get; set; }
        public int metterid { get; set; }
        public int price { get; set; }
    }

}
