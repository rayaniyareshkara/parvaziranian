﻿
namespace CMS.Schema.Sms
{
    /// <summary>
    /// If(Value==1)
    /// {
    /// کاربری که تازه ثبت نام کرده است
    /// }
    ///
    /// if(value==2)
    /// {
    /// ثبت نام جدید در باشگاه
    /// }
    /// </summary>
    public enum EnumStatusMessageInfo:byte
    {
        NewRegistration = 1,
        NewClubRegistration=2

    }

}
