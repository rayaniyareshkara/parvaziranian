﻿
namespace CMS.Schema.Mohandesan
{
    public class LicenseShcema
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Id { get; set; }
    }
}
