﻿
namespace CMS.Core.Component
{
    using Schema.Staff;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json.Serialization;

    namespace CMS.Core.Component
    {

        public interface IConnectSecureCrs<T>
        {
            Task<ResultConnectData<T>> Post<TA>(string url, TA data, IEnumerable<KeyValuePair<string, string>> headers = null);
            Task<ResultConnectData<T>> Get(string url, IEnumerable<KeyValuePair<string, string>> headers = null);
        }

        public class ConnectSecureCrs<T> : IConnectSecureCrs<T>
        {
            /// <summary>
            /// get method crs
            /// </summary>
            /// <param name="url"></param>
            /// <param name="headers"></param>
            /// <returns></returns>
            public async Task<ResultConnectData<T>> Get(string url, IEnumerable<KeyValuePair<string, string>> headers = null)
            {
                try
                {
                    Uri uri = new Uri(url);

                    var client = new HttpClient();
                    client.BaseAddress = uri;

                    if (headers != null)
                        foreach (var item in headers)
                            client.DefaultRequestHeaders.Add(item.Key, item.Value);

                    var result = await client.GetAsync(uri);

                    var resultContent = await result.Content.ReadAsStringAsync();




                    var _resultdata = JsonConvert.DeserializeObject<JsonResponse<T>>(resultContent);


                    if (_resultdata.code != 200)
                        return new ResultConnectData<T>(ResultStatus.Error, default(T), _resultdata.errors);


                    return new ResultConnectData<T>(ResultStatus.Success, _resultdata.value);

                }
                catch (Exception ex)
                {
                    new FrameWork.Statute.Events.EventSite().Other(ex, "خطا در Get" + "[" + url + "]");
                    return new ResultConnectData<T> { Data = default(T), Errors = new ErrorList { new ErrorSchema(null, "خطا مجددا تلاش کنید") }, Status = ResultStatus.Error };
                }
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="url"></param>
            /// <param name="data"></param>
            /// <returns></returns>
            public async Task<ResultConnectData<T>> Post<TA>(string url, TA data, IEnumerable<KeyValuePair<string, string>> headers = null)
            {
                try
                {
                    Uri uri = new Uri(url);
                    string postData = getQueryString(data);

                    var client = new HttpClient();

                    client.BaseAddress = uri;
                    StringContent content = new StringContent(JsonConvert.SerializeObject(data, new JsonSerializerSettings
                    {
                        ContractResolver = new CamelCasePropertyNamesContractResolver()
                    }), Encoding.UTF8, "application/json");

                    if (headers != null)
                        foreach (var item in headers)
                            client.DefaultRequestHeaders.Add(item.Key, item.Value);

                    var result = await client.PostAsync(uri, content);
                    string resultContent = await result.Content.ReadAsStringAsync();

                    //if (typeof(T) == typeof(string))
                    //    return new ResultConnectData<T>(ResultStatus.Success, (T)(object)resultContent);

                    var _resultdata = JsonConvert.DeserializeObject<JsonResponse<T>>(resultContent);


                    if (_resultdata.code != 200)
                        return new ResultConnectData<T>(ResultStatus.Error, default(T), _resultdata.errors);

                    return new ResultConnectData<T>(ResultStatus.Success, (T)_resultdata.value , _resultdata.errors);
                }
                catch (Exception ex)
                {
                    new FrameWork.Statute.Events.EventSite().Other(ex, "خطا در ارسال اطلاعات به Secure Crs");
                    return new ResultConnectData<T>(ResultStatus.Error, default(T));
                }
            }


            private string getQueryString<T>(T data)
            {
                return JsonConvert.SerializeObject(data);
            }
        }


    }

    public class JsonResponse<T>
    {
        public JsonResponse()
        {

        }

        public JsonResponse(int code, string message, List<ErrorSchema> errors, T value)
        {
            this.code = code;
            this.message = message;
            this.errors.AddRange(errors);
            this.value = value;
        }
        /// <summary>
        /// وضعیت 
        /// </summary>
        public int code { get; set; }
        /// <summary>
        /// متن توضیحات یا اررور
        /// </summary>
        public string message { get; set; }
        /// <summary>
        /// اررور لیست ها
        /// </summary>
        public ErrorList errors { get; set; } = new ErrorList();
        /// <summary>
        /// مقدار برگشتی هر متد
        /// </summary>
        public T value { get; set; }
    }


    public class AgencyDetails
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("username")]
        public string UserName { get; set; }

        [JsonIgnore]
        public Guid UserId { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }
    }

    public class ResponseCreditSchema
    {
        [JsonIgnore]
        public int id { get; set; }

        [JsonProperty("agency")]
        public AgencyDetails Agency { set; get; } = new AgencyDetails();

        [JsonProperty("balance")]
        public int Balance { get; set; }

        [JsonProperty("logs")]
        public List<creditlogs> Logs { get; set; } = new List<creditlogs>();
    }

    public class creditlogs
    {
        [JsonIgnore]
        public int CreditId { get; set; }

        [JsonProperty("balance")]
        public int Balance { get; set; }

        [JsonProperty("date")]
        public DateTime Date { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }
    }

    public class ApiGroupDiscountSchema
    {
        [JsonIgnore]
        public int Id { get; set; }

        [JsonProperty("id")]
        public int CrsGroupId { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("amount")]
        public int Amount { get; set; }

        [JsonProperty("start_date")]
        public DateTime? StartDate { get; set; }

        [JsonProperty("expire_date")]
        public DateTime? ExpireDate { get; set; }

        [JsonProperty("amount_ceiling")]
        public int AmountCeiling { get; set; }

        [JsonProperty("cash")]
        public int Cash { get; set; }

        [JsonProperty("cash_ceiling")]
        public int CashCeiling { get; set; }

        [JsonProperty("hotel_id")]
        public int CrsHotelId { get; set; }

        [JsonIgnore]
        public int HotelId { get; set; }
    }

    public class ApiGroupDiscountAgencySchema
    {
        [JsonIgnore]
        public int Id { get; set; }

        [JsonProperty("id")]
        public int CrsId { get; set; }

        [JsonProperty("group_id")]
        public int GroupId { get; set; }

        [JsonProperty("agency")]
        public AgencyDetails Agency { get; set; } 

        [JsonProperty("room_code")]
        public string RoomCode { get; set; }

        [JsonProperty("room")]
        public CrsRoomSchema Room { get; set; } 
    }
    
    public class LocalApiGroupDiscountAgencySchema
    {
        public int Id { get; set; }
        public int AgencyId { get; set; }
        public string RoomCode { get; set; }
        public int GroupId { get; set; }
    }

}
