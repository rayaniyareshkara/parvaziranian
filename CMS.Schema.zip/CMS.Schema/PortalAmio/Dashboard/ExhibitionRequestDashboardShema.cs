﻿namespace CMS.Schema.PortalAmio.Dashboard
{
    public class ExhibitionRequestDashboardSchema
    {
        public int ExhibitionId { get; set; }

        public string Title { get; set; }

        public string StartTime { get; set; }

        public string Type { get; set; }

        public string Status { get; set; }

        public int StatusButton { get; set; }

        public string StepStatus { get; set; }

        public string Image { get; set; }

        public string UrlExhibition { get; set; }
    }
}
