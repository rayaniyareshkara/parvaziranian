﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Schema.Admin;
using System.Data;

namespace CMS.Core.Component
{
    public class CreateMenu
    {
        public MenuModel.MenuJson GenerateMenuJson(MenuSchema[] menus, LanguagesSchema[] languages)
        {
            MenuModel.MenuJson menuJson = new MenuModel.MenuJson { Data = RecursiveGenerateNode(menus, languages, null) };
            return menuJson;
        }

        public List<MenuModel.MenuJson.DataObj> RecursiveGenerateNode(MenuSchema[] menus, LanguagesSchema[] languages, Guid? parentId)
        {
            List<MenuModel.MenuJson.DataObj> json = new List<MenuModel.MenuJson.DataObj>();

            var parentMenus = menus.Where(m => m.ParentId == parentId).OrderBy(m => m.Order).GroupBy(g => g.Id).Select(s => s.First()).ToArray();

            foreach (var menu in parentMenus)
            {
                MenuModel.MenuJson.DataObj node = new MenuModel.MenuJson.DataObj
                {
                    Id = menu.Id,
                    IsUrlEditable = !menu.Default,
                    Source = menu.Source,
                    SourceKey = menu.SourceKey
                };
                foreach (var lang in languages)
                {
                    var tmp = menus.FirstOrDefault(m => m.Language == lang.Id && m.Id == menu.Id);
                    if (tmp != null)
                    {
                        node.UrlinLanguages.Add(lang.Id.ToString(), tmp.Url);
                        node.TitleinLanguages.Add(lang.Id.ToString(), tmp.Title);
                    }
                }
                node.Nodes = RecursiveGenerateNode(menus, languages, menu.Id);
                json.Add(node);
            }
            return json;
        }

        //public void UpdateMenues(MenuModel.MenuJson data)
        //{
        //    //var menusToDelete = _context.Menu.Where(m => data.Deleted.Contains(m.Id.ToString()));
        //    //if (menusToDelete.Any())
        //    //{
        //    //    _context.Menu.RemoveRange(menusToDelete);
        //    //    _context.SaveChanges();
        //    //}


        //    //List<MenuSchema> menus = RecursiveConvertDataObjToMenu(data.Data);

        //    //if (menus.Any())
        //    //{
        //    //    _context.Menu.AddOrUpdate(menus.ToArray());
        //    //    _context.SaveChanges();
        //    //}
        //}

        public List<MenuSchema> RecursiveConvertDataObjToMenu(List<MenuModel.MenuJson.DataObj> data)
        {
            List<MenuSchema> menus = new List<MenuSchema>();
            foreach (var dataObj in data)
            {
                foreach (var lang in dataObj.TitleinLanguages.Keys)
                {
                    MenuSchema menu = new MenuSchema()
                    {
                        Id = dataObj.Id,
                        Url = dataObj.UrlinLanguages[lang],
                        Title = dataObj.TitleinLanguages[lang],
                        Order = dataObj.Order,
                        ParentId = dataObj.ParentId,
                        Source = dataObj.Source,
                        SourceKey = dataObj.SourceKey,
                        Language = Convert.ToInt32(lang)
                    };
                    menus.Add(menu);
                }

                if (dataObj.Nodes != null && dataObj.Nodes.Any())
                {
                    menus.AddRange(RecursiveConvertDataObjToMenu(dataObj.Nodes));
                }
            }

            return menus;
        }

    }
}
