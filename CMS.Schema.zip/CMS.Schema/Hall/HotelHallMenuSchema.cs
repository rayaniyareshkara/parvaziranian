﻿namespace CMS.Schema.Hall
{
    public class HotelHallMenuSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int Type { get; set; }
        public int HallId { get; set; }
        public bool IsMain { get; set; }
        public int MenuId { get; set; }
    }
}
