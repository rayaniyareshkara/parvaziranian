﻿namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class SearchNewsPagination
    {

        public int Lang { get; set; } = 1;

        public string CategoryId { get; set; }
    }
}
