﻿namespace CMS.Schema.PortalAmio.ExhibitionUi
{
    public class UpcomingExhibitionsVm
    {
        public string Title { get; set; }

        public string Image { get; set; }

        public string Time { get; set; }

        public string Url { get; set; }

        public string Link { get; set; }

        public string Summery { get; set; }

        public string Place { get; set; }
    }
}
