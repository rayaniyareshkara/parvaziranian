﻿using System;
using System.Collections.Generic;

namespace CMS.Schema.PortalAmio.ExhibitionUi
{
    public class ExhibitionDetailsInformationVm
    {
        public string RightBannerImage { get; set; }

        public string LeftBannerImage { get; set; }

        public string CenterBannerImage { get; set; }

        public string Image { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

        public string VisitingTime { get; set; }

        public string HoldingSpace { get; set; }

        public string MetaKeyWord { get; set; }

        public string MetaDescription { get; set; }

        public string PageTitle { get; set; }

        public string ExhibitionType { get; set; }

        public string Summery { get; set; }

        public string Caption { get; set; }

        public string DateVisit { get; set; }

        public string Location { get; set; }

        public string Description { get; set; }

        public string StartTime { get; set; }

        public int ExhibitionId { get; set; }

        public int? NewsCategoryId { get; set; }

        public string Url { get; set; }
        public List<ExhibitionGalleryDto> Gallery { get; set; }
    }
}
