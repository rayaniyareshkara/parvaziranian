﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.GridSource
{


    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Reflection;
    using System.Runtime.Serialization;

    namespace CMS.Schema.Admin
    {
        public class DataSource<T>
        {
            public virtual int Count { get; set; }
            public virtual IList<T> Data { get; set; }
        }

        public class DataSourceResult
        {
            /// <summary>
            /// Represents a single page of processed data.
            /// </summary>
            public IEnumerable Data { get; set; }

            /// <summary>
            /// The total number of records available.
            /// </summary>
            public int Total { get; set; }

            /// <summary>
            /// Represents a requested aggregates.
            /// </summary>
            public object Aggregates { get; set; }

            /// <summary>
            /// Used by the KnownType attribute which is required for WCF serialization support
            /// </summary>
            /// <returns></returns>
            private static Type[] GetKnownTypes()
            {
                var assembly = AppDomain.CurrentDomain
                                        .GetAssemblies()
                                        .FirstOrDefault(a => a.FullName.StartsWith("DynamicClasses"));

                if (assembly == null)
                {
                    return new Type[0];
                }

                return assembly.GetTypes()
                               .Where(t => t.Name.StartsWith("DynamicClass"))
                               .ToArray();
            }


        }

        public class DataSourceRequest
        {
            /// <summary>
            /// Specifies how many items to take.
            /// </summary>
            public int Take { get; set; }

            /// <summary>
            /// Specifies how many items to skip.
            /// </summary>
            public int Skip { get; set; }

            /// <summary>
            /// Specifies the requested sort order.
            /// </summary>
            public IEnumerable<Sort> Sort { get; set; }

            /// <summary>
            /// Specifies the requested filter.
            /// </summary>
            public Filter Filter { get; set; }
        }
        [DataContract(Name = "aggregate")]
        public class Aggregator
        {
            /// <summary>
            /// Gets or sets the name of the aggregated field (property).
            /// </summary>
            [DataMember(Name = "field")]
            public string Field { get; set; }

            /// <summary>
            /// Gets or sets the aggregate.
            /// </summary>
            [DataMember(Name = "aggregate")]
            public string Aggregate { get; set; }

            /// <summary>
            /// Get MethodInfo.
            /// </summary>
            /// <param name="type">Specifies the type of querable data.</param>
            /// <returns>A MethodInfo for field.</returns>
            public MethodInfo MethodInfo(Type type)
            {
                var proptype = type.GetProperty(Field).PropertyType;
                switch (Aggregate)
                {
                    case "max":
                    case "min":
                        return GetMethod(CultureInfo.InvariantCulture.TextInfo.ToTitleCase(Aggregate), MinMaxFunc().Method, 2).MakeGenericMethod(type, proptype);
                    case "average":
                    case "sum":
                        return GetMethod(CultureInfo.InvariantCulture.TextInfo.ToTitleCase(Aggregate),
                            ((Func<Type, Type[]>)this.GetType().GetMethod("SumAvgFunc", BindingFlags.Static | BindingFlags.NonPublic)
                            .MakeGenericMethod(proptype).Invoke(null, null)).Method, 1).MakeGenericMethod(type);
                    case "count":
                        return GetMethod(CultureInfo.InvariantCulture.TextInfo.ToTitleCase(Aggregate),
                            Nullable.GetUnderlyingType(proptype) != null ? CountNullableFunc().Method : CountFunc().Method, 1).MakeGenericMethod(type);
                }
                return null;
            }

            private static MethodInfo GetMethod(string methodName, MethodInfo methodTypes, int genericArgumentsCount)
            {
                var methods = from method in typeof(Queryable).GetMethods(BindingFlags.Public | BindingFlags.Static)
                              let parameters = method.GetParameters()
                              let genericArguments = method.GetGenericArguments()
                              where method.Name == methodName &&
                                genericArguments.Length == genericArgumentsCount &&
                                parameters.Select(p => p.ParameterType).SequenceEqual((Type[])methodTypes.Invoke(null, genericArguments))
                              select method;
                return methods.FirstOrDefault();
            }

            private static Func<Type, Type[]> CountNullableFunc()
            {
                return (T) => new[]
                    {
                    typeof(IQueryable<>).MakeGenericType(T),
                    typeof(Expression<>).MakeGenericType(typeof(Func<,>).MakeGenericType(T, typeof(bool)))
                };
            }

            private static Func<Type, Type[]> CountFunc()
            {
                return (T) => new[]
                    {
                    typeof(IQueryable<>).MakeGenericType(T)
                };
            }

            private static Func<Type, Type, Type[]> MinMaxFunc()
            {
                return (T, U) => new[]
                    {
                    typeof (IQueryable<>).MakeGenericType(T),
                    typeof (Expression<>).MakeGenericType(typeof (Func<,>).MakeGenericType(T, U))
                };
            }

            private static Func<Type, Type[]> SumAvgFunc<U>()
            {
                return (T) => new[]
                    {
                    typeof (IQueryable<>).MakeGenericType(T),
                    typeof (Expression<>).MakeGenericType(typeof (Func<,>).MakeGenericType(T, typeof(U)))
                };
            }
        }


        [DataContract]
        public class Filter
        {
            /// <summary>
            /// Gets or sets the name of the sorted field (property). Set to <c>null</c> if the <c>Filters</c> property is set.
            /// </summary>
            [DataMember(Name = "field")]
            public string Field { get; set; }

            /// <summary>
            /// Gets or sets the filtering operator. Set to <c>null</c> if the <c>Filters</c> property is set.
            /// </summary>
            [DataMember(Name = "operator")]
            public string Operator { get; set; }

            /// <summary>
            /// Gets or sets the filtering value. Set to <c>null</c> if the <c>Filters</c> property is set.
            /// </summary>
            [DataMember(Name = "value")]
            public object Value { get; set; }

            /// <summary>
            /// Gets or sets the filtering logic. Can be set to "or" or "and". Set to <c>null</c> unless <c>Filters</c> is set.
            /// </summary>
            [DataMember(Name = "logic")]
            public string Logic { get; set; }

            /// <summary>
            /// Gets or sets the child filter expressions. Set to <c>null</c> if there are no child expressions.
            /// </summary>
            [DataMember(Name = "filters")]
            public IEnumerable<Filter> Filters { get; set; }

            /// <summary>
            /// Mapping of Kendo DataSource filtering operators to Dynamic Linq
            /// </summary>
            private static readonly IDictionary<string, string> operators = new Dictionary<string, string>
        {
            {"eq", "="},
            {"neq", "!="},
            {"lt", "<"},
            {"lte", "<="},
            {"gt", ">"},
            {"gte", ">="},
            {"startswith", "StartsWith"},
            {"endswith", "EndsWith"},
            {"contains", "Contains"},
            {"doesnotcontain", "Contains"}
        };

            /// <summary>
            /// Get a flattened list of all child filter expressions.
            /// </summary>
            public IList<Filter> All()
            {
                var filters = new List<Filter>();

                Collect(filters);

                return filters;
            }

            private void Collect(IList<Filter> filters)
            {
                if (Filters != null && Filters.Any())
                {
                    foreach (Filter filter in Filters)
                    {
                        filters.Add(filter);

                        filter.Collect(filters);
                    }
                }
                else
                {
                    filters.Add(this);
                }
            }

            /// <summary>
            /// Converts the filter expression to a predicate suitable for Dynamic Linq e.g. "Field1 = @1 and Field2.Contains(@2)"
            /// </summary>
            /// <param name="filters">A list of flattened filters.</param>
            public string ToExpression(IList<Filter> filters)
            {
                if (Filters != null && Filters.Any())
                {
                    return "(" + String.Join(" " + Logic + " ", Filters.Select(filter => filter.ToExpression(filters)).ToArray()) + ")";
                }

                int index = filters.IndexOf(this);

                string comparison = operators[Operator];

                if (Operator == "doesnotcontain")
                {
                    return String.Format("!{0}.{1}(@{2})", Field, comparison, index);
                }

                if (comparison == "StartsWith" || comparison == "EndsWith" || comparison == "Contains")
                {
                    return String.Format("{0}.{1}(@{2})", Field, comparison, index);
                }

                return String.Format("{0} {1} @{2}", Field, comparison, index);
            }
        }
        [DataContract]
        public class Sort
        {
            /// <summary>
            /// Gets or sets the name of the sorted field (property).
            /// </summary>
            [DataMember(Name = "field")]
            public string Field { get; set; }

            /// <summary>
            /// Gets or sets the sort direction. Should be either "asc" or "desc".
            /// </summary>
            [DataMember(Name = "dir")]
            public string Dir { get; set; }

            /// <summary>
            /// Converts to form required by Dynamic Linq e.g. "Field1 desc"
            /// </summary>
            public string ToExpression()
            {
                return Field + " " + Dir;
            }
        }


    }

}
