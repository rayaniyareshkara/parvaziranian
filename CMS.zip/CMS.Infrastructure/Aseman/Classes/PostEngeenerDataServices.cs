﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Mohandesan.Interfaces;

namespace CMS.Infrastructure.Mohandesan.Classes
{
  public  class PostEngeenerDataServices : ConversionMain<PostEngeener, int>, IPostEngeener
    {
        public PostEngeenerDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<PostEngeener, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
