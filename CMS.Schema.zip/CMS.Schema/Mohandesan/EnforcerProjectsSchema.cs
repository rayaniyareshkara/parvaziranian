﻿

using System;
using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
    public class EnforcerProjectsSchema
    {
        public List<string> Images { get; set; }
        public string Description { get; set; }
        public Guid Id { get; set; }
    }
}
