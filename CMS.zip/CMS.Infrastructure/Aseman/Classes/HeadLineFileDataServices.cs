﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class HeadLineFileDataServices : ConversionMain<HeadLineFile, int>, IHeadLineFile
    {
        public HeadLineFileDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<HeadLineFile, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
