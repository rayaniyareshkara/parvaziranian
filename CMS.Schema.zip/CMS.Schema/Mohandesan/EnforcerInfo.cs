﻿
using System.Collections.Generic;


namespace CMS.Schema.Mohandesan
{
    public class EnforcerInfo
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        //public int Field { get; set; }
        public int Grade { get; set; }
        public bool IsDesign { get; set; }
        public int Order { get; set; }
        public string FieldName { get; set; }
        public bool IsImplementation { get; set; }
        public bool IsSupervision { get; set; }
        public string Image { get; set; }
        public List<LawFirmInFields> Field { get; set; }
        public string AboutMe { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public List<EnforcerActivityShcema> Activity { get; set; }
        public List<EnforcerProjectsSchema> Projects { get; set; }
        public List<LicenseShcema> License { get; set; }

        public bool? IsJobSeeker { get; set; }
        public List<ModirGradeSchema> grades { get; set; }
        public List<ModirSheetSchema> sheet { get; set; }
        public List<ModirSheetSchema> design { get; set; }


    }

    public class EnforcerGrades
    {
        public string Grade { get; set; }
        public int Field { get; set; }
        public int FieldCode { get; set; }
        public string FieldName { get; set; }
        public int GradeId { get; set; }
        public int Type { get; set; }
    }

}
