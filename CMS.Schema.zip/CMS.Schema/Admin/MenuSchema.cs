﻿
using System;

namespace CMS.Schema.Admin
{
    public class MenuSchema
    {
        public bool? Default { get; set; }
        public string Description { get; set; }
        public Guid Id { get; set; }
        public int Language { get; set; }
        public int? Order { get; set; }
        public Guid? ParentId { get; set; }
        public string Source { get; set; }
        public Guid? SourceKey { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
    }
}
