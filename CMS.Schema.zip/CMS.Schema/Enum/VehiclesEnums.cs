﻿namespace CMS.Schema.Enum
{
    /// <summary>
    /// if(Value==1)
    /// {
    /// Airplane="هواپیما"
    /// }
    /// if(Value==2)
    /// {
    /// Train="قطار"
    /// }
    /// if(Value==3)
    /// {
    /// Bus="اتوبوس"
    /// }
    /// if(Value==4)
    /// {
    /// Car="ماشین شخصی"
    /// }
    /// if(Value==5)
    /// {
    /// Other="سایر"
    /// }
    /// </summary>
    public enum VehiclesEnums
    {

        Airplane = 1,
        Train = 2,
        Bus = 3,
        Car = 4,
        Other = 5

    }
}
