﻿
namespace CMS.Schema.Mohandesan
{
   public class VisitCountCart
    {
        public int Id { get; set; }
        public int Count { get; set; }
        public int Price { get; set; }
    }
}
