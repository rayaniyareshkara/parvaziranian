﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Enum
{
    public enum RegisterTypeEnum
    {
        [Display(Name = "حقیقی")]
        Real = 1,
        [Display(Name = "حقوقی")]
        Legal = 2
    }
}
