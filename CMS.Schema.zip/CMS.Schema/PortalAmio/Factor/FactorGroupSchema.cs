﻿using System;
using System.Collections.Generic;

namespace CMS.Schema.PortalAmio.Factor
{
    public class FactorGroupSchema
    {
        public InformationFactor InformationFactor { get; set; }

        public InformationApply InformationApply { get; set; }
    }

    public class InformationFactor
    {
        public string CreationTime { get; set; }

        public int FactorId { get; set; }

        public string Title { get; set; }
        public string CustomerName { get; set; }

        public string InvoiceNumber { get; set; }

        public string Amount { get; set; }

        public string Price { get; set; }

        public string Discount { get; set; }

        public string Taxation { get; set; }

        public string CollectAfterDiscount { get; set; }
        public bool StatusPay { get; set; }


    }

    public class InformationApply
    {
        public string Title { get; set; }

        public string Price { get; set; }

        public string Unit { get; set; }

        public string Amount { get; set; }

        public string Count { get; set; }

    }
}
