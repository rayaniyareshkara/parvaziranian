﻿
using System;

namespace CMS.Schema.Mohandesan
{
    public class EnforcerActivityShcema
    {
        public string Time { get; set; }
        public string Description { get; set; }
        public Guid Id { get; set; }
    }
}
