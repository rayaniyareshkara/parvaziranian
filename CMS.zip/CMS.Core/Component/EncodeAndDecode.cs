﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace CMS.Core.Component
{
    public class EncodeAndDecode
    {
        public string Encode(string strEncode)
        {
            if (!string.IsNullOrEmpty(strEncode))
            {
                byte[] keyArray;
                byte[] toEncryptArray = ASCIIEncoding.ASCII.GetBytes(strEncode);
                string key = new Schema.SecurityCode().CodeDigit;

                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(key));
                hashmd5.Clear();

                TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
                tdes.Key = keyArray;
                tdes.Mode = CipherMode.ECB;

                tdes.Padding = PaddingMode.PKCS7;

                ICryptoTransform cTransform = tdes.CreateEncryptor();
                byte[] resultArray =
                  cTransform.TransformFinalBlock(toEncryptArray, 0,
                  toEncryptArray.Length);
                tdes.Clear();

                return Convert.ToBase64String(resultArray, 0, resultArray.Length).Replace("=", "___");

            }
            else
                return null;
        }

        public string Decode(string strDecode)
        {
            if (!string.IsNullOrEmpty(strDecode))
            {
                byte[] keyArray;
                byte[] toEncryptArray = Convert.FromBase64String(strDecode.Replace("___", "="));
                string key = new Schema.SecurityCode().CodeDigit;

                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(key));
                hashmd5.Clear();

                TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
                tdes.Key = keyArray;
                tdes.Mode = CipherMode.ECB;
                tdes.Padding = PaddingMode.PKCS7;

                ICryptoTransform cTransform = tdes.CreateDecryptor();
                byte[] resultArray = cTransform.TransformFinalBlock(
                                     toEncryptArray, 0, toEncryptArray.Length);
                tdes.Clear();

                return ASCIIEncoding.ASCII.GetString(resultArray);
            }
            else
                return null;
        }
    }

}
