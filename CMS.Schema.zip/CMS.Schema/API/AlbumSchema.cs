﻿

namespace CMS.Schema.API
{
    public class AlbumSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
    }
}
