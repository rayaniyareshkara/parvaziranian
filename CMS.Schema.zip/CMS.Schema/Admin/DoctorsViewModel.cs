﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Admin
{
    public class DoctorsViewModel
    {
        public DoctorsViewModel()
        {
            InfoPerLanguages = new Dictionary<string, DoctorPersonalInfo>();
        }

        public Guid Id { get; set; }

        //[StringLength(maximumLength: 50, MinimumLength = 5, ErrorMessageResourceName = "minandmax"/*, ErrorMessageResourceType = typeof(GlobalResources)*/)]
        //[Required(ErrorMessageResourceName = "requiredfield"/*, ErrorMessageResourceType = typeof(GlobalResources)*/)]
        [Display(Name = "email"/*, ResourceType = typeof(GlobalResources)*/)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Display(Name = "telephone"/*, ResourceType = typeof(GlobalResources)*/)]
        [DataType(DataType.PhoneNumber)]
        public string Telephone { get; set; }

        //[Display(Name = "imageUrl"/*, ResourceType = typeof(GlobalResources)*/)]
        //public int ImageUrl { get; set; }

        public Dictionary<string, DoctorPersonalInfo> InfoPerLanguages { get; set; }

        [Display(Name = "isactive"/*, ResourceType = typeof(GlobalResources)*/)]
        public bool IsActive { get; set; }

  
    }

}
