﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class MobileCheckDataServices : ConversionMain<MobileCheck, int>, IMobileCheck
    {
        public MobileCheckDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<MobileCheck, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
