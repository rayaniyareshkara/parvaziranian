﻿using System.Web.Mvc;
using static CMS.Core.Component.SetCookie;
using CMS.Schema;

namespace CMS.Core.Attribute
{
    public class ModirAuthorizeCMS : ActionFilterAttribute, IActionFilter
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (ValueCookie(new Coockie { BehinNewsaadCMS = CoockieEnum.ModirBehinNewsaadCMS }) == null)
                filterContext.Result = new RedirectResult("/fa/Account/Login?returnUrl=" + filterContext.HttpContext.Request.CurrentExecutionFilePath);

            base.OnActionExecuting(filterContext);
        }
    }
}