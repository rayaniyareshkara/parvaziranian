﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class CourseTermTimeDataServices : ConversionMain<CourseTermTime, int>, ICourseTermTime
    {
        public CourseTermTimeDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<CourseTermTime, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
