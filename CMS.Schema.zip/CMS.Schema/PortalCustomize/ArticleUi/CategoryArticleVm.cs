﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalCustomize.ArticleUi
{
    public class CategoryArticleVm
    {
        public string Title { get; set; }

        public string Count { get; set; }

        public string Url { get; set; }
    }
}
