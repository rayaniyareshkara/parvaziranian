﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
 public   class DegreeTimeSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Day { get; set; }
        public string Time { get; set; }
    }
}
