﻿using System.Collections.Generic;
using System.Linq;

namespace CMS.Core.Helper
{
    public class LanguageHelper
    {
        public List<string> ListLanguage(int[] pageId, string lang)
        {
            return CMS.Core.Component.Language.Instance.ResourceList.Where(w => pageId.Contains(w.Id) && w.Suffix.ToLower() == lang.ToLower()).Select(s => s.Description).ToList();
        }
    }
}
