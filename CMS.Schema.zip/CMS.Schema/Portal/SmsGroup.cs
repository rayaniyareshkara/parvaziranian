﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
   public class SmsGroup
    {
        [Key]
        [ScaffoldColumn(false)]
        public int Id { get; set; }

        [Display(Name ="نام گروه")]
        [Required(ErrorMessage ="نام گروه را وارد کنید")]
        public string GroupName { get; set; }

        [Display(Name ="توضیحات")]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

    }
}
