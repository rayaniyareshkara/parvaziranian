﻿
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class AboutHotelViewModel
    {
        public string Title { get; set; }
        public string Caption { get; set; }
        public string BackgroundImage { get; set; }
        public string Hotel { get; set; }
        public string Description { get; set; }
        public string AmozeshTitle { get; set; }
        public string AmozeshDescription { get; set; }
        public string AmozeshImage { get; set; }
        public List<AboutProductSchema> products { get; set; }

    }

    
}
