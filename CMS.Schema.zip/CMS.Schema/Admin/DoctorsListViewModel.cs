﻿using System.Collections.Generic;

namespace CMS.Schema.Admin
{
    public class DoctorsListViewModel
    {
        public int CurrentPage { get; set; }
        public IEnumerable<DoctorsSchema> DoctorsList { get; set; }
    }
}
