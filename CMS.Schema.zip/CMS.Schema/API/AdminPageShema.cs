﻿

using CMS.Schema.Admin;
using System;
using System.Collections.Generic;

namespace CMS.Schema.API
{
    public class AdminPageShema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public string Code { get; set; }
    }


    public class AdminPagePermissionShema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int GroupId { get; set; }
        public string Code { get; set; }
        public List<PermissonEnum> Operations { get; set; } = new List<PermissonEnum>();
    }

    public class AdminPagePermissionPeruserShema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Guid UserId { get; set; }
        public string Code { get; set; }
        public List<PermissonEnum> Operations { get; set; } = new List<PermissonEnum>();
    }
}
