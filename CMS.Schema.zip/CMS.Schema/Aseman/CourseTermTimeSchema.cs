﻿using CMS.FrameWork.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class CourseTermTimeSchema
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public string MasterName { get; set; }
        public int? MasterId { get; set; }
        public string BranchName { get; set; }
        public int? BranchId { get; set; }
        public string DegreeTermName { get; set; }
        public int? DegreeTermId { get; set; }
        public string CourseTermName { get; set; }
        public int? CourseTermId { get; set; }  
        public string MainCourseTermName { get; set; }
        public int? MainCourseTermId { get; set; }

        public int StatusId { get; set; }
        public int? Count { get; set; }
        public string StartDate { get; set; }
        public int? BranchClassId { get; set; }
        public string BranchClassName { get; set; }
        public string EndDate { get; set; }
        public DateTime StartDateOrginal { get; set; }
        public DateTime EndDateOrginal { get; set; }


       // public List<CourseTermStudentCheck> courseTermStudentCheck { get; set; }
    }
}
