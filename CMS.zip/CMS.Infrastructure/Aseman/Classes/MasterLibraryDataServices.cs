﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;


namespace CMS.Infrastructure.Aseman.Classes
{
   public  class MasterLibraryDataServices : ConversionMain<MasterLibrary, int>, IMasterLibrary
    {
        public MasterLibraryDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<MasterLibrary, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
