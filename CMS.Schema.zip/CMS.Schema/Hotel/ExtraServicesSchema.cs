﻿
namespace CMS.Schema.Hotel
{
    public class ExtraServicesSchema
    {
        public int Id { get; set; }
        public int Count { get; set; }
        public string Date { get; set; }
        public string Description { get; set; }
        public string Time { get; set; }
    }
}
