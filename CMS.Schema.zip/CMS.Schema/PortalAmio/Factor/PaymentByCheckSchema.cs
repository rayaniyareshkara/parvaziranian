﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalAmio.Factor
{
    public class PaymentByCheckSchema
    {
        [DisplayName("فاکتور درخواستی")]
        [Required(ErrorMessage = "{0} الزامی است")]

        public int FactorId { get; set; }
        [DisplayName("تصویر چک")]
        [Required(ErrorMessage = "{0} الزامی است")]

        public string ImageCheck { get; set; }
        [DisplayName("شماره چک")]
        public string CheckNumber { get; set; }
    }
}
