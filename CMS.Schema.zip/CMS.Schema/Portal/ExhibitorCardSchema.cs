﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
 public   class ExhibitorCardSchema
    {
        public string FullNameFa { get; set; }
        public string FullNameEn { get; set; }
       public string FileName { get; set; }
        public int ExhibitionId { get; set; }
    }  
}
