﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
   public class ExamTakesChema
    {
        public int QuestionId { get; set; }
        public string QuestionText  { get; set; }
        public string QuestionCode { get; set; }
        public string Answer1 { get; set; }
        public string Answer2 { get; set; }
        public string Answer3 { get; set; }
        public string Answer4 { get; set; }
        public string audio { get; set; }
        public string Image { get; set; }
        public string Video { get; set; }
        public int Status { get; set; }
        public string Answer { get; set; }
    }
}
