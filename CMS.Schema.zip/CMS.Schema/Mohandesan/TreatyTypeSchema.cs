﻿

namespace CMS.Schema.Mohandesan
{
    public class TreatyTypeSchema
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string ParentId { get; set; }
        
    }
}
