﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class CourseTermQuizAddSchema
    {     
        public int QuizId { get; set; }
        public int CourseTermId { get; set; }

        public string Title { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
            
        public bool Isactive { get; set; }
        public bool ShowQuestion { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        

    }

   
}
