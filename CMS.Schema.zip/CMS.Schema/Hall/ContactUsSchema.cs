﻿namespace CMS.Schema.Hall
{
    public class ContactUsSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Text { get; set; }
        public string HotelName { get; set; }
        public int? HotelId { get; set; }
        public string PageLink { get; set; }
        public string Date { get; set; }
        public string AnswerDate { get; set; }
        public bool hasHanswer { get; set; }
        public string Message { get; set; }
        public string User { get; set; }

    }
}
