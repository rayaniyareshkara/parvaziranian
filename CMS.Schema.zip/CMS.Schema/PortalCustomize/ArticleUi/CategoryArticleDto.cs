﻿namespace CMS.Schema.PortalCustomize.ArticleUi
{
    public class CategoryArticleDto
    {
        public string Title { get; set; }

        public int Count { get; set; }

        public string Url { get; set; }
    }
}
