﻿

namespace CMS.Schema.Hotel
{
    public class HotelServiceSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Icon { get; set; }
        public string Brief { get; set; }
        public string Time { get; set; }
        public int Price { get; set; }
        public int TotalCount { get; set; }
        public bool IsTotal_Price { get; set; }
        public bool? IsActive { get; set; }
        public string IsTotalPrice { get; set; }
        public string Unit { get; set; }
        public string TicketDescription { get; set; }
        public string Tour { get; set; }
        public string Image { get; set; }
    }

    public class HotelServiceTimeSChema
    {
        public int Id { get; set; }
        public string To { get; set; }
        public string From { get; set; }
        public int ServiceId { get; set; }
    }

    public class HotelServiceExtraTimeSChema
    {
        public int Id { get; set; }
        public int ServiceId { get; set; }
        public string Description { get; set; }
        public int Count { get; set; }
        public int Time { get; set; }
        public string Date { get; set; }
     

    }

}
