﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class InvestmentRequestSchema
    {
        public int Id { get; set; }
        public int? Status { get; set; }
        public string StatusName { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
    }
}
