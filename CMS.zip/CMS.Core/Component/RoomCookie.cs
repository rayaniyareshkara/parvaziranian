﻿
using CMS.Schema.Hotel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CMS.Core.Component
{
    public class RoomCookie
    {
        public string name = "rur";
        public HttpCookie coockie;
        private EncodeAndDecode encoder = new EncodeAndDecode();
        public RoomCookie()
        {
            if (HttpContext.Current.Request.Cookies[name] != null)
                coockie = HttpContext.Current.Request.Cookies[name];
            else
                coockie = new HttpCookie(name, encoder.Encode(JsonConvert.SerializeObject(new List<RoomBasketSchema>())));
        }

        public void addToCookie(int room, int count, string fromDate, string endDate, int TotalDays, int additinalPerson, int ChildAdditionalPerson = 0)
        {
            List<RoomBasketSchema> values = getValue();

            var item = values.FirstOrDefault(w => w.room == room);
            if (item == null)
                values.Add(new RoomBasketSchema { room = room, count = count, EndDate = endDate, StartDate = fromDate, TotalDays = TotalDays, AdditionalPerson = additinalPerson, ChildAdditionalPerson = ChildAdditionalPerson });
            else
            { item.count = count; item.StartDate = fromDate; item.EndDate = endDate; item.AdditionalPerson = additinalPerson; item.ChildAdditionalPerson = ChildAdditionalPerson; }

            coockie.Values["items"] = encoder.Encode(JsonConvert.SerializeObject(values));
            HttpContext.Current.Response.Cookies.Add(coockie);
        }

        public void removefromCookie(int room)
        {
            List<RoomBasketSchema> values = getValue();
            var item = values.FirstOrDefault(w => w.room == room);
            if (item != null)
                values.Remove(item);

            coockie.Values["items"] = encoder.Encode(JsonConvert.SerializeObject(values));
            HttpContext.Current.Response.Cookies.Add(coockie);
        }

        public void removeall(int room)
        {
           //  List<RoomBasketSchema> values = getValue();
            // coockie.Value = encoder.Encode(JsonConvert.SerializeObject(new List<RoomBasketSchema>()));
            // overwrite the cookie
          

            var httpContext = new HttpContextWrapper(HttpContext.Current);
            var _response = httpContext.Response;

            HttpCookie cookie = new HttpCookie(name)
            {
                Expires = DateTime.Now.AddDays(-1), // or any other time in the past,
                Value = null,
            };
            _response.Cookies.Set(cookie);


            coockie = new HttpCookie(name);
            coockie.Values["items"] = encoder.Encode(JsonConvert.SerializeObject(new List<RoomBasketSchema>()));

            HttpContext.Current.Response.Cookies.Add(coockie);
        }

        public List<RoomBasketSchema> getValue()
        {
            try
            {
                return JsonConvert.DeserializeObject<List<RoomBasketSchema>>(encoder.Decode(coockie.Values["items"]) ?? "");
            }
            catch (Exception )
            {
                return new List<RoomBasketSchema>();
            }

        }
    }
}
