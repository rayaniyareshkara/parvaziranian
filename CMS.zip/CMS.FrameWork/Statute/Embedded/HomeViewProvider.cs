﻿using CMS.FrameWork.Statute.Embedded.Repository;
using System;
using System.IO;
using System.Linq;
using System.Reflection;

namespace CMS.FrameWork.Statute.Embedded
{
    public class HomeViewProvider : IViewProvider
    {
        private readonly Assembly _executingAssembly;

        public HomeViewProvider()
        {
            _executingAssembly = Assembly.GetExecutingAssembly();
        }

        public bool FileExists(string virtualPath)
        {
            var returnValue = IsEmbeddedResourcePath(virtualPath);
            return returnValue;
        }

        public bool IsEmbeddedResourcePath(string virtualPath)
        {
            var assemblyResourceNames = _executingAssembly
                .GetManifestResourceNames();
            var resourceName = GetResourceName(virtualPath);
            var returnValue = assemblyResourceNames
                .Contains(resourceName, StringComparer.OrdinalIgnoreCase);

            return returnValue;
        }

        public Stream Open(string mPath)
        {
            if (mPath.StartsWith("~")) mPath = mPath.Substring(1);
            if (!mPath.StartsWith("/")) mPath = string.Concat("/", mPath);
            var resourceName = GetResourceName(mPath);

            var returnValue = _executingAssembly.GetManifestResourceStream(resourceName);

            return returnValue;
        }

        private string GetResourceName(string virtualPath)
        {
            var returnValue = string.Concat(_executingAssembly.GetName().Name
                , virtualPath.Replace("/", "."));

            return returnValue;
        }
    }
}
