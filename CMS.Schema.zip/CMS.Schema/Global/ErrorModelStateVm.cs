﻿namespace CMS.Schema.Global
{
    public class ErrorModelStateVm
    {
        public string ErrorMessage { get; set; }

        public string Key { get; set; }
    }
}
