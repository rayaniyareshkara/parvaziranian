﻿using System;
using System.Collections.Generic;

namespace CMS.Schema.PortalAmio.ExhibitionUi
{
    public class ExhibitionDetailsInformationDto
    {
        
        public string RightBannerImage { get; set; }

        public string LeftBannerImage { get; set; }

        public string CenterBannerImage { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string VisitingTime { get; set; }

        public string HoldingSpace { get; set; }

        public string MetaKeyWord { get; set; }

        public string MetaDescription { get; set; }

        public string PageTitle { get; set; }

        public string ExhibitionType { get; set; }

        public string Summery { get; set; }

        public string Caption { get; set; }

        public string Image { get; set; }

        public string Place { get; set; }

        public string Description { get; set; }

        public int Id { get; set; }

        public int? NewsCategoryId { get; set; }

        public string Url { get; set; }

        public int? IdRow { get; set; }

        public bool IsRegisterActive { get; set; }


        public List<ExhibitionGalleryDto> Gallery { get; set; }
    }
}
