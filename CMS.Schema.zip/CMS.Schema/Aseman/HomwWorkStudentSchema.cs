﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class HomwWorkStudentSchema
    {
        public int Id { get; set; }
        public int CourseTermTimeId { get; set; }  
        public string Title { get; set; }
        public string AcceptDate { get; set; }
        public DateTime? AcceptDateMain { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public List<StudentWork> StudentWorkList { get; set; }

    }
    public class StudentWork 
    {
        public int Id { get; set; }
        public string Decription { get; set; }
        public string Image { get; set; }
        public int Status { get; set; }
        public string StatusName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Guid UserId { get; set; }
    }
}
