﻿using CMS.FrameWork.Model;
using System.Collections.Generic;
using System.Linq;

namespace CMS.Core.Component
{
    public class StartupConfigs
    {

        public FrameWork.Model.Language[] Languages { get; set; }
        public List<string> LangInitList { get; set; }
        private static StartupConfigs _instance;

        public static StartupConfigs Instance
        {
            get
            {
                if (_instance?.Languages != null)
                    return _instance;

                _instance = new StartupConfigs();
                Refresh();
                return _instance;
            }
        }

        private StartupConfigs()
        {

        }

        private static void Refresh()
        {
            var context = new EntitysModelCMS();

            //var ii = context.Galleries_Images.ToList();
            _instance.Languages = context.Languages.ToArray();
            _instance.LangInitList = new List<string>();
            foreach (var item in _instance.Languages)
            {
                _instance.LangInitList.Add(item.Init);
            }
            //_instance.LangList.Add("xx");
        }

    }
}

