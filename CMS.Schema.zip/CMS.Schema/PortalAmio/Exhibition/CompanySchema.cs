﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
  public  class CompanySchema
    {
        public int Id { get; set; }
        public String Name { get; set; }
    }
}
