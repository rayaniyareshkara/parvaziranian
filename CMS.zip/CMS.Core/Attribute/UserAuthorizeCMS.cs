﻿using CMS.Schema;
using System.Web.Mvc;
using static CMS.Core.Component.SetCookie;

namespace CMS.Core.Attribute
{
    public class UserAuthorizeCMS : ActionFilterAttribute, IActionFilter
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (ValueCookie(new Coockie { BehinNewsaadCMS = CoockieEnum.UsersBehinNewsaadCMS }) == null)
                filterContext.Result = new RedirectResult("/fa/Login2/index?returnUrl=" + filterContext.HttpContext.Request.CurrentExecutionFilePath);

            base.OnActionExecuting(filterContext);
        }
    }
}
