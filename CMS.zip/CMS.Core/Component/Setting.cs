﻿using System.Collections.Generic;
using System.Linq;
using CMS.FrameWork.Model;

namespace CMS.Core.Component
{
    public class Setting
    {
        public FrameWork.Model.Language[] Languages { get; set; }
        public List<string> LangInitList { get; set; }
        private static Setting _instance;

        public static Setting Instance
        {
            get
            {
                if (_instance != null) 
                    return _instance;

                _instance = new Setting();
                Refresh();
                return _instance;
            }
        }

        private Setting()
        {

        }

        private static void Refresh()
        {
            var context = new EntitysModelCMS();

            //var ii = context.Galleries_Images.ToList();
            _instance.Languages = context.Languages.ToArray();
            _instance.LangInitList = new List<string>();
            foreach (var item in _instance.Languages)
            {
                _instance.LangInitList.Add(item.Init);
            }
            //_instance.LangList.Add("xx");
        }
    }
}
