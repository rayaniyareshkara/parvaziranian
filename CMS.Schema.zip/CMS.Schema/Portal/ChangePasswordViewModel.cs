﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class ChangePasswordViewModel
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = @"رمز عبور فعلی")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = @"The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = @"رمز عبور جدید")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = @"تکرار رمز عبور جدید")]
        [Compare("NewPassword", ErrorMessage = @"رمز جدید و تکرار رمز جدید یکسان نیست")]
        public string ConfirmPassword { get; set; }
    }
    public class ChangePasswordViewModel2
    {
        [Required]
        [StringLength(100, ErrorMessage = @"The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = @"رمز عبور جدید")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = @"تکرار رمز عبور جدید")]
        [Compare("NewPassword", ErrorMessage = @"رمز جدید و تکرار رمز جدید یکسان نیست")]
        public string ConfirmPassword { get; set; }

        public string UserName { get; set; }
    }

}
