﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
  public  class ExamTypeSchema
    {
         public int RecordIDId { get; set; }
        public string Title { get; set; } 
        public string Description { get; set; }
    }
}
