﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
  public   class QuestionSetListSchema
    {
       
        public int QuestionID { get; set; }
        public int QuestionSetID { get; set; }
        public int Periority { get; set; }
    }
}
