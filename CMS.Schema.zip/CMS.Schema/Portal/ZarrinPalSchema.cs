﻿using System;

namespace CMS.Schema.Portal
{
    [Serializable]
    public class ZarrinPalSchema
    {
        private string _merceId;
        public string merceId
        {
            get { return Cypher.Decrypt(_merceId); }
            set { _merceId = Cypher.Encrypt(value); }
        }
        public bool IsActive { get; set; }
    }
}
