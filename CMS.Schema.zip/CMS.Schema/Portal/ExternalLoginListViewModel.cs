﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }

}
