﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
  public  class ParkingCardSchema
    {
        public string LicensePlate { get; set; }
        public string Color { get; set; }
        public string Model { get; set; }
        public int ExhibitionId { get; set; }

    }
}
