﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalAmio.Place
{
    public class PlaceGridSchema
    {
        public int Id { get; set; }
      
        public string Title { get; set; }

        public string Lang { get; set; }

        public string Time { get; set; }

        public string Status { get; set; }   
    }
}
