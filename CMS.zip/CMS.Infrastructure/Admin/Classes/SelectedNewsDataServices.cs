﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Admin.Interfaces;

namespace CMS.Infrastructure.Admin.Classes
{
 public   class SelectedNewsDataServices : ConversionMain<SelectedNew, int>, ISelectedNews
    {
        public SelectedNewsDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<SelectedNew, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}

