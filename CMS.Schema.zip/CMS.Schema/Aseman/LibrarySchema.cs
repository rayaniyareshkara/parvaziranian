﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class LibrarySchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Link { get; set; } 
        public string Author { get; set; }
        public string Description { get; set; }
      
        public string Image { get; set; }
    }
}
