﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace CMS.Core.Helper
{
    public static class HttpPostedFileBaseExtensions
    {
        public const int ImageMinimumBytes = 70;

        public static bool IsImage(this HttpPostedFileBase postedFile)
        {
            //-------------------------------------------
            //  Check the image mime types
            //-------------------------------------------
            if (postedFile.ContentType.ToLower() != "image/jpg" &&
                        postedFile.ContentType.ToLower() != "image/jpeg" &&
                        postedFile.ContentType.ToLower() != "image/pjpeg" &&
                        postedFile.ContentType.ToLower() != "image/gif" &&
                        postedFile.ContentType.ToLower() != "image/x-png" &&
                        postedFile.ContentType.ToLower() != "image/png")
            {
                return false;
            }

            //-------------------------------------------
            //  Check the image extension
            //-------------------------------------------
            var extension = Path.GetExtension(postedFile.FileName);
            if (extension != null && (extension.ToLower() != ".jpg"
                && extension.ToLower() != ".png"
                && extension.ToLower() != ".gif"
                && extension.ToLower() != ".jpeg"))
            {
                return false;
            }

            //-------------------------------------------
            //  Attempt to read the file and check the first bytes
            //-------------------------------------------
            try
            {
                if (!postedFile.InputStream.CanRead)
                {
                    return false;
                }

                if (postedFile.ContentLength < ImageMinimumBytes)
                {
                    return false;
                }

                byte[] buffer = new byte[postedFile.ContentLength];
                postedFile.InputStream.Read(buffer, 0, postedFile.ContentLength);
                string content = System.Text.Encoding.UTF8.GetString(buffer);
                if (Regex.IsMatch(content, @"<script|<html|<head|<title|<body|<pre|<table|<a\s+href|<img|<plaintext|<cross\-domain\-policy",
                    RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Multiline))
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }

            //-------------------------------------------
            //  Try to instantiate new Bitmap, if .NET will throw exception
            //  we can assume that it's not a valid image
            //-------------------------------------------

            try
            {
                using (var bitmap = new System.Drawing.Bitmap(postedFile.InputStream))
                {
                }
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        public static bool IsExcel(this HttpPostedFileBase postedFile)
        {
            return postedFile.ContentType.ToLower().Contains("./xlsx") ||
                   postedFile.ContentType.ToLower()
                       .Contains("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") ||
                   postedFile.ContentType.ToLower().Contains("application/vnd.ms-excel");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="postedFile"></param>
        /// <returns></returns>
        public static bool IsValidFileSubmitUser(this HttpPostedFileBase postedFile)
        {
            return postedFile.ContentType.ToLower().Contains("image/jpg") ||
                   postedFile.ContentType.ToLower().Contains("image/png") ||
                   postedFile.ContentType.ToLower().Contains("image/jpeg") ||
                   postedFile.ContentType.ToLower().Contains("application/pdf") ||
                   postedFile.ContentType.ToLower().Contains("application/zip") ||
                   postedFile.ContentType.ToLower().Contains("application/octet-stream");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="postedFile"></param>
        /// <returns></returns>
        public static string GetContentTypeFile(this HttpPostedFileBase postedFile)
        {
            if (postedFile == null)
                return null;

            var type = postedFile.ContentType;
            string typeReturn = null;
            switch (type)
            {
                case "application/pdf":
                    typeReturn = ".pdf";
                    break;
                case "image/jpeg":
                    typeReturn = ".jpeg";
                    break;
                case "image/jpg":
                    typeReturn = ".jpg";
                    break;
                case "image/png":
                    typeReturn = ".png";
                    break;
                case "application/zip":
                    typeReturn = ".zip";
                    break;
                case "application/octet-stream":
                    typeReturn = ".zip";
                    break;
            }


            return typeReturn;
        }
    }

}
