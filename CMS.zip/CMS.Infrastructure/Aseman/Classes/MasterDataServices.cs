﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;


namespace CMS.Infrastructure.Aseman.Classes
{
  public  class MasterDataServices : ConversionMain<Master, int>, IMaster
    {
        public MasterDataServices(EntitysModelCMS context) : base(context)
        {
        }

        public override Expression<Func<Master, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
