﻿namespace CMS.Schema.PortalCustomize.Article
{
    public class LocationBookGridSchema
    {
        public int Id { get; set; }

        public string Caption { get; set; }

        public string Active { get; set; }

        public string Exhibition { get; set; }

        public int Count { get; set; }

    }
}
