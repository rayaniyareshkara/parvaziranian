﻿

namespace CMS.Schema.Hotel
{
    public class RoomBasketSchema
    {
        public int room { get; set; }
        public int count { get; set; } = 1;
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public int TotalDays { get; set; }
        public int AdditionalPerson { get; set; }
        public int ChildAdditionalPerson { get; set; }
    }


    public class RoomPricechema
    {
        public int Room { get; set; }
        public int Price { get; set; }
        public int PriceExtra { get; set; }
        public int AdditionalPerson { get; set; }
        public int Count { get; set; }
    }
}
