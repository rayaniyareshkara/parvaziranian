﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
   public class ExamSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string Code { get; set; }
        public string ExamTypeName { get; set; } 
        public string StatusId { get; set; }
        public string StatusName { get; set; }
       
        public int Duration { get; set; }
        public string NegativePoint { get; set; }
        public string MaxPoint { get; set; }
        public string acceptablePoint { get; set; }
        public string RandomQuestion { get; set; }
        public string Maxquestion { get; set; }
        public string IsRemote { get; set; }
        public string IsInvigilator { get; set; }
        public string Image { get; set; }
        public string IsActive { get; set; }

        public string ExamTypeId { get; set; }
        public string MasterId { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public string LanguageId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? AcceptableStartDate { get; set; }
        public string ExamHardShipId { get; set; }
        public string ExamFrameId { get; set; }
        public string ExamCenterName { get; set; }

    }
}
