﻿
namespace CMS.Schema.Admin
{
    public class GroupSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
        public bool IsActive { get; set; }
    }
}
