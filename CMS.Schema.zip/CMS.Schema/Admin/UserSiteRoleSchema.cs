﻿
namespace CMS.Schema.Admin
{
    public class UserSiteRoleSchema
    {
        public int Id { get; set; }
        public bool? IsActive { get; set; }
        public string UserName { get; set; }
        public string RoleName { get; set; }
    }
}
