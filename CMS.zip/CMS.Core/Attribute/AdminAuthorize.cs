﻿
using System.Linq;
using System.Web.Mvc;
namespace CMS.Core.Attribute
{
    
    public class AdminAuthorize : ActionFilterAttribute, IActionFilter 
    {
        private readonly string RoleName;
        public AdminAuthorize(string Roles = "Normal")
        {
            this.RoleName = Roles;
        }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //var db = new CMS.FrameWork.Model.EntitysModelCMS();
            //if (Helper.CurrentUser.User.MembershipUsersInRoles.Where(w => w.MembershipRole.RoleName == "Admin").FirstOrDefault() == null)
            //{
            //    filterContext.Result = new RedirectResult("/fa/Forum", true);
            //};
            base.OnActionExecuting(filterContext);
        }
    }
}
