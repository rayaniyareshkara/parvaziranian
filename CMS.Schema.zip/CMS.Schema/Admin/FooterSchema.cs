﻿
using System.Collections.Generic;

namespace CMS.Schema.Admin
{
    public class FooterTypeSChema {

        public int Id { get; set; }
        public string Title { get; set; }
        public string Align { get; set; }
        public List<FooterSchema> items { get; set; }

    }
    public class FooterSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int TypeId  { get; set; }
        public string Url { get; set; }
        public string Image { get; set; }
        public string value { get; set; }
    }
}
