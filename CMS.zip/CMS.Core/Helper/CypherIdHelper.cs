﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace CMS.Core.Helper
{
    public static class CypherIdHelper
    {
        public static string EncryptId(this HtmlHelper helper, string text)
        {
            string encryptionKey = new CMS.Schema.SecurityCode().CodeDigit;
            if (helper.ViewContext.HttpContext.Session?["EncryptionKey"] != null)
            {
               // encryptionKey = helper.ViewContext.HttpContext.Session["EncryptionKey"].ToString();
            }

            byte[] clearBytes = Encoding.Unicode.GetBytes(text);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(encryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                if (encryptor != null)
                {
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        text = Convert.ToBase64String(ms.ToArray());
                    }
                }
            }
            text = text.Replace("+", " ").Replace("/", "__");
            return text;
        }

        public static string DecryptId(this string cipherText, HttpSessionStateBase session)
        {
            string encryptionKey = new CMS.Schema.SecurityCode().CodeDigit;
            //if (session?["EncryptionKey"] != null)
            //{
            //    encryptionKey = session["EncryptionKey"].ToString();
            //}

            return DecryptId(cipherText, encryptionKey);
        }

        public static string DecryptId(this string cipherText, string key)
        {
            string encryptionKey = new CMS.Schema.SecurityCode().CodeDigit;
            if (!string.IsNullOrWhiteSpace(key))
            {
                encryptionKey = key;
            }
            cipherText = cipherText.Replace(" ", "+").Replace("__", "/");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(encryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                if (encryptor != null)
                {
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText;
            }
        }
    }
}
