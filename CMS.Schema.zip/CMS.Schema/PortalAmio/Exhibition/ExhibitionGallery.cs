﻿using System.ComponentModel;

namespace CMS.Schema.PortalAmio.Exhibition
{
    public class ExhibitionGalleryVm
    {
        [DisplayName("تصویر")]
        public string ImageGallery { get; set; }

        [DisplayName("عنوان")]
        public string TitleGallery { get; set; }
    }
}