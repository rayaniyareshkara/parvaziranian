﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
   public  class MasterShowDataServices : ConversionMain<MasterShow, int>, IMasterShow
    {
        public MasterShowDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<MasterShow, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}