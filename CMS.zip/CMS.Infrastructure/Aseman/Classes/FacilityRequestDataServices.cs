﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class FacilityRequestDataServices : ConversionMain<FacilityRequest, int>, IFacilityRequest
    {
        public FacilityRequestDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<FacilityRequest, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
