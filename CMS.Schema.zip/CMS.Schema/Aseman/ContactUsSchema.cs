﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class ContactUsSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int Status { get; set; }
        public string StatusName { get; set; }
        public string Anwser { get; set; }
       public int RoleId { get; set; }
          public string RoleName { get; set; }
        public DateTime? AnwserDate { get; set; }
        public DateTime CreateDate { get; set; }


      
    }
}
