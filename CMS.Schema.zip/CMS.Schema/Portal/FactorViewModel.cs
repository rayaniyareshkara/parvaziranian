﻿
namespace CMS.Schema.Portal
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}
