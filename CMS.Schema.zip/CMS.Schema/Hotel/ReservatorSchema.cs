﻿
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class ReservatorSchema 
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string Password { get; set; }
        public string Request { get; set; }
    }

    public class ReservatorGuestSchema
    {
        public ReservatorGuestSchema()
        {
            Info = new List<Info>();
        }
        public int Room { get; set; }
        public string FullName { get; set; }
        public int MaxCount { get; set; }
        public List<Info> Info { get; set; }
        public string Phone { get; set; }
        public int Count { get; set; }
    }

    public class Info
    {
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string phone { get; set; }
        public string old { get; set; }
        public int? roomid { get; set; }
    }
}
