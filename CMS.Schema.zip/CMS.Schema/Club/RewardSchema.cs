﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
  public  class RewardSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImgFile { get; set; }
        public string description { get; set; }
        public int Price { get; set; } 
        public string Hotel { get; set; }
        public string Coin { get; set; }
        public int Inventory { get; set; }
        public bool IsActive { get; set; }
        public string Club { get; set; }
    }
    public class RewardAddSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImgFile { get; set; }
        public string description { get; set; }
        public int Price { get; set; }
        public int HotelId { get; set; }
        public int CoinId { get; set; }
        public int Inventory { get; set; }
        public bool IsActive { get; set; }
        public int ClubId { get; set; }
    }
}
