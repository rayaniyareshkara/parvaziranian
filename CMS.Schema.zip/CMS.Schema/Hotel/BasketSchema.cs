﻿
using System;

namespace CMS.Schema.Hotel
{
    public class BasketSchema
    {
        public int id { get; set; }
        public int count { get; set; }
        public DateTime? Date { get; set; }
    }
}
