﻿
namespace CMS.Schema.Staff
{
    public class CalendarLogSchema
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string Date { get; set; }
        public string DateAdded { get; set; }
        public int? Price { get; set; }
        public int Count { get; set; }
        public string Time { get; set; }
        public int? ReserveType { get; set; }
    }
}
