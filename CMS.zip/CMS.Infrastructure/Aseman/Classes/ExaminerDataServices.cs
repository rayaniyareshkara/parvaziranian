﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
 public   class ExaminerDataServices : ConversionMain<Examiner, int>, IExaminer
    {
        public ExaminerDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<Examiner, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
