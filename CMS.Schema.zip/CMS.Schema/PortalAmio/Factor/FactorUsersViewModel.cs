﻿using CMS.Schema.Enum;

namespace CMS.Schema.PortalAmio.Factor
{
    public class FactorUsersViewModel
    {
        public string InvoiceNumber { get; set; }

        public string CreationDate { get; set; }

        public string PayDate { get; set; }

        public string StatusPay { get; set; }

        public string TypeOfPayment { get; set; }

        public string UserName { get; set; }

        public TypeOfPaymentEnum TypeOfPaymentEnum { get; set; }

        public string Subject { get; set; }

        public int InvoiceNumberId { get; set; }

        public string Approve { get; set; }

        public int Id { get; set; }

        public string CompanyName { get; set; }

    }
}
