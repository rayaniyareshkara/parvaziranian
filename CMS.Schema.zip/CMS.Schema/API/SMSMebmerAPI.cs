﻿using System;


namespace CMS.Schema.API
{
    public class SMSMebmerAPI
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public int GroupId { get; set; }
        public string Mobile { get; set; }
    }
}
