﻿
namespace CMS.Schema.Admin
{
    public class PaginationViewModel
    {
        public int CurrentPage { get; set; }
        public int MaxPage { get; set; }
    }
}
