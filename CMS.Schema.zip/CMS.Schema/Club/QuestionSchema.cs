﻿using CMS.FrameWork.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
    public class QuestionSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string description { get; set; }
        public string ImgFile { get; set; }
        public string Model { get; set; }
        public string Category { get; set; }
        public bool IsActive { get; set; }
    }

    public class QuestionAddSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string description { get; set; }
        public string ImgFile { get; set; }
        public int Model { get; set; }
        public int CategoryId { get; set; }
        public bool IsActive { get; set; }
        public List<QuestionAnswerSchema> Answers { get; set; }

    }
}
