﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
   public class QuestionCategorySchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImgFile { get; set; }
        public string description { get; set; }       
        public bool IsActive { get; set; }
    }
}
