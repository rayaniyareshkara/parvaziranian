﻿using CMS.FrameWork.Statute.Events;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CMS.FrameWork.Statute.DBA
{
    public abstract class ConversionMain<TModel, TKey> : Events.EventSite, IDisposable, Repository.IRule<TModel, TKey> where TModel : class
    {
        protected DbContext DbContext { get; set; }
        public DbSet<TModel> Current { get; set; }
        public Model.EntitysModelCMS Context { get; set; }
        public string tablename { get; set; }
        public abstract System.Linq.Expressions.Expression<Func<TModel, TKey>> GetKey();

        public IQueryable<TModel> Table
        {
            get
            {
                return this.Entities;
            }

        }

        public ConversionMain(Model.EntitysModelCMS Context)
        {
            this.Context = Context;

            ((IObjectContextAdapter)Context).ObjectContext.CommandTimeout = 0;
            tablename = (Context as IObjectContextAdapter).ObjectContext.CreateObjectSet<TModel>().EntitySet.Name;
            this.Current = Context.Set<TModel>();
        }

        public void Dispose()
        {
            Context.Dispose();
        }

        public virtual IQueryable<TModel> Select()
        {
            return Current.AsQueryable();
        }

        public virtual async Task<TModel> Save(TModel item, CancellationToken cancellationToken = default(CancellationToken))
        {
            try
            {
                Current.Add(item);
                await Context.SaveChangesAsync();
                return item;
            }
            catch (Exception )
            {
                
                return null;
            }

        }

        public virtual async Task<TModel> Update(TModel item, params string[] properties)
        {
            try
            {
                Context.Entry(item).State = EntityState.Modified;
                foreach (var property in properties)
                {
                    //var propertyName = ExpressionHelper.GetExpressionText(property);
                    Context.Entry(item).Property(property).IsModified = true;
                }

                await Context.SaveChangesAsync();

                return item;
            }
            catch (Exception )
            {
                return null;
            }


        }

        public virtual async Task Delete(TModel item)
        {
            try
            {
                Current.Attach(item);
                Current.Remove(item);
                await Context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
         
        }

        protected virtual IDbSet<TModel> Entities
        {
            get
            {
                if (Current == null)
                    Current = Context.Set<TModel>();
                return Current;
            }
        }

        public virtual TModel Get(TKey id)
        {
            var key = GetKey();
            var body = key.Body;
            var exp = System.Linq.Expressions.Expression.Equal(body, System.Linq.Expressions.Expression.Constant(id));
            var lambda = System.Linq.Expressions.Expression.Lambda<Func<TModel, bool>>(exp, key.Parameters);
            return Current.FirstOrDefault(lambda);
        }

        public virtual async Task<IList<TModel>> Save(IList<TModel> item)
        {
            foreach (var q in item)
                Current.Add(q);
            await Context.SaveChangesAsync();

            return item;
        }

        public async Task<IList<TModel>> Update(IList<TModel> item, params string[] Properties)
        {


            foreach (var fi in item)
            {
                Context.Entry(fi).State = EntityState.Modified;
                foreach (var property in Properties)
                {
                    Context.Entry(fi).Property(property).IsModified = true;
                }
            }

            await Context.SaveChangesAsync();


            return item;

        }

        public virtual async Task Delete(IList<TModel> item)
        {
            Current.RemoveRange(item);
            await Context.SaveChangesAsync();
        }

        public virtual async Task<TModel> UnChnagedUpdate(TModel item, params string[] Properties)
        {

            Context.Entry(item).State = EntityState.Unchanged;
            foreach (var property in Properties)
            {
                //var propertyName = ExpressionHelper.GetExpressionText(property);
                Context.Entry(item).Property(property).IsModified = true;
            }

            await Context.SaveChangesAsync();

            return item;
        }

        public virtual async Task<IList<TModel>> UnChnagedUpdate(IList<TModel> item, params string[] Properties)
        {
            foreach (var fi in item)
            {
                Context.Entry(fi).State = EntityState.Unchanged;
                foreach (var property in Properties)
                {
                    Context.Entry(fi).Property(property).IsModified = true;
                }
            }

            await Context.SaveChangesAsync();


            return item;
        }

        public interface ITypeOfService
        {
        }
    }
}
