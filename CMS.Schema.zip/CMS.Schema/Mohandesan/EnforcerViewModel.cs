﻿
using System;
using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
    public class EnforcerViewModel 
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Mobile { get; set; }
        public string Description { get; set; }
        public int Order { get; set; }
        public List<EnforcerInGradeSchema> Grades { get; set; }
        public List<EnforcerLicenseSchema> License { get; set; }
        public List<EnforcerActivitySchema> Activity { get; set; }
        public List<EnforcerProjectsSchema> Projects { get; set; }
    }

    public class EnforcerInGradeSchema
    {
        public string Id { get; set; }
        public int Field { get; set; }
        public int Grade { get; set; }
        public int Type { get; set; }
        public int Terend { get; set; }

        public string FieldName { get; set; }
        public string GradeName { get; set; }
        
        public string TerendName { get; set; }




    }

    public class EnforcerLicenseSchema
    {
        public Guid Id { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
      
    }

    public class EnforcerActivitySchema
    {
        public Guid Id { get; set; }
        public string Time { get; set; }
        public string Description { get; set; }

    }
}
