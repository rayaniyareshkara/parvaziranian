﻿
namespace CMS.Schema.Mohandesan
{
    public class TerendScema
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
