﻿namespace CMS.Schema.Admin
{
    public class CategorySchema
    {
        public int Id { get; set; }
        public int Count { get; set; }
        public string Title { get; set; }
    }
}
