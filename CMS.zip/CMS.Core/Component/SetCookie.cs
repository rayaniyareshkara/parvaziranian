﻿using System;
using CMS.Schema;
using System.Web;
using System.Net;

namespace CMS.Core.Component
{
    public static class SetCookie
    {
        private static string ActiveCode
        {
            get
            {
                return new EncodeAndDecode().Encode(CoockieEnum.ActiveCode.ToString());
            }
        }
        private const string USERID = "USERID";
        private const string USERNAME = "USERNAME";

        public static void AddCookie(Coockie ck)
        {
            EncodeAndDecode ead = new EncodeAndDecode();
            HttpCookie CoockieValue = new HttpCookie(ead.Encode(ck.BehinNewsaadCMS.ToString()));

            if (ck.RememberMe)
                CoockieValue.Expires = DateTime.Now.AddDays(30);

            CoockieValue.Values[ActiveCode] = ead.Encode(ck.ActiveCode);
            CoockieValue.Values[ead.Encode(USERNAME)] = ead.Encode(ck.UserName);
            CoockieValue.Values[ead.Encode(USERID)] = ead.Encode(ck.UserId.ToString());

            HttpContext.Current.Response.Cookies.Add(CoockieValue);
        }

        public static void AddCookie(Coockie ck,int time)
        {
            EncodeAndDecode ead = new EncodeAndDecode();
            HttpCookie CoockieValue = new HttpCookie(ead.Encode(ck.BehinNewsaadCMS.ToString()));

            if (ck.RememberMe)
                CoockieValue.Expires = DateTime.Now.AddMinutes(time);
            CoockieValue.Secure = true;
            CoockieValue.SameSite = SameSiteMode.Lax;
            CoockieValue.HttpOnly = true;
            CoockieValue.Values[ActiveCode] = ead.Encode(ck.ActiveCode);
            CoockieValue.Values[ead.Encode(USERNAME)] = ead.Encode(ck.UserName);
            CoockieValue.Values[ead.Encode(USERID)] = ead.Encode(ck.UserId.ToString());

            HttpContext.Current.Response.Cookies.Add(CoockieValue);
        }
        public static Coockie ValueCookie(Coockie ck)
        {
            try
            {
                EncodeAndDecode ead = new EncodeAndDecode();

                var cookie = HttpContext.Current.Request.Cookies.Get(ead.Encode(ck.BehinNewsaadCMS.ToString()));
                if (cookie != null)
                {
                    ck.ActiveCode = ead.Decode(cookie[ActiveCode]);
                    if (Guid.TryParse(ead.Decode(cookie[ead.Encode(USERID)]), out Guid userid))
                    {
                        ck.UserId = userid;
                    }
                    ck.UserName = ead.Decode(cookie[ead.Encode(USERNAME)]);
                    ///////// ---------------------------------------------------------------------------------------------------------------------------
                    //ck.UserId = Guid.Parse(ead.Decode(HttpContext.Current.Request.Cookies.Get(ead.Encode(ck.BehinNewsaadCMS.ToString()))[ead.Encode(USERID)]));
                    //ck.UserName = ead.Decode(HttpContext.Current.Request.Cookies.Get(ead.Encode(ck.BehinNewsaadCMS.ToString()))[ead.Encode(ead.Decode)]);
                    //////// -----------------------------------------------------------------------------------------------------------------------------
                    return ck;
                }
                else
                    return null;
            }
            catch (Exception)
            {
                return null;

            }
         
        }

        public static void DeleteCookie(Coockie ck)
        {
            EncodeAndDecode ead = new EncodeAndDecode();
            var httpContext = new HttpContextWrapper(HttpContext.Current);
            var _response = httpContext.Response;

            HttpCookie cookie = new HttpCookie(ead.Encode(ck.BehinNewsaadCMS.ToString()))
            {
                Expires = DateTime.Now.AddDays(-1), // or any other time in the past,
                Value = null,
            };
            _response.Cookies.Set(cookie);
        }

        public static bool IsActiveCookie(Coockie ck)
        {
            EncodeAndDecode ead = new EncodeAndDecode();

            if (HttpContext.Current.Request.Cookies[ead.Encode(ck.BehinNewsaadCMS.ToString())] != null)
                return true;
            else
                return false;
        }
    }

}
