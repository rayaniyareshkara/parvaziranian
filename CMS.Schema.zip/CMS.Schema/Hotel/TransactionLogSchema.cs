﻿namespace CMS.Schema.Hotel
{
    public class TransactionLogSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string OrderId { get; set; }
        public string ResNum { get; set; }
        public string Mobile { get; set; }
        public string FirstName { get; set; }
        public string SecurePan { get; set; }
        public string TRACENO { get; set; }
        public string RefNum { get; set; }
        public string Time { get; set; }
        public string Bank { get; set; }
        public string Date { get; set; }
        public string Amount { get; set; }
        public string FormDate { get; set; }
        public string ToDate { get; set; }
    }
}
