﻿using System.Collections.Generic;
using CMS.Schema.Hotel;

namespace CMS.Schema.Club
{
    public class RegisterCartGroup
    {
        public RegisterCartSchema RegisterCartSchema { get; set; }

        public IEnumerable<ComradeSchema> ComradeSchema { get; set; }
    }
}
