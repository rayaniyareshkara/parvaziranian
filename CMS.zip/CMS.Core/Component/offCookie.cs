﻿using System;

using System.Web;

namespace CMS.Core.Component
{
    
    public class OffCookie 
    {
        
        public static bool Exists()
        {
            try
            {
                return HttpContext.Current.Request.Cookies["off"] != null;
            }
            catch (Exception )
            {
                return false;
            }
          
        }

        public static string GetCode()
        {
            try
            {
                return HttpContext.Current.Request.Cookies["off"]?.Value ?? "";
            }
            catch (Exception )
            {
                return "";
            }
        }
    }
}
