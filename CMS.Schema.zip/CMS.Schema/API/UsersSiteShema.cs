﻿

using System;

namespace CMS.Schema.API
{
    public class UsersSiteShema
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public bool IsActive { get; set; }
        public string Image { get; set; }
        public string Password { get; set; }
        public byte Sex { get; set; }
    }
}
