﻿namespace CMS.Schema.Staff
{

    public class BoothCardShowGrid
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }
        public string Time { get; set; }
        public string Exhibition { get; set; }
        public string Stand { get; set; }

        public string Status { get; set; }
    }

    public class BoothCardDetail
    {
        public int Id { get; set; }

        public string CompanyName { get; set; }

        public string FullNameFa { get; set; }

        public string FullNameEn { get; set; }

        public string File { get; set; }

    }


    public class CardIssuanceRequestShowGrid
    {
        public int Id { get; set; }

        public string CompanyName { get; set; }

        public string Time { get; set; }

        public string Status { get; set; }

        public int Number { get; set; }

        public string Exhibition { get; set; }

        public string Stand { get; set; }
    }

    public class CardIssuanceRequestDetail
    {
        public int Id { get; set; }

        public string CompanyName { get; set; }

        public string Time { get; set; }

        public int Type { get; set; }

        public int Number { get; set; }

        public string Exhibition { get; set; }

        public string Description { get; set; }
    }
}
