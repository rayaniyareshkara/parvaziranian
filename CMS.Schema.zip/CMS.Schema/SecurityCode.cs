﻿
namespace CMS.Schema
{
    public class SecurityCode
    {
        public string CodeDigit
        {
            get
            {
                return "S~1e!i2@E#3d$4K%5e^6I&7v*8A(9n)0M_1o+2U=3s-4A|5v}6I{7M'8a;9R/0z.1D>2a<3s,4H`5t[6i]";
            }
        }
    }
}
