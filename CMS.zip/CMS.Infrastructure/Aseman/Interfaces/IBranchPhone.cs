﻿using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA.Repository;


namespace CMS.Infrastructure.Aseman.Interfaces
{
   public interface IBranchPhone : IRule<BranchPhone, int>
    {
    }
}
