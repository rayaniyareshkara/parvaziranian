﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class AddPhoneNumberViewModel
    {
        [Required]
        [Phone]
        [Display(Name = @"شماره تلفن")]
        public string Number { get; set; }
    }

}
