﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
  public  class MemberClubSchema
    {
        public int Id { get; set; }      
        public string ClubName { get; set; }

        public string Username { get; set; }
        public string Mobile { get; set; }
        public string Introduced { get; set; }
        public string CreateDate { get; set; }
        public string LastActiveDate { get; set; }






    }
}
