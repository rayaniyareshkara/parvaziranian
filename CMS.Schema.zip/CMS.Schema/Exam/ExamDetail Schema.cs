﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
  public  class ExamDetail_Schema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string Code { get; set; }
        public int Duration { get; set; }
        public decimal NegativePoint { get; set; }
        public int MaxPoint { get; set; }
        public int acceptablePoint { get; set; }
        public int Maxquestion { get; set; }
        public string Image { get; set; }
        public string ExamType { get; set; }
        public int?   ExamTypeId { get; set; }
        public string MasterName { get; set; }
        public int? MasterId { get; set; }
        public string ExamHardShip { get; set; }
        public bool IsRemote { get; set; }
        public bool IsInvigilator { get; set; }
        public DateTime? AcceptableStartDate { get; set; }
        public DateTime? AcceptableEndDate { get; set; }
        public int ExamCenterId { get; set; } 
        public string ExamCenterName { get; set; }
        public int? DegreeId { get; set; }
        public string DegreeName { get; set; }
        public int? MainCourseId { get; set; }
        public string MainCourseName { get; set; }
        public int? CourseId { get; set; }
        public string CourseName { get; set; }
        public int? ExaminerId { get; set; }
        public Guid? ExaminerUserId { get; set; }
        public string ExaminerName { get; set; }
        public int? StatusId { get; set; }
        public string StatusName { get; set; }
      
     

       
     

    }
}
