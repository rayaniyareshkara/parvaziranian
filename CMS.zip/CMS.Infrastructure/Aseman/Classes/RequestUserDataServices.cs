﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class RequestUserDataServices : ConversionMain<RequestUser, int>, IRequestUser
    {
        public RequestUserDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<RequestUser, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
