﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
   public class RegisterVisitorSchema
    { 
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }
        public string JobTitle { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public Guid UserId { get; set; }

        public int? CategoryId { get; set; }
        public string Category { get; set; }
        public int? VisitTypeID { get; set; }
        public string VisitType { get; set; }
    
        public DateTime CreateDate { get; set; }

      
    }
}
