﻿

using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Mohandesan.Interfaces;

namespace CMS.Infrastructure.Mohandesan.Classes
{
    public class PostDataServices : ConversionMain<Post, int> ,IPost
    {
        public PostDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<Post, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
