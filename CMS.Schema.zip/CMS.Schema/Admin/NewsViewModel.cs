﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Admin
{
    public class NewsViewModel
    {
        public NewsViewModel()
        {
            NewsInLanguage = new Dictionary<string, NewsValidated>();
        }

        public Dictionary<string, NewsValidated> NewsInLanguage { get; set; }
    }

}
