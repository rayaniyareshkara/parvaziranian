﻿namespace CMS.Schema.Admin
{
    using System.Collections.Generic;

    public class GalleryImage
    {
        public List<string> LstUrlImage { get; set; }
        public PageAmin Page { get; set; }
        public string AlbumGalleryId { get; set; }
    }
}
