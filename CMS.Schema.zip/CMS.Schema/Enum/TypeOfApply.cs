﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Enum
{
    public enum TypeOfApply : byte
    {
        [Display(Name = "پیش پرداخت")]
        Prepayment = 1,
        [Display(Name = "پرداخت نهایی")]
        FinalPayment = 2
    }
}
