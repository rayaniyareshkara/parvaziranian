﻿
namespace CMS.Schema.Mohandesan
{
    public class SheetPriceSchema
    {
        public int Id { get; set; }
        public int Field { get; set; }
        public int MetterId { get; set; }
        public int Price { get; set; }
        public int UserId { get; set; }
    }
}
