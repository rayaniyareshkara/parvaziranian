﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class ExamListUserSchema
    {
        public int Id { get; set; }
        public string Date { get; set; }
        public string CenterName { get; set; }
        public string Code { get; set; }
        public int Duration { get; set; }
      


    }
}
