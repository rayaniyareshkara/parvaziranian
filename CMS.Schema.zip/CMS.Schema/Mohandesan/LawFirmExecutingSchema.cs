﻿
using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
    public class LawFirmExecutingSchema
    {
        public int Id { get; set; }
        public string Image { get; set; }
        public string Title { get; set; }
        public List<LawFirmExecutingGrades> GradesAndFields { get; set; }
        public double? Metter500 { get; set; }
        public double? Metter1000 { get; set; }

        public string Grade { get; set; }
        public double? MoreThan2000 { get; set; }

        public double? Metter2000 { get; set; }
        public string Name { get; set; }

    }

    public class LawFirmExecutingGrades
    {
        public string Field { get; set; }
        public string Grade { get; set; }
        public string Terend { get; set; }
    }
}
