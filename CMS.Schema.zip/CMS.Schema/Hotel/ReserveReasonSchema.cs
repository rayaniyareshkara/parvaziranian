﻿
namespace CMS.Schema.Hotel
{
    public class ReserveReasonSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public string Brief { get; set; }
        public string Link { get; set; }
    }
}
