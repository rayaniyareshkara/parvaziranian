﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
   public class Register
    {
      
        [ScaffoldColumn(false)]
        
        public System.Guid Id { get; set; }

        [Required(ErrorMessage ="the firstname field is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "the lastname field is required")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "the email field is required")]
        [DataType(DataType.EmailAddress,ErrorMessage ="invalid email address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "the mobile field is required")]
        [StringLength(11,MinimumLength =11,ErrorMessage ="the mobile field must 11 caracters")]
        
        public string Mobile { get; set; }

        [Required(ErrorMessage = "the phone field is required")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "the birthDate field is required")]
        public System.String BirthDate { get; set; }

        [Required(ErrorMessage = "the username field is required")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "the password field is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "the confirmPassword field is required")]
        [DataType(DataType.Password)]
        [Compare("Password",ErrorMessage ="Password not like confirm password")]
        public string ConfirmPassword { get; set; }

        [ScaffoldColumn(false)]
        public bool IsActive { get; set; }
        public bool Sex { get; set; }
        public string Image { get; set; }

        [ScaffoldColumn(false)]
        public Nullable<System.Guid> UserActive { get; set; }

        [ScaffoldColumn(false)]
        public Nullable<int> MobileActive { get; set; }
        public string Description { get; set; }
        public bool IsAdmin { get; set; }
        public bool IsDelete { get; set; }


    }
}
