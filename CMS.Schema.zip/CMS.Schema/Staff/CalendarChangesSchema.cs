﻿
using System;

namespace CMS.Schema.Staff
{
    public class CalendarChangesSchema
    {
        public int room { get; set; }
        public int Count { get; set; } = -1;
        public int Selltype { get; set; } = -1;
        public int Price { get; set; } = -1;
        public DateTime Date { get; set; }
        public string room_code { get; set; }

        public int Discount { get; set; } = -1;
    }
}
