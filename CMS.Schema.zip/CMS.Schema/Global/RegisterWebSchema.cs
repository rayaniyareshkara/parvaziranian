﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Global
{
    public class RegisterWebSchema
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        public int Type { get; set; }
    }
}
