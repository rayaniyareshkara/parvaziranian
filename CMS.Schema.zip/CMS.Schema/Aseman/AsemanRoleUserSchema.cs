﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class AsemanRoleUserSchema
    {
        public int Id { get; set; }
        public int AsemanRoleId { get; set; }
        public Guid UserId { get; set; }
        public string AsemanRoleName { get; set; }
        public string UserName { get; set; }

    }
}
