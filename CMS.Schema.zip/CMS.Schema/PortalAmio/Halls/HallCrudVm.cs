﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalAmio.Halls
{
    public class HallCrudVm
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        [DisplayName("عنوان")]
        public string Title { get; set; }
        [DisplayName("فعال/غیرفعال")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public bool Status { get; set; }
        [DisplayName("زبان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int Lang { get; set; }
        [DisplayName("مکان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int PlaceId { get; set; }
    }
}
