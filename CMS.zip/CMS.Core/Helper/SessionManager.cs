﻿using CMS.Core.Component;
using Newtonsoft.Json;
using System;
using System.Web;
using System.Web.SessionState;

namespace CMS.Core.Helper
{

    public enum SessionEnum
    {
        LogOn,
        Permission,
        LogInName,
        LogInTime,
        AdminSignalR
    }


    public class SessionManager
    {

        //public static DateTime LastPermission = DateTime.Now;
        private HttpSessionState _session;
        private readonly SessionEnum? _sessionKey = SessionEnum.Permission;
        private readonly EncodeAndDecode encoder;
        private string SessionName
        {
            get
            {
                if (_sessionKey == null)
                {
                    throw new NullReferenceException("No sessionKey provided at the constructor");
                }
                return _sessionKey.ToString();
            }
        }

        public SessionManager()
        {
            encoder = new EncodeAndDecode();
            _session = HttpContext.Current.Session;
        }

        public SessionManager(SessionEnum sessionKey) : this()
        {
            _sessionKey = sessionKey;
        }

        #region Depends on SessionKey provided using constructor
        public bool DoesKeyExist()
        {
            if (!HasAnySessions())
            {
                return false;
            }
            bool exist = false;
            for (int i = 0; i < _session.Count; i++)
            {
                exist = _session.Keys[i] == SessionName;
                if (exist)
                {
                    break;
                }
            }
            return exist;
        }

        public bool IsNull()
        {
            return _session[SessionName] == null;       

        }

        public void SetNull()
        {
            _session[SessionName] = null;
        }

        public TSource Get<TSource>()
        {

            return JsonConvert.DeserializeObject<TSource>(encoder.Decode(_session[SessionName]?.ToString()));
        }

        public void Add<TSource>(TSource model)
        {
            _session.Add(SessionName, encoder.Encode(JsonConvert.SerializeObject(model)));
        }

        public void Replace<TSource>(TSource model)
        {
            if (model == null)
                _session[SessionName] = model;
            else
                _session[SessionName] = encoder.Encode(JsonConvert.SerializeObject(model));
        }

        public void Remove()
        {
            _session.Remove(SessionName);
        }
        #endregion


        public string GetSessionId()
        {
            return _session.SessionID;
        }

        public bool HasAnySessions()
        {
            return _session.Count > 0;
        }

        public void RemoveAll()
        {
            _session.RemoveAll();
        }

        public void AbandonSessions()
        {
            _session.Abandon();
        }
    }
}
