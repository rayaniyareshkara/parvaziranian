﻿
namespace CMS.Schema.Admin
{
    public class LoginAdmin
    {
        public string UserName { get; set; }
    }
}
