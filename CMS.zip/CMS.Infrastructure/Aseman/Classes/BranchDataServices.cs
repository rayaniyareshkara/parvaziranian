﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;



namespace CMS.Infrastructure.Aseman.Classes
{
  public  class BranchDataServices : ConversionMain<Branch, int>, IBranch
    {
        public BranchDataServices(EntitysModelCMS context) : base(context)
        {
        }

        public override Expression<Func<Branch, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}


