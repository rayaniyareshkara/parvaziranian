﻿
using System;

namespace CMS.Schema.Hotel
{
    public class HotelInfoSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }

    public class FeatureRoomSchema
    {
        public int Price { get; set; }
        public bool IsRequired { get; set; }
        
        public int Id { get; set; }
        public string Title { get; set; }
    }


    public class HotelInfoReserveSchema
    {
        public int Id { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string Image { get; set; }
        public string StartDate { get; set; }
        public string RulesLink { get; set; }
        public string Map { get; set; }
        public string EndDate { get; set; }
        public int TotalDays { get; set; }
        public string Title { get; set; }
    }
}
