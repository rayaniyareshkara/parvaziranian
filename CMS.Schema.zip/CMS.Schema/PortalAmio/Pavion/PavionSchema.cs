﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Pavion
{
   public class PavionSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string law { get; set; }

        public string Prupose { get; set; }
        public string Country { get; set; }
         public string City { get; set; }
        public string Link { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
       public DateTime? StartRegistration { get; set; }
        public DateTime? EndRegistration { get; set; }
        public bool IsActive { get; set; }
        public string MetaKeyWord { get; set; }      
        public string MetaDescription { get; set; }
        public string Key { get; set; }
        public string HoldingSpace { get; set; }
        public string Image { get; set; }
        public string ImageMain { get; set; }
        public string ImageLeft { get; set; }
        public string Imageright { get; set; }
        public string Lawpdf { get; set; }
        public string SignupPdf { get; set; }
        public string CatalogPdf { get; set; }
        public string VisitingTime { get; set; }
        public int? IdRow { get; set; }
        public bool? Status { get; set; }
        public int LanguageId { get; set; }
        public DateTime CreateDate { get; set; }

    }
}
