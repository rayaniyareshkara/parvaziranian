﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
public    class UserCertificateDataServices : ConversionMain<UserCertificate, int>, IUserCertificate
    {
        public UserCertificateDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<UserCertificate, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
