﻿

namespace CMS.Schema.Portal
{
    public class Users_similarity
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public bool IsRole { get; set; }

    }
}
