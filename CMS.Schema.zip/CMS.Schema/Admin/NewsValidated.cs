﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace CMS.Schema.Admin
{
    public class NewsValidated
    {

        public NewsValidated()
        {
            TagsList = new List<string>();
        }

        public System.Guid Id { get; set; }
        public int IntId { get; set; }
        public int Language { get; set; }
        public string Title { get; set; }
        public string Header { get; set; }
        public string Description { get; set; }
        [AllowHtml]
        public string Body { get; set; }
        public string Tags { get; set; }
        public string Author { get; set; }
        public string ImageUrl { get; set; }
        public string TypeNewsId { get; set; }
        public List<string> TagsList { get; set; }
        public string GroupId { get; set; }
    }
}
