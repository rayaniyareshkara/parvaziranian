﻿
namespace CMS.Schema.jsTree
{
    using CMS.FrameWork.Model;
    using System.Collections.Generic;

    public class JsTreeNode
    {
        public string id { set; get; } // نام اين خواص بايد با مستندات هماهنگ باشد
        public string text { set; get; }
       
        public string icon { set; get; }

        public string VideoNameServer { get; set; }
        public string VideoAddress { get; set; }
        public string VideoFileName { get; set; }
        public string Description { get; set; }

        public JsTreeNodeState state { set; get; }
        public List<JsTreeNode> children { set; get; }
        public JsTreeNodeLiAttributes li_attr { set; get; }
        public JsTreeNodeAAttributes a_attr { set; get; }

        public JsTreeNode()
        {
            state = new JsTreeNodeState();
            children = new List<JsTreeNode>();
            li_attr = new JsTreeNodeLiAttributes();
            a_attr = new JsTreeNodeAAttributes();
        }
    }


}
