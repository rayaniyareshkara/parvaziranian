﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
  public   class TransactionSchema
    {
        public int Id { get; set; }
        public int Value { get; set; }
        public string UserSite { get; set; }
        public string CoinName { get; set; }
        public string description { get; set; }
        public string CreateDate { get; set; }    
    
     
    }
}
