﻿
namespace CMS.Schema.Mohandesan
{
    public class Grade
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int Implementation { get; set; }
        public int Count { get; set; }
        public int Capacity { get; set; }
        public int Area { get; set; }

    }

    public class LawFirmGrade : Grade
    {
        public int Experiment { get; set; }
        public int Consultant { get; set; }
    }

    public class EnforcerGrade : Grade
    {
        public int Supervision { get; set; }
        public int Design { get; set; }
    }
}
