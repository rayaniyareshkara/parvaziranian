﻿using System;
using System.Collections.Generic;

namespace CMS.Schema.Global
{
    public class DropDownVm
    {
        public int Id { get; set; }

        public string Title { get; set; }
    }

    public class DropDownUser
    {
        public Guid Id { get; set; }

        public string Title { get; set; }
    }

    public class DropDownSelected
    {
        public int Id { get; set; }
        public string Title { get; set; }

        public bool Selected { get; set; }


    }
    public class StandReserveSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int?  Status { get; set; }
        public string Color { get; set; }
        public int Count { get; set; }
        public bool Selected { get; set; }

    }
}
