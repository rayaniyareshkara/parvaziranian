﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
    [Serializable]
    public class Sms
    {
        //تنظیمات اس ام اس
        private string _userName;

        public string UserName
        {
            get { return Cypher.Decrypt(_userName); }
            set { _userName = Cypher.Encrypt(value); }
        }

        private string _passwordSms;

        public string PasswordSms
        {
            get { return Cypher.Decrypt(_passwordSms); }
            set { _passwordSms = Cypher.Encrypt(value); }
        }

        private string _senderCode;

        public string SenderCode
        {
            get { return Cypher.Decrypt(_senderCode); }
            set { _senderCode = Cypher.Encrypt(value); }
        }


        //پایان تنظیمات اس ام اس
    }
}
