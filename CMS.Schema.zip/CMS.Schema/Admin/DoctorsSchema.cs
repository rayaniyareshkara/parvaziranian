﻿using System;

namespace CMS.Schema.Admin
{
    public class DoctorsSchema
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public string Specialization { get; set; }
        public string Specialty { get; set; }
        public string Description { get; set; }
        public string Email { get; set; }
        public string Telephone { get; set; }
        public Nullable<int> Image { get; set; }
        public int Language { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
