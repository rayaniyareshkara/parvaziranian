﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
 public  class MasterSocialNetWorkDataServices : ConversionMain<MasterSocialNetWork, int>, IMasterSocialNetWork
    {
        public MasterSocialNetWorkDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<MasterSocialNetWork, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
