﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
  public  class CommentAddSchema
    {
        public int ArticleId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Discription { get; set; }
      
        public int ParentId { get; set; }
    }
}
