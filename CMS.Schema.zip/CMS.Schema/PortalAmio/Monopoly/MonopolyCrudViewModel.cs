﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalAmio.Monopoly
{
    public class MonopolyCrudViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(250, ErrorMessage = "{0} طول نمی تواند بیشتر از 250 حروف باشد")]
        [DisplayName(" نام کالا")]
        public string ProductName { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("نوع کالا")]
        public int ProductionType { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]
        [DisplayName(" پروانه تولید")]
        public string ProductionLicense { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]
        [DisplayName(" گواهی اصالت")]
        public string CertificateOfAuthenticity { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]
        [DisplayName("پروانه گمرکی")]
        public string CustomsLicense { get; set; }
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]
        [DisplayName("متراژ")]
        public string Area { get; set; }
    }
}
