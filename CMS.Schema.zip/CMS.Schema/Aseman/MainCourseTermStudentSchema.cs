﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class MainCourseTermStudentSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public string MainCourseName { get; set; }
        public string BranchName { get; set; }
        public int StatusId { get; set; }
        public string Status { get; set; }
    }
}
