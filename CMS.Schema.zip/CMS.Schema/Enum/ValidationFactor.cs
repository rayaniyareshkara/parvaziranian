﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Enum
{
    public enum ValidationFactor
    {
        [Display(Name = "غیر فعال")]
        Inactive = 1,
        [Display(Name = "حذف شده")]
        IsDeleted = 2,
        [Display(Name = "پرداخت شده است")]
        Payment = 3,
        [Display(Name = "این فاکتور برای یک کاربر دیگر است")]
        AnotherUser = 4,
        [Display(Name = "درست است")]
        Active = 5,
        [Display(Name = "این فاکتور وجود ندارد ")]
        NotExist = 6
    }

}
