﻿using CMS.Core.Helper;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;
using CMS.Schema.Component;
using CMS.Schema.Admin;

namespace CMS.Core.Component
{
    public class FileManager
    {
        public FileManager()
        {
            this.WaterMark = false;
        }

        public bool WaterMark { get; set; }

        public FilesSchema SaveImage(HttpPostedFileBase file)
        {
            return Save(file, true);
        }

        public FilesSchema Save(HttpPostedFileBase file, bool forceImage)
        {
            string newName = string.Empty;
            if (file != null && file.ContentLength > 0)
            {
                CheckIfUploadDirExist();
                var fileType = GetFileType(file.ContentType);

                try
                {
                    if (forceImage && fileType != (int)FileTypes.Image || (fileType == (int)FileTypes.Image && !file.IsImage()) || fileType == null)
                    {
                        throw new InvalidDataException();
                    }
                    Random rnd = new Random(Convert.ToInt32(Environment.TickCount));
                    string fileName = Path.GetFileNameWithoutExtension(file.FileName) + rnd.Next(1, 100) + Path.GetExtension(file.FileName);
                    newName = Guid.NewGuid().ToString();

                    // TODO: save the file content into a file async
                    //if (forceImage && fileType == (int)FileTypes.Image)
                    //{
                    //    if (this.WaterMark)
                    //    {
                    //        fst = SetWaterMark(file.InputStream);
                    //    }
                    //}

                    FilesSchema fileContext = new FilesSchema()
                    {
                        Mime = file.ContentType,
                        NewName = newName,
                        OriginalName = fileName,
                        Type = fileType
                    };

                    string path = Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data/upload/"), newName);

                    file.SaveAs(path);

                    //using (ContentContext context = new ContentContext())
                    //{
                    //    context.Files.Add(fileContext);
                    //    context.SaveChanges();
                    //}
                    return fileContext;
                }
                catch
                {
                    //LogModel log = new LogModel("error Saving picture", e.Message);
                    throw;
                }
            }
            return null;
        }

        private static void CheckIfUploadDirExist()
        {
            var originalDirectory = new DirectoryInfo(HttpContext.Current.Server.MapPath(@"~/App_Data"));

            string pathString = Path.Combine(originalDirectory.ToString(), "Upload");

            bool isExists = System.IO.Directory.Exists(pathString);

            if (!isExists)
                Directory.CreateDirectory(pathString);
        }

        private Stream SetWaterMark(Stream inputStream)
        {
            throw new NotImplementedException();
        }

        private static int? GetFileType(string contentType)
        {
            int? fileType = null;
            if (contentType.Contains("image"))
            {
                fileType = (int)FileTypes.Image;
            }
            else if (contentType.Contains("pdf"))
            {
                fileType = (int)FileTypes.Pdf;
            }
            else if (contentType.Contains("plain") && contentType.Contains("text"))
            {
                fileType = (int)FileTypes.Text;
            }

            return fileType;
        }

        public ImageResult GetImage(FilesSchema uploadedFile, int maxWidth, int maxHeight, bool thumbIt)
        {
            string path = Path.Combine(HttpContext.Current.Server.MapPath("~/App_Data/upload/"), uploadedFile.NewName);

            Stream fileStream = null;
            string mime = uploadedFile.Mime.ToLower();
            Image img = Image.FromFile(path);
            fileStream = new MemoryStream();
            ImageFormat imageFormat = null;
            if (thumbIt)
            {
                img = ScaleImage(img, maxWidth, maxHeight);
            }

            if (mime == "image/jpg" || mime.ToLower() == "image/jpeg" || mime == "image/pjpeg")
            {
                imageFormat = ImageFormat.Jpeg;
            }
            else if (mime == "image/gif")
            {
                imageFormat = ImageFormat.Gif;
            }
            else if (mime == "image/x-png" || mime == "image/png")
            {
                imageFormat = ImageFormat.Png;
            }
            else
            {
                imageFormat = ImageFormat.Bmp;
            }

            img.Save(fileStream, imageFormat);
            fileStream.Position = 0;
            img.Dispose();
            ImageResult imageResult = new ImageResult()
            {
                Stream = fileStream,
                Type = mime,
                Name = uploadedFile.NewName
            };

            return imageResult;
        }
        private static Image ScaleImage(Image image, int maxWidth, int maxHeight)
        {
            var ratioX = (double)maxWidth / image.Width;
            var ratioY = (double)maxHeight / image.Height;
            var ratio = Math.Min(ratioX, ratioY);

            var newWidth = (int)(image.Width * ratio);
            var newHeight = (int)(image.Height * ratio);

            var newImage = new Bitmap(newWidth, newHeight);

            using (var graphics = Graphics.FromImage(newImage))
                graphics.DrawImage(image, 0, 0, newWidth, newHeight);

            return newImage;
        }
    }

}
