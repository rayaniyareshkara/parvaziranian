﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class LoginVm
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Password { get; set; }
        public bool IsRemember { get; set; }

        public string UrlExhibition { get; set; }
    }
}
