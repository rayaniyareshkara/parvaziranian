﻿namespace CMS.Schema.PortalAmio.ExhibitionUi
{
    public class ExhibitionsListVm
    {
        public string Title { get; set; }

        public string Image { get; set; }

        public string StartDate { get; set; }

        public string Time { get; set; }

        public string Url { get; set; }

        public string Link { get; set; }
    }
}
