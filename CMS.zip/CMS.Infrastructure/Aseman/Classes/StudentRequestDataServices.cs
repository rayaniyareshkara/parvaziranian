﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
 public   class StudentRequestDataServices : ConversionMain<StudentRequest, int>, IStudentRequest
    {
        public StudentRequestDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<StudentRequest, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
