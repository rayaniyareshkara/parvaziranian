﻿namespace CMS.Schema.PortalAmio.Stand
{
    public class StandGridSchema
    {
        public int Id { get; set; }

        public string Place { get; set; }

        public string Hall { get; set; }

        public string Title { get; set; }

        public string Status { get; set; }
    }
}
