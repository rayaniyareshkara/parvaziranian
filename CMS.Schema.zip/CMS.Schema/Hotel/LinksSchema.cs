﻿
namespace CMS.Schema.Hotel
{
    public class LinksSchema 
    {
        public int Id { get; set; }
        public string Link { get; set; }
        public string Event { get; set; }
        public string Social { get; set; }
        public string Title { get; set; }
        public int Count { get; set; }
    }
}
