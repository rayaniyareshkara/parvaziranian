﻿using CMS.Core.Component;
using CMS.Schema.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Web.Mvc;

namespace CMS.Core.Attribute
{
    public class StaffPermission : ActionFilterAttribute, IActionFilter
    {
        private readonly string PageId;
        private readonly string Root;
        private readonly string Code;
        private readonly PermissonEnum Type;
        public StaffPermission(string pageCode, PermissonEnum Type, string Root = "view")
        {
            try
            {
                this.Root = Root.ToLower();
                this.PageId = pageCode.ToLower();
                this.Type = Type;
                if (SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }) != null)
                {
                    var activeId = Guid.Parse(SetCookie.ValueCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS }).ActiveCode);
                    this.Code = activeId.ToString();
                }
            }
            catch (Exception)
            {
                SetCookie.DeleteCookie(new Schema.Coockie { BehinNewsaadCMS = Schema.CoockieEnum.ModirBehinNewsaadCMS });
            }
        }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {

                var hasPermision = true;
                if (hasPermision == false)
                {
                    if (Root == "view")
                    {
                        var viewResult = new ViewResult
                        {
                            ViewName = "~/Areas/staff/Views/Error/Error403.cshtml",
                        };
                        filterContext.Result = viewResult;
                    }
                    else if (Root == "json")
                    {
                        var Result = new JsonResult
                        {
                            Data = new { status = "!ok", error = "دسترسی ندارید" },

                            JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                        };
                        filterContext.Result = Result;
                    }
                    else
                    {

                        var viewResult = new PartialViewResult
                        {
                            ViewName = "~/Areas/staff/Views/Error/ChildError403.cshtml",
                        };

                        filterContext.Result = viewResult;
                    }
                }


            }
            catch (Exception )
            {
                // filterContext.Result = new RedirectResult("/fa/Account/Login?returnUrl=" + filterContext.HttpContext.Request.CurrentExecutionFilePath);
            }

            base.OnActionExecuting(filterContext);

        }
    }
}
