﻿
namespace CMS.Schema.PortalCustomize.Language
{
    public class LanDropDownVm
    {
        public int Id { get; set; }

        public string Title { get; set; }
    }
}
