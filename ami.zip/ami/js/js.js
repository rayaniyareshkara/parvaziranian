﻿


//
$(".hover").mouseleave(
	function () {
		$(this).removeClass("hover");
	}
);



//


function scrollNav() {
	$('.nav a').click(function () {
		$(".active").removeClass("active");
		$(this).addClass("active");

		$('html, body').stop().animate({
			scrollTop: $($(this).attr('href')).offset().top - 160
		}, 300);
		return false;
	});
}
scrollNav();




//counter  //counter  //counter


let didScroll = false;
let paralaxTitles = document.querySelectorAll('.paralax-title');

const scrollInProgress = () => {
	didScroll = true
}

const raf = () => {
	if (didScroll) {
		paralaxTitles.forEach((element, index) => {
			element.style.transform = "translateX(" + window.scrollY / 10 + "%)"
		})
		didScroll = false;
	}
	requestAnimationFrame(raf);
}


requestAnimationFrame(raf);
window.addEventListener('scroll', scrollInProgress)
//counter




//time

(function init() {
	function getTimeRemaining(endtime) {
		var t = Date.parse(endtime) - Date.parse(new Date());
		var seconds = Math.floor((t / 1000) % 60);
		var minutes = Math.floor((t / 1000 / 60) % 60);
		var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
		var days = Math.floor(t / (1000 * 60 * 60 * 24));
		return {
			'total': t,
			'days': days,
			'hours': hours,
			'minutes': minutes,
			'seconds': seconds,

		};
	}

	function initializeClock(endtime) {
		var timeinterval = setInterval(function () {
			var t = getTimeRemaining(endtime);
			document.querySelector(".days > .value").innerText = t.days;
			document.querySelector(".hours > .value").innerText = t.hours;
			document.querySelector(".minutes > .value").innerText = t.minutes;
			document.querySelector(".seconds > .value").innerText = t.seconds;
			if (t.total <= 0) {
				clearInterval(timeinterval);
			}
		}, 1000);
	}
	initializeClock(((new Date()).getFullYear() + 1) + "/1/1")
})()


