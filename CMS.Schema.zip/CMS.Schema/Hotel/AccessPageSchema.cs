﻿
namespace CMS.Schema.Hotel
{
    public class AccessPageSchema
    {
        public int id { get; set; }
        public string text { get; set; }
        public bool is_checked { get; set; }
        public bool is_insert { get; set; }
        public bool is_update { get; set; }
        public bool is_active { get; set; }
        public bool is_delete { get; set; }
        public bool is_select { get; set; }

        //  public int page_id { get; set; }
    }
}
