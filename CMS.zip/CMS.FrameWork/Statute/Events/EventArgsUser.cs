﻿using System;

namespace CMS.FrameWork.Statute.Events
{
    public class EventArgsUser 
    {
        public int Id { get; set; }
    }
}
