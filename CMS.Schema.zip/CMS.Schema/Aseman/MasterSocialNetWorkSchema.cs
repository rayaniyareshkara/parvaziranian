﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class MasterSocialNetWorkSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Icon { get; set; }
        public string Link { get; set; }
        public int MasterId { get; set; }
        public int? IsTrue { get; set; }
        public string MasterName { get; set; }
        public Guid MasterUserId { get; set; }

    }
}
