﻿
namespace CMS.Schema.Admin
{
    using System;

    public class SearchUsersSite
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string TypeSearch { get; set; }
    }
}
