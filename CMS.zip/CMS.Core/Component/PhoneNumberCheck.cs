﻿namespace CMS.Core.Component
{
    public class PhoneNumberCheck
    {

        /// <summary>
        /// تغییر عدد به انگلیسی و حذف +
        /// </summary>
        /// <param name="Phone"> شماره تلفن </param>
        /// <returns></returns>
        public static string Check(string Phone)
        {
            return Phone?
                  .Replace("۰", "0")
                  .Replace("۱", "1")
                  .Replace("۲", "2")
                  .Replace("۳", "3")
                  .Replace("۴", "4")
                  .Replace("۵", "5")
                  .Replace("۶", "6")
                  .Replace("۷", "7")
                  .Replace("۸", "8")
                  .Replace("۹", "9")
                  .Replace("+", "");

        }
    }
}
