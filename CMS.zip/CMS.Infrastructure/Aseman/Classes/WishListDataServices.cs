﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
   public class WishListDataServices : ConversionMain<WishList, int>, IWishList
    {
        public WishListDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<WishList, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
