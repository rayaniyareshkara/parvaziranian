﻿

using System;

namespace CMS.Schema.Mohandesan
{
   public class NewsSchema
    {
        public Guid Id { get; set; }
        public string Image { get; set; }
        public string Title { get; set; }
        public string Embed { get; set; }
        public DateTime Date { get; set; }
        public string Category { get; set; }
        public string Header { get; set; }
        public int IntId { get; set; }
        public string Description { get; set; }
        public string Author { get; set; }
        public DateTime ReleaseDate { get; set; }
        public DateTime ExpireDate{ get; set; }
        public string Body { get; set; }
        public int? galleryId { get; set; }
        public bool IsActive { get; set; }
        public string TypeNews { get; set; }
        public string MetaKey { get; set; }
        public string MetaName { get; set; }
        public string MetaDesc { get; set; }

        public string Rotter { get; set; }
       public string Tags { get; set; }

        public string Subtitle { get; set; }
        public string Lead { get; set; }
        public string CategoryId { get; set; } 
        public string Summary { get; set; }
        public int ViewCount { get; set; }
    }
}
