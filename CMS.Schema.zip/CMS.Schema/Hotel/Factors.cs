﻿

using System;

namespace CMS.Schema.Hotel
{
    public class Factors 
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Titme { get; set; }
        public DateTime Date { get; set; }
        public string Price { get; set; }
        public bool Status { get; set; }
        public string Code { get; set; }
        public string Hotel { get; set; }
      
    }

    
}
