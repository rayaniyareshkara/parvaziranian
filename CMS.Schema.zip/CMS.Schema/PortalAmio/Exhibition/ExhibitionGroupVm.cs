﻿using System.Collections.Generic;

namespace CMS.Schema.PortalAmio.Exhibition
{
    public class ExhibitionGroupVm
    {
        public ExhibitionCrudVm Exhibition { get; set; }

        public IEnumerable<ExhibitionGalleryVm> Gallery { get; set; }

        public IEnumerable<ExhibitionLocationCrud> Location { get; set; }
    }
}
