﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Enum.Notification
{
    public enum TypeNotificationEnum : byte
    {
        [Display(Name = "ثبت نام")]
        Register = 1,
        
    }
}
