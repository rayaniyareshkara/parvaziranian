﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CMS.Schema.PortalAmio.Exhibition
{
    public class ExhibitionCrudVm
    {

        public int Id { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        [DisplayName("عنوان")]
        public string Title { get; set; }
        [DisplayName("نوع نمایشگاه")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int TypeId { get; set; }
        [DisplayName("زبان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int Lang { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("تاریخ شروع")]
        public string StartDate { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("تاریخ پایان")]
        public string EndDate { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("تاریخ شروع ثبت نام ")]
        public string RegistrationStartDate { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("تاریخ پایان ثبت نام ")]
        public string EndDateOfRegistration { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(500, ErrorMessage = "{0} طول نمی تواند بیشتر از 500 حروف باشد")]
        [DisplayName("خلاصه متن")]
        public string Summery { get; set; }
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]
        [DisplayName("لینک نمایشگاه")]
        public string Link { get; set; }
        [AllowHtml]
        public string Description { get; set; }
        [DisplayName("تصویر")]

        public string Image { get; set; }
        [DisplayName("تصویر بنری سمت راست")]

        public string RightBannerImage { get; set; }
        [DisplayName("تصویر بنری سمت چپ")]

        public string LeftBannerImage { get; set; }
        [DisplayName("تصویر بنری مرکزی")]

        public string CenterBannerImage { get; set; }
        [DisplayName("فضای نمایشگاه")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]

        public string HoldingSpace { get; set; }
        [DisplayName("زمان بازدید")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد")]

        public string VisitingTime { get; set; }
        [DisplayName("خبر نمایشگاه")]
        public int? NewsId { get; set; }
        [DisplayName("اسلایدر")]
        public bool? Slider { get; set; }
        [DisplayName("قیمت پیش ثبت نام")]
        [Required(ErrorMessage = "{0} الزامی است")]

        public int PreRegistrationPrice { get; set; }
        [DisplayName("فعال/غیرفعال")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public bool Status { get; set; }
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد ")]
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("آدرس")]
        public string Url { get; set; }
        [DisplayName("کلمات کلیدی")]
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        public string MetaKeyWord { get; set; }
        [DisplayName("عنوان صفحه")]
        [StringLength(150, ErrorMessage = "{0} طول نمی تواند بیشتر از 150 حروف باشد ")]
        public string PageTitle { get; set; }
        [DisplayName("آدرس")]
        [StringLength(500, ErrorMessage = "{0} طول نمی تواند بیشتر از 500 حروف باشد ")]
        public string MetaDescription { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("فعال بودن ثبت نام")]
        public bool IsRegisterActive { get; set; }

        [DisplayName("غرفه ها")]
        public int?[] StandId { get; set; }
        [DisplayName("ترتیب")]

        public int? IdRow { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("سالن")]

        public int[] HallId { get; set; }



    }
}
