﻿namespace CMS.Schema.Staff
{
    public class DescriptionTextShowGrid
    {
        public int Id  { get; set; }

        public string Caption { get; set; }

        public string Exhibition { get; set; }

        public int IdRow { get; set; }
    }
}
