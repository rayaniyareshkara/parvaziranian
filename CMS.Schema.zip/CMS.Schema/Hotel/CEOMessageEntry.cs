﻿

namespace CMS.Schema.Hotel
{
    public class CEOMessageEntry
    {

        public string Phone { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
        public string FullName { get; set; }
    }
}
