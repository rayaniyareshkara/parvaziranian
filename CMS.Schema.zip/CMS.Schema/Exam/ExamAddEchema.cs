﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
    public class ExamAddEchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string Code { get; set; }
    
        public int Status { get; set; }
       

        public int Duration { get; set; }
        public int NegativePoint { get; set; }
        public int MaxPoint { get; set; }
        public int acceptablePoint { get; set; }
        public int RandomQuestion { get; set; }
        public int Maxquestion { get; set; }
        public bool IsRemote { get; set; }
        public bool IsInvigilator { get; set; }
        public string Image { get; set; }
        public bool IsActive { get; set; }

        public int ExamTypeId { get; set; }
        public int MasterId { get; set; }
        
        public int LanguageId { get; set; }
        public int ExnaminerId { get; set; }
        public DateTime AcceptableStartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? AcceptableEndDate { get; set; }
        public int ExamHardShipId { get; set; }
        public int ExamFrameId { get; set; }
        public int ExamCenterId { get; set; }
        public Guid UserId { get; set; }
        public int? CourseId { get; set; }
        public int? MainCourseId { get; set; }
        public int? DegreeId { get; set; }
        public bool IsFullRandom { get; set; }
        public List<Qrequest> QuestionList { get; set; }
    }
    public class Qrequest
        {
     
        public int Count  { get; set; }
        public int CourseId  { get; set; }
        public int MainCourseId  { get; set; }

    }
}
