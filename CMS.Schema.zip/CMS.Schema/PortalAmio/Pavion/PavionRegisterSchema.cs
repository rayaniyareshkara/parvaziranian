﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Pavion
{
   public  class PavionRegisterSchema
    {
        public int PavionId { get; set; }
        public string CompanyNameFa { get; set; }
        public string CompanyNameEn { get; set; }
        public string ContactPerson { get; set; }
        public string ContactPersonEn { get; set; }
        public string WebSite { get; set; }
        public string EmailId { get; set; }

        public string CountryId { get; set; }
        public string ProvinceId { get; set; }
        public int CityId { get; set; }
        public string RelatedPerson { get; set; }
        public string PhoneNumber { get; set; }
        public string SkypeID { get; set; }
        public int SaloonPlaceRequestDollar { get; set; }
        public int BildingModel { get; set; }
        public string TitleEnglish { get; set; }
        public string TitlePersian { get; set; }
        public bool SaloonPlaceModelNormal { get; set; }
        public bool SaloonPlaceModelSpetial { get; set; }
        public bool SaloonPlaceModelspanser { get; set; }
        public int OpenPlaceRequestDollar { get; set; }
        public bool OPenPlaceModelSpetial { get; set; }
        public bool OPenPlaceModelNormal { get; set; }
        public int BuildingTypeId { get; set; }
        public string ActivityFieldFa { get; set; }
        public string ActivityFieldEn { get; set; }
        public string MDrictorNameFa { get; set; }
        public string MDrictorNameEn { get; set; }
        public string MDirectorEmail { get; set; }
        public string MDrictorMobile { get; set; }
        public string Fax { get; set; }
        public string PostCode { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string PreferConnection { get; set; }

    }
}
