﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
   public class ExamFrameAddSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string Code { get; set; }
        public int Duration { get; set; }
        public decimal NegativePoint { get; set; }
        public int MaxPoint { get; set; }
        public int acceptablePoint { get; set; }
        public bool RandomQuestion { get; set; }
        public int Maxquestion { get; set; }
        public bool IsRemote { get; set; }
        public bool IsInvigilator { get; set; }
        public string Image { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int ExamTypeId { get; set; }
        public int LanguageId { get; set; }
        public System.DateTime CreateDate { get; set; }
        public int ExamHardShipId { get; set; }

        public List<myHeadLine> MyHeadLine { get; set; }
    } 
   public  class myHeadLine
    {
        public int Id { get; set; }
        public int Count { get; set; }

        public int HeadLineId { get; set; }

    }
}
