﻿namespace CMS.Schema.Global
{
    public class DropDwnStatusVm
    {
        public bool Id  { get; set; }

        public string Title { get; set; }
    }

    public class DropDownApprove
    {
        public int Id { get; set; }

        public string Title { get; set; }
    }
}
