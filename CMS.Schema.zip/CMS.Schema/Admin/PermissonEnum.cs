﻿

namespace CMS.Schema.Admin
{
    public enum PermissonEnum
    {
        IsActive,
        IsSelect,
        IsDelete,
        IsUpdate,
        IsInsert
    }
}
