﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
public    class SliderPageSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public DateTime?  StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Link { get; set; }
        public string Image { get; set; }
        public int SliderId { get; set; }
        public string SliderName { get; set; }

        
    }
}
