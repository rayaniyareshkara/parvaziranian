﻿

using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
    public class LawfirmInfoSchema
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Image { get; set; }
        public List<LawFirmInFields> Field { get; set; }
        public string Fax { get; set; }
        public string Tel1 { get; set; }
        public string Tel2 { get; set; }
        public string Title { get; set; }
        public string Address { get; set; }
        public string AboutMe { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public List<EnforcerActivityShcema> Activity { get; set; }
        public List<EnforcerProjectsSchema> Projects { get; set; }
        public List<LicenseShcema> License { get; set; }

    }
}
