﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
   public class RulesSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string description { get; set; }
        public string  ImgFile { get; set; }
        public bool IsActive { get; set; }
        public int ClubId { get; set; }

    }
}
