﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
    public class FinanceDocDataServices : ConversionMain<FinanceDoc, int>, IFinanceDoc
    {
        public FinanceDocDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<FinanceDoc, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}