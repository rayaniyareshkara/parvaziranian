﻿
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    
    public class HotelServiceViewModel
    {
        public int Id { get; set; }
        public List<ListBoxSchema> Times { get; set; }
        public string Desc { get; set; }
        public string Title { get; set; }
        public bool IsTotal_Price { get; set; }
        public string Unit { get; set; }
        public int HotelId { get; set; }
        public string  Tour { get; set; }
        public string Image { get; set; }
        public int Capacity { get; set; }
        
        public int Reservs { get; set; }
        public int Price { get; set; }
    }
}
