﻿using CMS.FrameWork.Model;
using CMS.Schema.Support;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Core.Component
{
  public  class ExhibitionMenuModel
    {
        public class ExhibitionMenuJson
        {
            public class ExhibitionDataObj
            {
               

                public Guid Id { get; set; }

                public int Order { get; set; }
                public Dictionary<string, string> TitleinLanguages { get; set; }

                public Dictionary<string, string> UrlinLanguages { get; set; }
                public bool? IsUrlEditable { get; set; }
                public List<ExhibitionDataObj> Nodes { get; set; }

                public string Source { get; set; }
                public Guid? SourceKey { get; set; }

                public Guid? ParentId { get; set; }
            }

            public List<ExhibitionDataObj> Data { get; set; }

            public List<string> Inserted { get; set; }

            public List<string> Deleted { get; set; }

            public List<string> MyProperty { get; set; }
        }

        public ExhibitionMenuModel.ExhibitionMenuJson GenerateMenuJson(ExhibitionMenu[] menus, FrameWork.Model.Language[] languages)
        {
            ExhibitionMenuModel.ExhibitionMenuJson menuJson = new ExhibitionMenuModel.ExhibitionMenuJson { Data = RecursiveGenerateNode(menus, languages, null) };
            return menuJson;
        }

        public List<ExhibitionMenuModel.ExhibitionMenuJson.ExhibitionDataObj> RecursiveGenerateNode(ExhibitionMenu[] menus, FrameWork.Model.Language[] languages, Guid? parentId)
        {
            List<ExhibitionMenuModel.ExhibitionMenuJson.ExhibitionDataObj> json = new List<ExhibitionMenuModel.ExhibitionMenuJson.ExhibitionDataObj>();

            var parentMenus = menus.Where(m => m.ParentId == parentId).OrderBy(m => m.Order).GroupBy(g => g.Id).Select(s => s.First()).ToArray();

            foreach (var menu in parentMenus)
            {
                ExhibitionMenuModel.ExhibitionMenuJson.ExhibitionDataObj node = new ExhibitionMenuModel.ExhibitionMenuJson.ExhibitionDataObj
                {
                    Id = menu.Id,
                    IsUrlEditable = !menu.Default,
                    Source = menu.Source,
                    SourceKey = menu.SourceKey,
                    UrlinLanguages=new Dictionary<string, string>(),
                    TitleinLanguages=new Dictionary<string, string>()
                };
                foreach (var lang in languages)
                {
                    var tmp = menus.FirstOrDefault(m => m.LanguageId == lang.Id && m.Id == menu.Id);
                    if (tmp != null)
                    {
                        node.UrlinLanguages.Add(lang.Id.ToString(), tmp.Url);
                        node.TitleinLanguages.Add(lang.Id.ToString(), tmp.Title);
                    }
                }
                node.Nodes = RecursiveGenerateNode(menus, languages, menu.Id);
                json.Add(node);
            }
            return json;
        }

        //public void UpdateMenues(MenuModel.MenuJson data)
        //{
        //    //var menusToDelete = _context.Menu.Where(m => data.Deleted.Contains(m.Id.ToString()));
        //    //if (menusToDelete.Any())
        //    //{
        //    //    _context.Menu.RemoveRange(menusToDelete);
        //    //    _context.SaveChanges();
        //    //}


        //    //List<MenuSchema> menus = RecursiveConvertDataObjToMenu(data.Data);

        //    //if (menus.Any())
        //    //{
        //    //    _context.Menu.AddOrUpdate(menus.ToArray());
        //    //    _context.SaveChanges();
        //    //}
        //}

        public List<ExhibitionMenuSchema> RecursiveConvertDataObjToMenu(List<ExhibitionMenuModel.ExhibitionMenuJson.ExhibitionDataObj> data)
        {
            var menus = new List<ExhibitionMenuSchema>();
            foreach (var dataObj in data)
            {
                foreach (var lang in dataObj.TitleinLanguages.Keys)
                {
                    ExhibitionMenuSchema menu = new ExhibitionMenuSchema()
                    {
                        Id = dataObj.Id,
                        Url = dataObj.UrlinLanguages[lang],
                        Title = dataObj.TitleinLanguages[lang],
                        Order = dataObj.Order,
                        ParentId = dataObj.ParentId,
                        Source = dataObj.Source,
                        SourceKey = dataObj.SourceKey,
                        Language = Convert.ToInt32(lang)
                    };
                    menus.Add(menu);
                }

                if (dataObj.Nodes != null && dataObj.Nodes.Any())
                {
                    menus.AddRange(RecursiveConvertDataObjToMenu(dataObj.Nodes));
                }
            }

            return menus;
        }


    }
}