﻿using CMS.Schema.Portal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;

namespace CMS.Core.Component
{
    public enum EmailSendingResult
    {
        Success = 1,
        Error = 0,
    }
    public class PortalEmailServices
    {



        private Email config;
        public PortalEmailServices()
        {
            config = ConfigData.Load()?.EmailConfig ?? new Email();
        }
        public PortalEmailServices(Email config)
        {
            this.config = config;
        }
        //  private string _Template = $" <div> تاریخ : {ConvertDateTime.GregorianToPersian(DateTime.Now)} </div> <div > #text# </div> ";

        public string Send(IList<string> email, string subject, string Body = "")
        {
            try
            {
                if (!email.Any())
                    return "Email Is Null";




                SmtpClient mySmtpClient = new SmtpClient(config.Host, Int32.Parse(config.SMTPPort));

                // set smtp-client with basicAuthentication
                mySmtpClient.UseDefaultCredentials = config.UseDefultCredential;
                System.Net.NetworkCredential basicAuthenticationInfo = new
                    System.Net.NetworkCredential(config.EmailAdress, config.Password);
                mySmtpClient.Credentials = basicAuthenticationInfo;

                // add from,to mailaddresses
                MailAddress from = new MailAddress(config.EmailAdress);

                MailMessage myMail = new System.Net.Mail.MailMessage();


                foreach (var item in email)
                    myMail.To.Add(item);

                // add ReplyTo

                // set subject and encoding
                myMail.Subject = subject;
                myMail.SubjectEncoding = System.Text.Encoding.UTF8;
                myMail.From = from;
                // set body-message and encoding
                myMail.Body = Body;
                myMail.BodyEncoding = System.Text.Encoding.UTF8;
                // text or html
                myMail.IsBodyHtml = config.ISBodyHTML;
                mySmtpClient.EnableSsl = true;
                mySmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                mySmtpClient.Send(myMail);

                return "Email Is Success";
            }
            catch (System.Exception ex)
            {
                new FrameWork.Statute.Events.EventSite().Other(ex, "email.sending");
                return ex.Message;
            }

        }

        public EmailSendingResult SendEmailByGmail(string email, string subject, string body = "")
        {
            try
            {
                if (!email.Any())
                    return EmailSendingResult.Error;

                var mail = new MailMessage();

                var smtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("amiorg.com@gmail.com");

                mail.To.Add(email);

                mail.Subject = subject;

                mail.Body = body;
                mail.IsBodyHtml = true;
                smtpServer.Port = 587;
                smtpServer.Credentials = new System.Net.NetworkCredential("amiorg.com@gmail.com", "bnaco@1234");
                smtpServer.EnableSsl = true;

                smtpServer.Send(mail);



                return EmailSendingResult.Success;
            }
            catch (System.Exception ex)
            {
                new FrameWork.Statute.Events.EventSite().Other(ex, "email.sending");
                return EmailSendingResult.Error;
            }

        }

    }
}
