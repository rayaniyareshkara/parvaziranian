﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
  public  class CommentShowSchema
    {

        public int Id { get; set; }
        public int? ArticleId { get; set; }
            public string Name { get; set; }
        public string ArticleName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string StatusName { get; set; }
        public int? ParentKey { get; set; }
        public int Count { get; set; }
        public int Status { get; set; }
          
            public string Discription { get; set; }
            public DateTime CreateDate { get; set; }
            public int ParentId { get; set; }
        public List<CommentChild> Child { get; set; }

    }
    public class CommentChild
    {
        public string Name { get; set; }

        public string Discription { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
