﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;

using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
   public class JobOfferDataServices : ConversionMain<JobOffer, int>, IJobOffer
    {
        public JobOfferDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<JobOffer, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}

