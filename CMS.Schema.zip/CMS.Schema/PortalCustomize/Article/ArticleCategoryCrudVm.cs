﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalCustomize.Article
{
    public class ArticleCategoryCrudVm
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد")]
        [DisplayName("عنوان")]
        public string Caption { get; set; }
        [DisplayName("فعال/غیرفعال")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public bool Status { get; set; }
        [DisplayName("زبان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int Lang { get; set; }
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد ")]
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("آدرس")]
        public string Url { get; set; }
        [DisplayName("عنوان صفحه")]
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد ")]
        public string PageTitle { get; set; }
        [DisplayName("آدرس")]
        [StringLength(300, ErrorMessage = "{0} طول نمی تواند بیشتر از 300 حروف باشد ")]
        public string MetaDescription { get; set; }
    }
}
