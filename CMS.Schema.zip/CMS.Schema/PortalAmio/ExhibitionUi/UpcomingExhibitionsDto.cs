﻿using System;

namespace CMS.Schema.PortalAmio.ExhibitionUi
{
    public class UpcomingExhibitionsDto
    {
        public string Title { get; set; }

        public string Image { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string Url { get; set; }

        public int Year { get; set; }

        public string VisitingTime { get; set; }
        /// <summary>
        /// ماه شمسی
        /// </summary>
        public int SolarMonth { get; set; }

        public string Link { get; set; }

        public string Summery { get; set; }

        public string Place { get; set; }
    }
}
