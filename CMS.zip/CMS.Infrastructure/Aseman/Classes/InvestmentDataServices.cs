﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class InvestmentDataServices : ConversionMain<Investment, int>, IInvestment
    {
        public InvestmentDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<Investment, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
