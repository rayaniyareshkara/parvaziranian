﻿
namespace CMS.Schema.Mohandesan
{
    public class LawfirmExaminationFieldsSchema 
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Code { get; set; }

        public double Price { get; set; }
        
    }
}
