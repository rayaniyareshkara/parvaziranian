﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class HomeWorkStudentShowSchema
    {
        public int Id { get; set; }
        public int CourseTermTimeId { get; set; }
        public string Title { get; set; }
        public string AcceptDate { get; set; }
        public DateTime? AcceptDateMain { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public bool  Status { get; set; }
        public int  AnswerId { get; set; }
        public int  MasterStatus { get; set; }
    }
}
