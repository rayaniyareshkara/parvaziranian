﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
 public   class SurveyAnswerUserSchema
    {
        public int SurveyAnswerId { get; set; }
        public string Description { get; set; }
        public List<SAnswer> MyAnswer { get; set; }
    }
    public class SAnswer
    {
        public string Answer { get; set; }
        public int Id { get; set; }

    }
}
