﻿
using System;

namespace CMS.Schema.Mohandesan
{
    public class AllUserSchema
    {
        public string Mobile { get; set; }
        public string UserType { get; set; }
        public string KDate { get; set; }
        public Guid Id { get; set; }
        public string UserTypeName { get; set; }
        public string Password { get; set; }
    }
}
