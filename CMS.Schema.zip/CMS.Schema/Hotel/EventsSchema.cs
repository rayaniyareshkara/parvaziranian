﻿

using System;
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class EventsSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
        public string StartDate { get; set; }
        public string PersianDate { get; set; }
        public string HotelName { get; set; }
        public int Capacity { get; set; }
        public int Reserve { get; set; }
        public List<string> Gallery { get; set; }
        public string StatusClass { get; set; }
        public string Status { get; set; }
        public string EndDate { get; set; }
        public string RunDate { get; set; }
        public DateTime Date { get; set; }
        public int HotelId { get; set; }
    }


    public enum RoomSortType
    {
        Order,
        New,
        Expensive,
        Inexpensive,
        MostView,
        MostReserve,
        MostDiscount,
    }
}
