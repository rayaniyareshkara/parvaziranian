﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
  public  class MasterBranchDataServices : ConversionMain<MasterBranch, int>, IMasterBranch
    {
        public MasterBranchDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<MasterBranch, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
