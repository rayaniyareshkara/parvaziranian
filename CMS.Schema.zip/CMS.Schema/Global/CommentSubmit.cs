﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Global
{
    public class CommentSubmit
    {
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(500, ErrorMessage = "{0} طول نمی تواند بیشتر از 500 حروف باشد")]
        [DisplayName("نظرات")]
        public string Comment { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(50, ErrorMessage = "{0} طول نمی تواند بیشتر از 50 حروف باشد")]
        [DisplayName("عنوان")]
        public string Title { get; set; }
        [StringLength(50, ErrorMessage = "{0} طول نمی تواند بیشتر از 50 حروف باشد")]
        [DisplayName("شماره تلفن")]
        public string PhoneNumber { get; set; }
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد")]
        [DisplayName("نام ونام خانوادگی")]
        public string FullName { get; set; }

        public Guid? UserId { get; set; }
    }
}
