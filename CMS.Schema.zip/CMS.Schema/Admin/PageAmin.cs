﻿
namespace CMS.Schema.Admin
{
    using System;

    public class PageAmin
    {
        public System.Guid Id { get; set; }
        public string Url { get; set; }
        public bool InMenu { get; set; }
        public string PageTitle { get; set; }
        public string Content { get; set; }
        public string Meta { get; set; }
        public Nullable<int> Language { get; set; }
        public string Tag { get; set; }
        public Nullable<System.Guid> GalleryId { get; set; }
        public bool IsActive { get; set; }
    }
}
