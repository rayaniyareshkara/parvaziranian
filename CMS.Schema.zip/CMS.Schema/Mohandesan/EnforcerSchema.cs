﻿

namespace CMS.Schema.Mohandesan
{
    public class EnforcerSchema
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Mobile { get; set; }
        public string Grade { get; set; }
        public string Field { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public int Order { get; set; }

    }
}
