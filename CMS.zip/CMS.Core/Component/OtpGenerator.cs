﻿using System;
using System.Security.Cryptography;

namespace CMS.Core.Component
{
    public class OtpGenerator
    {
        private static char[] punctuations = "!@#$%^&*()_-+=[{]};:>|./?".ToCharArray();
        public static string GenerateCode(int length, int numberOfNonAlphanumericCharacters)
        {

            string password;
            byte[] buf;
            char[] cBuf;
            int count;
            buf = new byte[length];
            cBuf = new char[length];
            count = 0;

            (new RNGCryptoServiceProvider()).GetBytes(buf);

            for (int iter = 0; iter < length; iter++)
            {
                int i = (int)(buf[iter] % 87);
                if (i < 10)
                    cBuf[iter] = (char)('0' + i);
                else if (i < 36)
                    cBuf[iter] = (char)('A' + i - 10);
                else if (i < 62)
                    cBuf[iter] = (char)('a' + i - 36);
                else
                {
                    cBuf[iter] = punctuations[i - 62];
                    count++;
                }
            }

            if (count < numberOfNonAlphanumericCharacters)
            {
                int j, k;
                Random rand = new Random();

                for (j = 0; j < numberOfNonAlphanumericCharacters - count; j++)
                {
                    do
                    {
                        k = rand.Next(0, length);
                    }
                    while (!Char.IsLetterOrDigit(cBuf[k]));

                    cBuf[k] = punctuations[rand.Next(0, punctuations.Length)];
                }
            }

            password = new string(cBuf);


            return password;
        }


    }

}