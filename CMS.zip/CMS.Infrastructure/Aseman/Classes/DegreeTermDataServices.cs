﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
   public class DegreeTermDataServices : ConversionMain<DegreeTerm, int>, IDegreeTerm
    {
        public DegreeTermDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<DegreeTerm, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
