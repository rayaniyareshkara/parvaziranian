﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class LoginViewModel
    {

        //  [Required]
        //  [Display(Name = @"نام کاربری")]
        public string UserName { get; set; }

        //   [Required]
        //  [DataType(DataType.Password)]
        //  [Display(Name = @"رمز عبور")]
        public string Password { get; set; }

        // [Display(Name = @"مرا بخاطر بسپار")]
        public bool Remember { get; set; }

        public string Captcha { get; set; }

        public string ReturnUrl { get; set; }

    }
    public class ForgotViewModel2
    {
        [Required]
        [Display(Name = @"نام کاربری")]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.EmailAddress, ErrorMessage = "E-mail is not valid")]
        public string Email { get; set; }
    }

}
