﻿
namespace CMS.Schema.Mohandesan
{
    public class SliderSchema 
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Caption { get; set; }
        public string Color { get; set; }
        public string Image { get; set; }
        public string Link { get; set; }
        public string Url { get; set; }
        public string Alt { get; set; }
        public string Description { get; set; }
    }
}
