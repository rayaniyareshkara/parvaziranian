﻿
namespace CMS.Schema
{
    public enum CoockieEnum
    {
        ModirBehinNewsaadCMS,
        UsersBehinNewsaadCMS,
        BehinNewsaadCMS,
        ActiveCode,
        CartCookie
    }
}
