﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalAmio.Exhibition
{
    public class ExhibitionStandCrud
    {
        [DisplayName("غرفه های نمایشگاه")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int[] Stand { get; set; }
    }
}