﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Enum
{
    public enum ExhibitionApprovalStageEnum : byte
    {
        [Display(Name = "ثبت نام اولیه")]
        InitialRegistration = 1,
        [Display(Name = "تاییدیه کارشناس")]
        ExpertApproval = 2,
        [Display(Name = "تاییدیه کارشناس مرحله دوم ")]
        HeadquartersApproval = 3,
        [Display(Name = "درخواست  فضای نمایشگاهی")]
        ExhibitionSpaceApproval = 4,
        [Display(Name = "تاییدیه مالی")]
        FinancialConfirmation= 5,
        [Display(Name = "تایید فضای نمایشگاهی")]
        ConfirmationOfExhibitionSpace = 6,
        [Display(Name = "مدارک ارسالی")]
        SentDocuments = 7,
        [Display(Name = "پرداخت نهایی")]
        FinalPayment = 8,
        [Display(Name = "تکمیل ثبت نام")]
        CompleteRegistration = 9,
    }
}
