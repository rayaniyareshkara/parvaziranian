﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
public    class MainCourseTermSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string BranchName { get; set; }
        public string MainCourseName { get; set; }
        public string DegreeName { get; set; }
        public string Status { get; set; }
        public int StatusId { get; set; }
        public string DegreeTermName { get; set; }
        public int DegreeTermId { get; set; }
        public DateTime Createdate { get; set; }

    }
}
