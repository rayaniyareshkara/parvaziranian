﻿namespace CMS.Schema.PortalCustomize.ArticleUi
{
    public class CommentArticleVm
    {
        public int Id { get; set; }

        public int? ParentId { get; set; }

        public string Comment { get; set; }

        public string TypeUser { get; set; }

        public string Time { get; set; }
    }
}
