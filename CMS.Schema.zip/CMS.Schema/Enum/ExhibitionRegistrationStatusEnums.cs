﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Enum
{
    public enum ExhibitionRegistrationStatusEnums
    {
        [Display(Name = "صفحه پیدا نشد")]
        NotFound,
        [Display(Name = "وقت ثبت نام گذشته")]
        LastRegistrationDate,
        [Display(Name = "ثبت نام فعال نیست")]
        RegistrationNotReceived,
        [Display(Name = "ثبت نام فعال")]
        ActiveRegistration,
        [Display(Name = "کاربر ثبت نام نکرده است")]
        UserIsNotRegistered,
        [Display(Name = "ثبت نام شما در قسمت پروفایل هنوز کامل نشده است")]
        IsNotRegisterComplete,
        [Display(Name = "ثبت نام شما هنوز مورد تایید مدیر قرار نگرفته است")]
        NotApproved,
        [Display(Name = "کاربر لاگین نکرده است")]
        NotLogin,

    }
}
