﻿using System;
using System.Collections.Generic;

namespace CMS.Schema.Hall
{
    public class HallReserveRequestSchema
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Tel { get; set; }
        public string Mobile { get; set; }
        public string CeremonyName { get; set; }
        public int? CeremonyType { get; set; }
        public System.DateTime? CeremonyDate { get; set; }
        public int? GuestCount { get; set; }
        public string StartTime { get; set; }
        public string CeremonyTypeName { get; set; }
        public string EndTime { get; set; }
        public int Pricing { get; set; }
        public DateTime DateAdded { get; set; }
        public string PCeremonyDate { get; set; }
        public int LayoutId { get; set; }
        public string HallName { get; set; }
        public string HotelName { get; set; }
        public string AdditinalRequest { get; set; }
        public string Code { get; set; }
        public int HallId { get; set; }
        public System.Guid? UserId { get; set; }
        public string HolderName { get; set; }
        public bool ReadStatus { get; set; }
        public int Status { get; set; }
        public List<CeremonySchema> feature { get; set; } = new List<CeremonySchema>();
        public List<CeremonySchema> meal { get; set; } = new List<CeremonySchema>();
        public List<CeremonySchema> service { get; set; } = new List<CeremonySchema>();
        public LayoutItemSchema Layout { get; set; } = new LayoutItemSchema();
        public List<CeremonySchema> OtherPlan { get; set; } = new List<CeremonySchema>();
        public List<MenuReserveTypeSchema> Menu { get; set; } = new List<MenuReserveTypeSchema>();
        public HallPricingSchema PricingDetails { get; set; } = new HallPricingSchema();

    }
}
