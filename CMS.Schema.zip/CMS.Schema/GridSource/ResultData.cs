﻿

using System.Collections.Generic;

namespace CMS.Schema.GridSource
{
    public class ResultData<T> where T: class
    {
        public List<T> Data { get; set; }
        public int Total { get; set; }
    }
}
