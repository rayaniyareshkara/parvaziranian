﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
public    class BoothCardAddSchema
    {

        public int Id { get; set; }
        public string FullNameFa { get; set; }
         public string FullNameEn { get; set; }
        public int myExhibitionId { get; set; }
        public string ImgFile { get; set; }
        public int Status { get; set; }      
        public int CompanyId { get; set; }





    }
}
