﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
 public   class BranchDegreeDataServices : ConversionMain<BranchDegree, int>, IBranchDegree
    {
        public BranchDegreeDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<BranchDegree, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
