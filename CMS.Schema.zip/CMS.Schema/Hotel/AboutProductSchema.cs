﻿
namespace CMS.Schema.Hotel
{
    public class AboutProductSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Icon { get; set; }
    }
}
