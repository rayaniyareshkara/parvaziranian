﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using CMS.Schema.Global;

namespace CMS.Schema.PortalAmio.Exhibition
{
    public class ExhibitionLocationCrud
    {
        [DisplayName("سالن  نمایشگاه")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int HallId { get; set; }
        [DisplayName("مکان نمایشگاه")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int PlaceId { get; set; }
        [DisplayName("غرفه های نمایشگاه")]
        public int? StandId { get; set; }
    }

    public class ExhibitionLocationVm
    {
        public List<DropDownSelected> HallId { get; set; }


        public List<DropDownSelected> StandId { get; set; }

    }
}