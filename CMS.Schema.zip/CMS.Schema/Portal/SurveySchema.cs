﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
  public  class SurveySchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int SurveyTypeId { get; set; }
        public string SurveyTypeName { get; set; }
        public int StatusId { get; set; }
        public string StatusName { get; set; }
    }
}
