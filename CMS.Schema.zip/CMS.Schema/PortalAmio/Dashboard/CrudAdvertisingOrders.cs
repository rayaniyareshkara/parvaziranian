﻿namespace CMS.Schema.PortalAmio.Dashboard
{
    public class CrudAdvertisingOrders
    {
        public int LocationId { get; set; }

        public int ExhibitionId { get; set; }

        public string Description { get; set; }
    }
}
