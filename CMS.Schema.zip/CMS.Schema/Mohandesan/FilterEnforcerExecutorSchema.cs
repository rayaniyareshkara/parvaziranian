﻿
namespace CMS.Schema.Mohandesan
{
    public class FilterEnforcerExecutorSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Grade { get; set; }
        public double? Metter500  { get; set; }
        public double? Metter1000 { get; set; }
        public bool? IsJobSeeker { get; set; }
        public double? Metter2000 { get; set; }
        public double? MoreThan2000 { get; set; }
        public string Field { get; set; }
    }
}
