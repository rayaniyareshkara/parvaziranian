﻿
using System;

namespace CMS.Schema.Admin
{
    public class UserGroupSchema
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
        public string Mobile { get; set; }
        public int GroupId { get; set; }
        public Guid UserId { get; set; }
        public string FullName { get; set; }
    }
}
