﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using System.Threading.Tasks;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
 public    class ContactUsDataServices : ConversionMain<ContactU, int>, IContactUs
    {
        public ContactUsDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<ContactU, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}

