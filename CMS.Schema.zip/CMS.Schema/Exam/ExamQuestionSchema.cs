﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Exam
{
   public class ExamQuestionSchema
    {
        public int Id { get; set; }
        public int ExamId { get; set; }
        public string   ExamName { get; set; }
        public int QuestionId { get; set; }

        public string QuestionName { get; set; }
        public int Status { get; set; }
        public string StatusName { get; set; }
        
    }
}
