﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class HeadLineSourceSchema
    {
        public int Id { get; set; }
        public int HeadLineId { get; set; }       
        public string Title { get; set; }
        public string MainTitle { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public string Video { get; set; }
    public string File { get; set; }

        public DateTime CreateDate { get; set; }
        public List<headlineSource> HeadLineSourceList { get; set; }
    }
    
}
