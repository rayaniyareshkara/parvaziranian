﻿using CMS.Core.Component;
using CMS.FrameWork.Model;
using CMS.Schema;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;
using static CMS.Core.Component.SetCookie;

namespace CMS.Core.Attribute
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = false)]
    public class StudentCommitmentRequiredAttribute : ActionFilterAttribute
    {
        // اگر خواستی فقط روی نقش Student اعمال شود
        public string RoleName { get; set; } = "Student";

        // صفحه‌ای که باید ریدایرکت شود
        public string RedirectArea { get; set; } = "Users";
        public string RedirectController { get; set; } = "Dashboard";
        public string RedirectAction { get; set; } = "Commitment";

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
           
          
            // 2) اگر خود اکشن فعلی، صفحه تعهد یا ثبت تعهد است → لوپ نشود
            var currentController = (filterContext.RouteData.Values["controller"] ?? "").ToString();
            var currentAction = (filterContext.RouteData.Values["action"] ?? "").ToString();

            if (currentController.Equals(RedirectController, StringComparison.OrdinalIgnoreCase) &&
                (currentAction.Equals(RedirectAction, StringComparison.OrdinalIgnoreCase) ||
                 currentAction.Equals("SubmitAgreement", StringComparison.OrdinalIgnoreCase)))
            {
                base.OnActionExecuting(filterContext);
                return;
            }

            try
            {
                // 3) گرفتن UserId از کوکی
                Guid _userId = SetCookie.ValueCookie(new Coockie
                { BehinNewsaadCMS = CoockieEnum.UsersBehinNewsaadCMS }).UserId;

                using (var db = new EntitysModelCMS())
                {
                    // 4) چک کن اصلاً این یوزر دانشجو هست یا نه (RoleId = 1)
                    bool isStudent = db.UserSiteRoles
                        .Any(w => w.UsersSiteId == _userId && w.RoleId == 1);

                    // اگر دانشجو نیست (ادمین/استاد/…) دیگه این Attribute براش اعمال نشه
                    if (!isStudent)
                    {
                        base.OnActionExecuting(filterContext);
                        return;
                    }

                    // 5) وضعیت تعهد دانشجو
                    bool? isCommitment = db.Students
                        .Where(w => w.UserId == _userId)
                        .Select(s => s.IsCommitment)
                        .FirstOrDefault();

                    bool committed = isCommitment.HasValue && isCommitment.Value;

                    // اگر هنوز تعهد نداده → ریدایرکت به صفحه تعهد
                    if (!committed)
                    {
                        filterContext.Controller.TempData["CommitmentMessage"] =
                            "برای استفاده از سامانه، ابتدا باید فرم تعهد آموزشی – انضباطی را تأیید کنید.";

                        filterContext.Result = new RedirectToRouteResult(
                            new RouteValueDictionary(
                                new
                                {
                                    area = RedirectArea,
                                    controller = RedirectController,
                                    action = RedirectAction
                                }
                            )
                        );
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                // لاگ خطا
                new CMS.FrameWork.Statute.Events.EventSite().Other(ex);

                // در صورت خطا، از جهت احتیاط به صفحه تعهد بفرست
                filterContext.Controller.TempData["CommitmentMessage"] =
                    "خطایی در بررسی وضعیت تعهد رخ داده است. لطفاً مجدداً صفحه را باز کنید یا با پشتیبانی تماس بگیرید.";

                filterContext.Result = new RedirectToRouteResult(
                    new RouteValueDictionary(
                        new
                        {
                            area = RedirectArea,
                            controller = RedirectController,
                            action = RedirectAction
                        }
                    )
                );
                return;
            }

            base.OnActionExecuting(filterContext);
        }
    }
}
