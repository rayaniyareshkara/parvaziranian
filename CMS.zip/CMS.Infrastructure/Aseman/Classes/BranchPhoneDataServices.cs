﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;


namespace CMS.Infrastructure.Aseman.Classes
{
  public  class BranchPhoneDataServices : ConversionMain<BranchPhone, int>, IBranchPhone
    {
        public BranchPhoneDataServices(EntitysModelCMS context) : base(context)
        {
        }

        public override Expression<Func<BranchPhone, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
