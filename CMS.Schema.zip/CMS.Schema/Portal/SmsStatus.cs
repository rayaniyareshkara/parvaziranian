﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;


namespace CMS.Schema.Portal
{
    public enum SendSmsReturnType
    {
        [Description("")]
        None = -10,

        [Description("ارسال با موفقیت انجام شد")]
        SendWasSuccessful = 0,

        [Description("نام کاربر یا کلمه عبور نامعتبر می باشد")]
        InvalidUserNameOrPassword = 1,

        [Description("کاربر مسدود شده است")]
        UserBlocked = 2,

        [Description("شماره فرستنده نامعتبر است")]
        InvalidSenderNumber = 3,

        [Description("محدودیت در ارسال روزانه")]
        LimitationInDailySend = 4,

        [Description("تعداد گیرندگان حداکثر 100 شماره می باشد")]
        LimitationInRecieverCount = 5,

        [Description("خط فرسنتده غیرفعال است")]
        SenderLineIsInactive = 6,

        [Description("متن پیامک شامل کلمات فیلتر شده است")]
        SmsContentFilteredWordsIsIncluded = 7,

        [Description("اعتبار کافی نیست")]
        NoCredit = 8,

        [Description("سامانه در حال بروز رسانی است")]
        SystemBeingUpdated = 9,

        [Description("پیاده سازی نشده است")]
        NotImplemented = 10
    }
    public class SmsStatus
    {
        //private int _resultSending;  
        public string TranslateGetDeliveryResult(int deliveryStatus)
        {
            var result = string.Empty;
            switch (deliveryStatus)
            {
                case -5:
                    result = "براي گرفتن گزارش تحويل حداقل يک دقيقه بعد از ارسال اقدام نماييد";
                    break;
                case -4:
                    result = "به علت اينکه پيام در صف ارسال مخابرات مي باشد، امکان گرفتن گزارش تحويل وجود ندارد";
                    break;
                case -3:
                    result = "به علت اينکه مهلت يک هفته اي گرفتن گزارش پايان يافته است، امکان گرفتن گزارش تحويل  وجود ندارد";
                    break;
                case -2:
                    result = "پيام با اين کد وجود ندارد (SmsId نامعتبر است)";
                    break;
                case -1:
                    result = "خطا در ارتباط با سرويس دهنده";
                    break;
                case 0:
                    result = "ارسال شده به مخابرات";
                    break;
                case 1:
                    result = "رسيده به گوشي";
                    break;
                case 2:
                    result = "نرسيده به گوشي";
                    break;
                case 3:
                    result = "خطاي مخابراتي";
                    break;
                case 4:
                    result = "خطاي نامشخص";
                    break;
                case 5:
                    result = "رسيده به مخابرات";
                    break;
                case 6:
                    result = "نرسيده به مخابرات";
                    break;
                case 7:
                    result = "مسدود شده توسط مقصد";
                    break;
                case 8:
                    result = "نامشخص";
                    break;
                case 9:
                    result = "مخابرات پيام را مردود اعلام کرد";
                    break;
                case 10:
                    result = "کنسل شده توسط اپراتور";
                    break;
            }
            return result;
        }

    }
}
