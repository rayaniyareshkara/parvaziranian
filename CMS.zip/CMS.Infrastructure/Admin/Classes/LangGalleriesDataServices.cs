﻿using CMS.FrameWork.Statute.DBA;
using CMS.FrameWork.Model;
using System;
using System.Linq.Expressions;

namespace CMS.Infrastructure.Admin.Classes
{
    //public class LangGalleriesDataServices : ConversionMain<LangGalleries, int>, Interfaces.ILangGalleries
    //{
    //    public LangGalleriesDataServices(EntitysModelCMS Context) : base(Context)
    //    {
    //    }
    //    public override Expression<Func<LangGalleries, int>> GetKey()
    //    {
    //        return a => a.Id;
    //    }
    //}
}
