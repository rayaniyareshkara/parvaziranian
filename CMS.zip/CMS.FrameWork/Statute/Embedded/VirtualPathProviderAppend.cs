﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.Caching;
using System.Web.Hosting;
using CMS.FrameWork.Statute.Embedded.Repository;

namespace CMS.FrameWork.Statute.Embedded
{
    public class VirtualPathProviderAppend : VirtualPathProvider
    {
        private readonly IEnumerable<IViewProvider> _viewProviders;

        public VirtualPathProviderAppend(IEnumerable<IViewProvider> viewProviders)
        {
            if (viewProviders == null) throw new ArgumentNullException("viewProviders");

            _viewProviders = viewProviders;
        }

        private bool IsEmbeddedResourcePath(string virtualPath)
        {
            var returnValue = _viewProviders.Any(c => c.IsEmbeddedResourcePath(virtualPath));
            return returnValue;
        }

        public override bool FileExists(string virtualPath)
        {
            var returnValue = IsEmbeddedResourcePath(virtualPath) || base.FileExists(virtualPath);
            return returnValue;
        }

        public override VirtualFile GetFile(string virtualPath)
        {
            var viewProvider = _viewProviders.FirstOrDefault(c => c.IsEmbeddedResourcePath(virtualPath));
            var foundProvider = viewProvider != null;
            var returnValue = foundProvider
                ? new VirtualFileAppend(virtualPath, viewProvider)
                : base.GetFile(virtualPath);

            return returnValue;
        }

        public override CacheDependency GetCacheDependency(string virtualPath, IEnumerable virtualPathDependencies, DateTime utcStart)
        {
            var returnValue = IsEmbeddedResourcePath(virtualPath)
                ? null
                : base.GetCacheDependency(virtualPath, virtualPathDependencies, utcStart);
            return returnValue;
        }
    }
}
