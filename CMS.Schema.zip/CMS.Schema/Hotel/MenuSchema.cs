﻿
using System;

namespace CMS.Schema.Hotel
{
   public  class MenuSchema
    {
        public Guid Id { get; set; }
        public Guid? ParentId { get; set; }
        public string Title { get; set; }
        public string Link { get; set; }
        
    }
}
