﻿namespace CMS.Schema.Hall
{
    public class HallServeTypeSchema
    {
        public int Id { get; set; }
        public int? TypeId { get; set; }
        public int HallId { get; set; }
        public string Title { get; set; }
        public int ServeId { get; set; }
    }
}
