﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalCustomize.Article
{
    public class LocationBookCrud
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد")]
        [DisplayName("عنوان")]
        public string Caption { get; set; }
        [DisplayName("فعال/غیرفعال")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public bool Status { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [DisplayName("تعداد")]
        public int Count { get; set; }
        [DisplayName("نمایشگاه")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int ExhibitionId { get; set; }
    }

    public class LocationPosterCrud
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(100, ErrorMessage = "{0} طول نمی تواند بیشتر از 100 حروف باشد")]
        [DisplayName("عنوان")]
        public string Caption { get; set; }
        [DisplayName("فعال/غیرفعال")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public bool Status { get; set; }
        [DisplayName("نمایشگاه")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int ExhibitionId { get; set; }
    }
}
