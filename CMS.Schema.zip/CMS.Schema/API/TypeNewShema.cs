﻿

namespace CMS.Schema.API
{
    public class TypeNewShema
    {
        public string Id { get; set; }
        public string ParentId { get; set; }
        public string Name { get; set; }
    }
}
