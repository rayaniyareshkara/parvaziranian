﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class SetPasswordViewModel
    {
        [Required]
        [StringLength(100, ErrorMessage = @"{0}نیار به حداعقل {2}حرف دارد ", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "رمز جدید")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = @"تکرار رمز جدید")]
        [Compare("NewPassword", ErrorMessage = @"رمز جدید و تکرار رمز جدید یکسان نیست")]
        public string ConfirmPassword { get; set; }
    }

}
