﻿
namespace CMS.Schema.Mohandesan
{
    public class MapSchema 
    {
        public int Id { get; set; }
        public string Phone { get; set; }
        public string FullName { get; set; }
        public string File { get; set; }
        public string ResponseFile { get; set; }
        public string ResponseText { get; set; }
        public bool IsFinished { get; set; }
        public bool IsProcess { get; set; }
        public string Description { get; set; }
    }
}
