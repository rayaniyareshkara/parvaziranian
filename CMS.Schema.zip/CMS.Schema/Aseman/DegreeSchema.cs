﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class DegreeSchema
    {
        public int Id { get; set; }

        public string Title { get; set; }
        public string Duration { get; set; }
        public string Image { get; set; }
        public string Viceo { get; set; }

        public string HeadLine { get; set; }
        public string prerequisite { get; set; }
        public string law { get; set; }
        public string Description { get; set; }
        public int DegreeMainID { get; set; }
       
        public int GalleryId { get; set; }
        public bool IsActive { get; set; }
        public string LanguageId { get; set; }
        public List<CourseList> CourseList { get; set; }
        public string Price { get; set; }

    }

    public class CourseList
    {
      
        public int CourceId { get; set; }

    }
}
