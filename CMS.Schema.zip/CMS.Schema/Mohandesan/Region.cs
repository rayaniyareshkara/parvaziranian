﻿

namespace CMS.Schema.Mohandesan
{
    public class Region
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
