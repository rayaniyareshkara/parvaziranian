﻿namespace CMS.Schema.Hotel
{
    public class JsonResultAjax
    {
        public JsonResultAjax(string status)
        {
            this.status = status;
        }

        public JsonResultAjax(string status, object data)
        {
            this.data = data;
            this.status = status;
        }

        public JsonResultAjax(string status, object data, string error) : this(status, data)
        {
            this.error = error;
        }

        public string status { get; set; }
        public object data { get; set; }
        public string error { get; set; }
    }
}
