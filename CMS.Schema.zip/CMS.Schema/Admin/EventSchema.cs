﻿

using System;

namespace CMS.Schema.Admin
{
    public class EventSchema
    {
        public EventSchema()
        {
            Category = new CategorySchema();
        }
        public int Id { get; set; }
        public string Header { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
        public string Body { get; set; }
        public string Keys { get; set; }
        public string Author { get; set; }
        public DateTime Date { get; set; }
        public CategorySchema Category { get; set; }
        public string Title { get; set; }
    }
}
