﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Admin.Interfaces;

namespace CMS.Infrastructure.Admin.Classes
{
    public class ImageGalleryDataServices : ConversionMain<ImageGallery, int>, IImageGallery
    {
        public ImageGalleryDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<ImageGallery, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
