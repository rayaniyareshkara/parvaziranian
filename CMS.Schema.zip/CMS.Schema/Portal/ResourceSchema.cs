﻿
namespace CMS.Schema.Portal
{
    public class ResourceSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Suffix { get; set; }
    }
}
