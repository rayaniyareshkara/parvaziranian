﻿
using System;

namespace CMS.Schema.Mohandesan
{

    public class LawFirmInFields
    {
        public string Id { get; set; }
        public bool IsExperiment { get; set; }
        public bool IsImplementation { get; set; }
        public bool IsConsultant { get; set; }
        public int Field { get; set; }
        public int Grade { get; set; }
        public int TerendId { get; set; }
        public int? orientation { get; set; }
        public bool? IsDesign { get; set; }
    }

    public class Fields
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Code { get; set; }

        public bool? IsDesign { get; set; }
    }



    public class LawFirmFieldsSchema
    {
        public int Id { get; set; }
        public int Grade { get; set; }
    }
}
