﻿using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA.Repository;

namespace CMS.Infrastructure.Aseman.Interfaces
{
  public  interface IBranchClass : IRule<BranchClass, int>
    {
    }
}
