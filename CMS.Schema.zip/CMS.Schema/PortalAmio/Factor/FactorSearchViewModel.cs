﻿namespace CMS.Schema.PortalAmio.Factor
{
    public class FactorSearchViewModel
    {
        public int? InvoiceNumber { get; set; }

        public string UserName { get; set; }

        public int? Type { get; set; }

        public bool? Approve { get; set; }

        public int? ExhibitionId { get; set; }
    }
}
