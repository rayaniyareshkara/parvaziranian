﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class StudentListSchema
    {
        public Guid UserId { get; set; }
        public int? StudentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
