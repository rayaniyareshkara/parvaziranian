﻿//side-bar
$(".sidebar-dropdown > a").click(function () {
    $(".sidebar-submenu").slideUp(200);
    if (
        $(this)
            .parent()
            .hasClass("active")
    ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
            .parent()
            .removeClass("active");
    } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
            .next(".sidebar-submenu")
            .slideDown(200);
        $(this)
            .parent()
            .addClass("active");
    }
});

$("#close-sidebar").click(function () {
    $(".page-admin").removeClass("toggled");
});
$("#show-sidebar").click(function () {
    $(".page-admin").addClass("toggled");
});


$('#min-sidebar').click(function () {
    $(".sidebar-admin").toggleClass("active");
    $(".page-content").toggleClass("active");
});
        //end-side-bar


$("select#user_type_select").change(function () {
    var selectedcompany = $(this).children("option:selected").val();
    if (selectedcompany == 'company') {
        $('.form-company').show();
        $('.form-parson').hide();
    } else if
        (selectedcompany == 'person') {
        $('.form-company').hide();
        $('.form-person').show();
    } else {
        $('.form-company').removeClass("show");
        $('.form-parson').removeClass("show");
    }
});




//add-row-for-socials
$(document).ready(function () {
    var i = 1;
    $("#add_row").click(function () {
        $('#addr' + i).html("<td><select  name='name0' placeholder='Name' class='form-control'><option>تلگرام</option><option>اینستاگرام</option><option> واتس آپ</option><option> لینکدین</option></select> </td><td > <input name='mobile" + i + "' type='text' placeholder='لینک' class='form-control input-md'></td>");

        $('#tab_logic').append('<tr id="addr' + (i + 1) + '"></tr>');
        i++;
    });
    $("#delete_row").click(function () {
        if (i > 1) {
            $("#addr" + (i - 1)).html('');
            i--;
        }
    });

});
        //end
        


        //add-row
        $(".jDeleteRow").click(function () {
            var rowCount = $(this).closest('table').find('tbody').length;
            if (rowCount > 1) {
                $(this).closest('tbody').remove();
            }
        });

        $(".jAddRow").click(function () {
            var lastRow = $(this).closest('table').find('tbody').last();
            var newRow = lastRow.clone(true, true); //use true to copy event bindings with rows.  Doesn't always work with 3rd party plugins.
            newRow.find('input').val('');
            newRow.find('.jDeleteRow').removeAttr("disabled");
            newRow.insertAfter(lastRow);
        });

        //end
          //add-card-p
     
   //add-row-for-card
        $(document).ready(function () {
            var i = 1;
            $("#add_row-card").click(function () {


                $('#userCard' + i).html("<td>" + (i + 1) + "</td><td><select  name='name0' placeholder='sex' class='form-control'><option>خانم</option><option>آقا</option></select></td><td><input type='text' name='NameFamily" + i + "' placeholder='نام و نام خانوادگی' class='form-control'></td><td><input type='text' name='position" + i + "' placeholder='سمت' class='form-control'></td><td><input type='text' name='code" + i + "' placeholder='کد' class='form-control'></td>");
                    $('#tab_logic-card').append('<tr id="userCard' + (i + 1) + '"></tr>');
                i++;
            });
            $("#delete_row-card").click(function () {
                if (i > 1) {
                    $("#userCard" + (i - 1)).html('');
                    i--;
                }
            });

        });
        //end

    //add-row-for-parking
        $(document).ready(function () {
            var i = 1;
            $("#add_row-parking").click(function () {


                $('#parkingCard' + i).html("<td>" + (i + 1) + "</td></td><td><input type='text' name='plak" + i + "' placeholder='پلاک خودرو' class='form-control'></td><td><input type='text' name='type" + i + "' placeholder='نوع خودرو' class='form-control'></td>");
                    $('#tab_logic-parking').append('<tr id="parkingCard' + (i + 1) + '"></tr>');
                i++;
            });
            $("#delete_row-parking").click(function () {
                if (i > 1) {
                    $("#parkingCard" + (i - 1)).html('');
                    i--;
                }
            });

        });
        //end                           
    //       custom-file

                  
            updateList = function () {
            	var input = document.getElementsByClassName('file-multi');
            	var output = document.getElementsByClassName('fileList-multi');
            	var children = "";
            	for (var i = 0; i < input.files.length; ++i) {
            		//children += '<li>' + input.files.item(i).name + '<span class="remove-list" onclick="return this.parentNode.remove()">X</span>' + '</li>'
            	children += input.files.item(i).name;
            	}
            	//output.innerHTML = children;
            	$(".fileList-multi").attr("value", children);
            	$(".fileList-multi").attr("title", children);
            	
            }
  

        //timer-part

        (function init() {
  function getTimeRemaining(endtime) {
    var t = Date.parse(endtime) - Date.parse(new Date());
    var seconds = Math.floor((t / 1000) % 60);
    var minutes = Math.floor((t / 1000 / 60) % 60);
    var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
    var days = Math.floor(t / (1000 * 60 * 60 * 24));
    return {
      'total': t,
      'days': days,
      'hours': hours,
      'minutes': minutes,
    
    };
  }
  
  function initializeClock(endtime){
  var timeinterval = setInterval(function(){
    var t = getTimeRemaining(endtime);
    document.querySelector(".days > .value").innerText=t.days;
    document.querySelector(".hours > .value").innerText=t.hours;
    document.querySelector(".minutes > .value").innerText=t.minutes;
    if(t.total<=0){
      clearInterval(timeinterval);
    }
  },1000);
}
initializeClock(((new Date()).getFullYear()+1) + "/1/1")
})()











