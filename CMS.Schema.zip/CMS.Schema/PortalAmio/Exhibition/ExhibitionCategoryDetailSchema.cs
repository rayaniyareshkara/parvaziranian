﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
 public  class ExhibitionCategoryDetailSchema
    {
        public int Id { get; set; }

        public string Title { get; set; }
        public string Description { get; set; }
        public string ImgFile { get; set; }
        public DateTime Createdate { get; set; }  
        public int Priority { get; set; }
        public string ExhibitionCategoryTitle{ get; set; }

    }
}
