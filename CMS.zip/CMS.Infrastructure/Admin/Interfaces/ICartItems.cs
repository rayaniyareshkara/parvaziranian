﻿using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA.Repository;


namespace CMS.Infrastructure.Admin.Interfaces
{
    public interface ICartItems : IRule<CartItem,int>
    {
    }
}
