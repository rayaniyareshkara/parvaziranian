﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Report
{
   public class UserInExhibitionSchema
    {
        public int Row { get; set; } 
        public DateTime? CreateDateSource { get; set; }       
        public String CreateDate { get; set; }
        public string Name { get; set; }
        public String Dmanager { get; set; }
        public Guid UserId { get; set; }
        public int SumMetter { get; set; }
        public string AgentName { get; set; }
        public string DmanagerMobile { get; set; }
        public string AgentMobile { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Address { get; set; }
        public string Register { get; set; }
        public string RegisterClass { get; set; }
        public string Locating { get; set; }
        public string LocatingClass { get; set; }
        public string Financial { get; set; }
        public string FinancialClass { get; set; }
        public string Card { get; set; }
        public string CardClass { get; set; }

        public byte?  Status { get; set; }
        public string FaCompanyName { get; set; }
        public int? OpenPlaceRequestReal { get; set; }
        public int? SaloonPlaceRequestReal { get; set; }
        public int? OpenPlaceRequestDollar { get; set; }
        public int? SaloonPlaceRequestDollar { get; set; }


    }
}
