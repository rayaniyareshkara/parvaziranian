﻿using CMS.FrameWork.Model;
using CMS.Schema.Admin;
using System.Collections.Generic;
using Language = CMS.FrameWork.Model.Language;


namespace CMS.Schema.Portal
{
    public class FooterViewModel
    {
        public List<Language> LstLanguage { get; set; }
        public List<Footer> LstFooter { get; set; }

        public List<CMS.FrameWork.Model.FooterType> LstFooterType { get; set; }
    }
  
}