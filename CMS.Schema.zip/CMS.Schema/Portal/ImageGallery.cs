﻿using System;

namespace CMS.Schema.Portal
{
    public class ImageGallery
    {
        public Guid Id { get; set; }
        public string Images { get; set; }
        public string Name { get; set; }
    }
}
