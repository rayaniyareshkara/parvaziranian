﻿

namespace CMS.Schema.Hall
{
    public class PropertySchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int FeatureId { get; set; }
        public string Description { get; set; }
        public bool IsMain { get; set; }
    }
}
