﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
  public  class SliderSchema
    {
        public int Id { get; set; }
       
        public string Title { get; set; }
        public string Description { get; set; }
    
    }
}
