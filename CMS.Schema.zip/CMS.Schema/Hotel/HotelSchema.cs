﻿
using System;
using System.Collections.Generic;

namespace CMS.Schema.Hotel
{
    public class HotelSchema : HotelNameSchema
    {
        public string Image { get; set; }
        public string Brief { get; set; }
        public string Icon { get; set; }
        public string Address { get; set; }
        public string PhoneReserve { get; set; }
        public DateTime Date { get; set; }
        public string Keys { get; set; }
        

    }

    public class HotelNameSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class HotelStaffSchema : HotelNameSchema
    {
        public string Image { get; set; }
        public string Description { get; set; }
        public string Brief { get; set; }
        public string MetaName { get; set; }
        public string MetaDesc { get; set; }
        public string MetaKeyword { get; set; }
        public string Icon { get; set; }
        public string Fax { get; set; }
        public string Agent { get; set; }
        public string VacherDescription { get; set; }
        public string Address { get; set; }
        public string PhoneReserve { get; set; }
        public List<string> Features  { get; set; }
        public string RulesLink { get; set; }
    }
}
