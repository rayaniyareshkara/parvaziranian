﻿namespace CMS.Schema.Sms
{
    /// <summary>
    /// if(Value==1)
    /// {
    /// ارسال نشده است Sms
    /// }
    /// if(Value==2)
    /// {
    /// Sms ارسال شده است و به مقصد رسیده است
    /// }
    /// if(value==3)
    /// {
    /// Sms  ارسال شده است و به مقصد نرسیده است
    /// }
    /// </summary>
    public enum EnumStatusSmsInfo : byte
    {
        NotSent = 1,
        Sent = 2,
        NotDelivered = 3
    }

}
