﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
   public class CourseTimeStudentSchowSchema
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public int StatusId { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string StudentStatus { get; set; }
        public string StudentStatusId { get; set; }

    }
}
