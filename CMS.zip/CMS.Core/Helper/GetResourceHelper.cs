﻿using System;
using System.Globalization;
using System.Resources;
using System.Web.Mvc;

namespace CMS.Core.Helper
{
    public static class GetResourceHelper
    {
        public static string GetResource(this HtmlHelper helper, Type type, string key, string culture)
        {
            try
            {
                ResourceManager r = new ResourceManager(type);

                string result = r.GetString(key, new CultureInfo(culture));

                return result;
            }
            catch (Exception)
            {
                return "";
            }
        }
    }
}
