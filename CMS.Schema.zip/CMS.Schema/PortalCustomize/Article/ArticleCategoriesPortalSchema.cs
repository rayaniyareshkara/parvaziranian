﻿namespace CMS.Schema.PortalCustomize.Article
{
    public class ArticleCategoriesPortalSchema
    {
        public int Id { get; set; }

        public string Caption { get; set; }

        public string Active { get; set; }

        public string Lang { get; set; }

        public string Time { get; set; }
    }
}
