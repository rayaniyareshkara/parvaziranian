﻿
namespace CMS.Schema.Mohandesan
{
    public class SheetMetterShcema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsSheet { get; set; }
        public bool IsDesign { get; set; }
    }
}
