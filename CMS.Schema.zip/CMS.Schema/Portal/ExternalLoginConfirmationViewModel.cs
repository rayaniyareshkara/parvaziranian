﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required]
        [Display(Name = @"ایمیل")]
        public string Email { get; set; }
    }

}
