﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CMS.Schema.Portal
{
    public class EmailGroup
    {
        [Key]
        [ScaffoldColumn(false)]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int Id { get; set; }

        [Required(ErrorMessage = "نام گروه را انتخاب کنید")]
        [Display(Name = "نام گروه")]
        [DisplayName("نام گروه")]
        public string GroupName { get; set; }

        [Display(Name = "توضیحات")]
        [DisplayName("توضیحات")]
        public string Description { get; set; }
    }
}


