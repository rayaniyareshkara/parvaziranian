﻿
namespace CMS.Schema.Admin
{
    public class Resource
    {
        public string Description { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
