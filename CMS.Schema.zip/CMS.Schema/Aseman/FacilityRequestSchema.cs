﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
 public   class FacilityRequestSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public string NationalCode { get; set; }
        public DateTime? BirthDate { get; set; }
        public string Nationality { get; set; }
        public string BirthPlace { get; set; }
        public string PassportNumber { get; set; }
        public string PassportCountry { get; set; }
        public bool? Gender { get; set; }
        public string GenderName { get; set; }
        public string FatherName { get; set; }
        public string BirthCertificateNumber { get; set; }
        public string DegreeCode { get; set; }
        public int? DegreeId { get; set; }
        public string DegreeName { get; set; }
        public string Description { get; set; }
        public string FacilityName { get; set; }
        public int? FacilityId { get; set; }
        public string Status { get; set; }
        public int? StatusId { get; set; }
        public DateTime CreateDate { get; set; }


    }
}
