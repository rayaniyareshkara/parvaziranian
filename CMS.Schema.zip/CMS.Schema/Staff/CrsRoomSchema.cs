﻿namespace CMS.Schema.Staff
{
    public class CrsRoomSchema
    {
        public int id { get; set; }
        public string room_code { get; set; }
        public string title { get; set; }
        public int adult_capacity { get; set; }
        public int child_capacity { get; set; }
        public int extend_count { get; set; }
        public int extend_rate { get; set; }
        public int rate { get; set; }
        public int discount_rate { get; set; }
        public string link { get; set; }
        public string brief { get; set; }
        public bool is_active { get; set; }
        public int priority { get; set; }
        public string description { get; set; }
        public string size { get; set; }
        public int hotel_id { get; set; }
        public string room_type { get; set; }
        public string bed_size { get; set; }
        public string image { get; set; }
        /// <summary>
        /// for 7 years old baby 
        /// </summary>
        public int medium_baby_Rate { get; set; }

        /// <summary>
        /// for two years old baby
        /// </summary>
        public int small_bayby_rate { get; set; } // -- for 2 years old
    }
}
