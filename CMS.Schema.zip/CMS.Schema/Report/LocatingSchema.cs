﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Report
{
   public class LocatingSchema
    {
        public int Row { get; set; }
        public DateTime? CreateDateSource { get; set; }
        public String CreateDate { get; set; }
        public string FaCompanyName { get; set; }
        public string AgentName { get; set; }
        public string AgentMobile { get; set; }
        public int? OpenPlaceRequestReal { get; set; }
        public int? SaloonPlaceRequestReal { get; set; }
        public int? OpenPlaceRequestDollar { get; set; }
        public int? SaloonPlaceRequestDollar { get; set; }
        public string SaloonName { get; set; }
        public string StandName { get; set; }
        public string BildingModel { get; set; }
        public Guid UserId { get; set; }


    }
}
