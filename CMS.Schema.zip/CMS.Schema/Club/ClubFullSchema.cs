﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
  public  class ClubFullSchema
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImgFile { get; set; }
        public string description { get; set; }
        public string Conditions { get; set; }
        public bool SmsBirthday { get; set; }
        public bool EmailBirthday { get; set; }
        public bool SmsMarriage { get; set; }
        public bool EmailMarriage { get; set; }
        public bool IsActive { get; set; }
        public List<RulesSchema> Rules { get; set; } = new List<RulesSchema>();
        public List<AdvantageSchema> Advantage { get; set; } = new List<AdvantageSchema>();

    }
}
