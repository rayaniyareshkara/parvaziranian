﻿using System.Collections.Generic;

namespace CMS.Schema.Portal
{
    public class ListGroupEmailViewModel
    {
        public List<EmailGroup> lstEmailGroup = new List<EmailGroup>();
        public List<GroupMember_Email> lstGroupMember = new List<GroupMember_Email>();
    }
}