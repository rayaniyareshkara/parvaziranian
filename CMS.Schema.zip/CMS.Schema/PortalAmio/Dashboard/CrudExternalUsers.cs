﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;


namespace CMS.Schema.PortalAmio.Dashboard
{
    public class CrudExternalUsers
    {


        [Required(ErrorMessage = "{0} Is Necessary")]
        [StringLength(350, ErrorMessage = "{0} Length can not be more than 350 letters")]
        [DisplayName("CompanyName")]
        public string CompanyName { get; set; }
        [Required(ErrorMessage = "{0} Is Necessary")]
        [StringLength(350, ErrorMessage = "{0} Length can not be more than 350 letters")]
        [DisplayName("ContactPerson")]
        public string ContactPerson { get; set; }
        [Required(ErrorMessage = "{0} Is Necessary")]
        [StringLength(350, ErrorMessage = "{0} Length can not be more than 350 letters")]
        [DisplayName("WebSite")]
        public string WebSite { get; set; }
        [Required(ErrorMessage = "{0} Is Necessary")]
        [StringLength(150, ErrorMessage = "{0} Length can not be more than 150 letters")]
        [DisplayName("EmailId")]
        public string EmailId { get; set; }
        [Required(ErrorMessage = "{0} Is Necessary")]
        [StringLength(150, ErrorMessage = "{0} Length can not be more than 150 letters")]
        [DisplayName("StandSize")]
        public string StandSize { get; set; }
        [Required(ErrorMessage = "{0} Is Necessary")]
        [StringLength(150, ErrorMessage = "{0} Length can not be more than 150 letters")]
        [DisplayName("Country")]
        public string Country { get; set; }
        [Required(ErrorMessage = "{0} Is Necessary")]
        [StringLength(150, ErrorMessage = "{0} Length can not be more than 150 letters")]
        [DisplayName("RelatedPerson")]
        public string RelatedPerson { get; set; }
        [Required(ErrorMessage = "{0} Is Necessary")]
        [StringLength(150, ErrorMessage = "{0} Length can not be more than 150 letters")]
        [DisplayName("PhoneNumber")]
        public string PhoneNumber { get; set; }
        [StringLength(150, ErrorMessage = "{0} Length can not be more than 150 letters")]
        [DisplayName("SkypeId")]
        public string SkypeId { get; set; }
    }
}
