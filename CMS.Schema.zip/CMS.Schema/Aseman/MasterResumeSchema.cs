﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Aseman
{
  public  class MasterResumeSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string WorkPlace { get; set; }

        public string Image { get; set; }
        public string Description { get; set; }
        public int MasterId { get; set; }
        public string MasterName { get; set; }
        public string ResumeTypeName { get; set; }
        public int ResumeTypeId { get; set; }

    }
}
