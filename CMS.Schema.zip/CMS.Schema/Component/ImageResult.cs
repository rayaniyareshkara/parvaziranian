﻿using System;
using System.IO;

namespace CMS.Schema.Component
{
    public class ImageResult : IDisposable
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public Stream Stream { get; set; }

        public void Dispose()
        {
            Stream?.Close();
            Stream?.Dispose();
        }
    }
}
