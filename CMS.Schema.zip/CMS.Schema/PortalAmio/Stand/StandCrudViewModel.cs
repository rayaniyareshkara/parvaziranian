﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.PortalAmio.Stand
{
    public class StandCrudViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "{0} الزامی است")]
        [StringLength(200, ErrorMessage = "{0} طول نمی تواند بیشتر از 200 حروف باشد")]
        [DisplayName("عنوان")]
        public string Title { get; set; }
        [DisplayName("فعال/غیرفعال")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int? Status { get; set; }
        [DisplayName("زبان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int Lang { get; set; }
        [DisplayName("سالن ")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int HallId { get; set; }
        [DisplayName("پیش قیمت ")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int PreRegistrationPrice { get; set; }
        [DisplayName("متراژ غرفه")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int Area { get; set; }
        [DisplayName("استان")]
        [Required(ErrorMessage = "{0} الزامی است")]
        public int ProvinceId { get; set; }

        public int? PlaceId { get; set; }
    }
}
