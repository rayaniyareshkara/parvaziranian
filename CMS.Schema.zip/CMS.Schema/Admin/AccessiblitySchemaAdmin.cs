﻿
namespace CMS.Schema.Admin
{
    public class AccessiblitySchemaAdmin
    {
        public string Id { get; set; }
        public string ExpireDate { get; set; }
        public string PageCount { get; set; }
        public string CreateProfile { get; set; }
        public string Name { get; set; }
        public string IdUserAndRole { get; set; }
    }
}
