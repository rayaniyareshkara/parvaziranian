﻿using System;


namespace CMS.Schema.Exam
{
  public  class QuestionAddSchema
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string Code { get; set; }
        public string Image { get; set; }
        public string Video { get; set; }
        public string audio { get; set; }
        public int? CourseId { get; set; }
        public int TypeId { get; set; }
        public int HardshipId { get; set; }
        public int LanguageId { get; set; }
        public DateTime CreateDate { get; set; }
        public int OptionId1 { get; set; }
        public string Option1 { get; set; }
        public int OptionId2 { get; set; }
        public string Option2 { get; set; }
        public int OptionId3 { get; set; }
        public string Option3 { get; set; }
        public int OptionId4 { get; set; }
        public string Option4 { get; set; } 
        public decimal? Score { get; set; }
        public bool IsActive { get; set; }


    }
}
