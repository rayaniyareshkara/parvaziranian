﻿using System.Collections.Generic;

namespace CMS.Schema.Admin
{
    public class ChartUserShema
    {
        public int MaxValues { get; set; }

        public IDictionary<string, string> Data { get; set; }
        public int MinValues { get; set; }
    }
}
