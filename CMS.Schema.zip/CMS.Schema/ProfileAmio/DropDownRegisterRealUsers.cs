﻿namespace CMS.Schema.ProfileAmio
{
    public class DropDownRegisterRealUsers
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public bool? Selected { get; set; }
    }
}
