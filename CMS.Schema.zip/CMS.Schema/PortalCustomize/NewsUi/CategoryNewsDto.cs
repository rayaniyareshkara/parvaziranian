﻿namespace CMS.Schema.PortalCustomize.NewsUi
{
    public class CategoryNewsDto
    {
        public string Title { get; set; }

        public int Count { get; set; }

        public string Url { get; set; }
    }
}
