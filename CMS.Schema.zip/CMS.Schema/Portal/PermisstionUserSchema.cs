﻿using CMS.Schema.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Portal
{
    public class PermisstionUserSchema
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public bool? IsSelected { get; set; }

        public bool? IsDeleted { get; set; }

        public bool? IsInserted { get; set; }

        public bool? IsUpdated { get; set; }

        public int? PageId { get; set; }
        public string PageName { get; set; }
    }

    public static class GlobalPermission
    {
        public static string UpdateKey = Guid.NewGuid().ToString();
    }
    public class SessionPermissionSchema
    {
        public List<UserPermissions> permissions { get; set; } = new List<UserPermissions>();

        public string UpdateKey { get; set; }

    }
    public class UserPermissions
    {
        public UserPermissions()
        {
        }

        public UserPermissions(string pageCode, PermissonEnum type)
        {
            PageCode = pageCode;
            Type = type;
        }

        public string PageCode { get; set; }
        public PermissonEnum Type { get; set; }
    }
}
