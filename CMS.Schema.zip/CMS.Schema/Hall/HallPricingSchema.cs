﻿

namespace CMS.Schema.Hall
{
    public class HallPricingSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int? Price { get; set; }
    }
}
