﻿namespace CMS.Schema.PortalAmio.Dashboard
{
    public class LogMessageSchema
    {
        public int Id { get; set; }

        public string Message { get; set; }
    }
}
