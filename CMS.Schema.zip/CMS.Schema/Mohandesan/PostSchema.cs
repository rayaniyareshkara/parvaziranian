﻿
using System;

namespace CMS.Schema.Mohandesan
{
    public class PostSchema
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string MetaKeyword { get; set; }
        public string Brief { get; set; }
        public string Image { get; set; }
        public string MetaDescriptin { get; set; }
        public int CountView { get; set; }
        public string MetaTitle { get; set; }
        public string Link { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
