﻿namespace CMS.Schema.Hall
{
    public class CeremonySchema
    {
        public int Id { get; set; }
        public bool IsMain { get; set; }
        public string Title { get; set; }
        public bool IsActive  { get; set; }
        public int HotelId { get; set; }
    }
}
