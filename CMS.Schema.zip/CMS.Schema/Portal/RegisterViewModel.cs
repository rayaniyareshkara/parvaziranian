﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class RegisterViewModel
    {
        [Required]
        [Display(Name = @"نام")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = @"نام خانوادگی")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = @"نام کاربری")]
        public string UserName { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = @"ایمیل")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = @"رمز عبور")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = @"تکرار رمز عبور")]
        [Compare("Password", ErrorMessage = @"رمز جدید و تکرار رمز جدید تکسان نیست")]
        public string ConfirmPassword { get; set; }
    }

}
