﻿
using System;

namespace CMS.Schema
{
    public class Coockie
    {
        public CoockieEnum BehinNewsaadCMS { get; set; }
        public string ActiveCode { get; set; }
        public bool RememberMe { get; set; }
        public Guid UserId { get; set; }
        public string UserName { get; set; }
    }
}
