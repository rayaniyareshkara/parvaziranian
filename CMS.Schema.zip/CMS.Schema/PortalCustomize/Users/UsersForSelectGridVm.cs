﻿using System;

namespace CMS.Schema.PortalCustomize.Users
{
    public class UsersForSelectGridVm
    {
        public Guid Id { get; set; }

        public string UserName { get; set; }

        public string Time { get; set; }

        public string Type { get; set; }

        public string Approve { get; set; }

        public string HeadquartersApproval { get; set; }

        public string Finished { get; set; }

        public string LastEdited { get; set; }

        public string Step { get; set; }

        public string CompanyName { get; set; }

        public string TypeRegister { get; set; }
    }

    public class ConfirmationOfSubmittedDocumentsForSelectGridVm
    {
        public int Id { get; set; }

        public string Step { get; set; }

        public string CompanyName { get; set; }

        public string TypeRegister { get; set; }

        public string Time { get; set; }

        public string Exhibition { get; set; }

        public string Approve { get; set; }
    }

    public class ExternalUsersGrid
    {
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string Time { get; set; }
        public string Approve { get; set; }
        public string Step { get; set; }

        public string LastEdited { get; set; }
        public string CompanyName { get; set; }
    }

    public class ExhibitionRequestGridVm
    {
        public int Id { get; set; }

        public string UserName { get; set; }

        public string Exhibition { get; set; }

        public string Status { get; set; }

        public string ApprovalIOfStaff { get; set; }

        public string HeadquartersApproval { get; set; }

        public string Time { get; set; }

        public string CompanyName { get; set; }


        public string TypeRegister { get; set; }

        public Guid UserId { get; set; }
    }

    public class UserGroupShowGrid
    {
        public int Id { get; set; }

        public string Group { get; set; }

        public string UserName { get; set; }
    }


    public class UserGroupCrud
    {
        public Guid UserId { get; set; }

        public int GroupId { get; set; }
    }

    public class ShowNotification
    {
        public string Type { get; set; }

        public string Sender { get; set; }

        public string CreationTime { get; set; }

        public string Status { get; set; }
    }

    public class InvoiceSettingViewModel
    { 
        public string Exhibition { get; set; }

        public int Id { get; set; }
    }

    public class ShowMonopoly
    {
        public int Id { get; set; }

        public string CompanyName { get; set; }

        public string Exhibition { get; set; }


    }

}
