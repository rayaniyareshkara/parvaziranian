﻿
using System.Collections.Generic;

namespace CMS.Schema.Mohandesan
{
    public class ExaminationSchema 
        
    {
        public int Id { get; set; }
        public string Image { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Grade { get; set; }
        public string Tel { get; set; }
        public List<LawfirmExaminationPricesSchema> Prices { get; set; }
    }

 
}
