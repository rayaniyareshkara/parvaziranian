﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CMS.FrameWork.Statute.DBA.Repository
{
    public interface IRule<TModel, TKey>
        where TModel : class
    {
        IQueryable<TModel> Select();
        Task<TModel> Save(TModel item, CancellationToken cancellationToken = default);

        Task<IList<TModel>> Save(IList<TModel> item);

        Task<TModel> Update(TModel item,params string[] properties);

        Task<TModel> UnChnagedUpdate(TModel item, params string[] Properties);

        Task<IList<TModel>> Update(IList<TModel> item, params string[] Properties);

        Task<IList<TModel>> UnChnagedUpdate(IList<TModel> item, params string[] Properties);

        Task Delete(TModel item);

        Task Delete(IList<TModel> item);

        TModel Get(TKey id);

        IQueryable<TModel> Table { get; }
    }
}
