﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using CMS.Core.Helper;

namespace CMS.Core.Component
{
    public static class ConvertDateTime
    {
        private static string[] nights = new string[]
        {
            "شب اول",
           "شب دوم",
           "شب سوم",
           "شب چهارم",
           "شب پنجم",
           "شب ششم",
           "شب هفتم",
           "شب هشتم",
           "شب نهم",
           "شب دهم",
           "شب یازدهم",
           "شب دوازدهم",
            "شب سیزدهم",
            "شب چهاردهم",
            "شب پانزدهم",
            "شب شانزدهم",
            "شب هفدهم",
            "شب هجدهم",
            "شب نوزدهم",
            "شب بیستم",
            "شب بیست و یکم",
            "شب بیست و دوم",
            "شب بیست و سوم",
            "شب بیست و چهارم",
            "شب بیست و پنجم",
            "شب بیست و ششم",
            "شب بیست و هفتم",
            "شب بیست و هشتم",
            "شب بیست و نهم",
            "شب سی ام",
            "شب سی و یکم",
            "شب سی و دوم"
       };


        private static string[] DaysList = new string[]
        {
            "error",
            "یکم",
            "دوم",
            "سوم",
            "چهارم",
            "پنجم",
            "ششم",
            "هفتم",
            "هشتم",
            "نهم",
            "دهم",
            "یازدهم",
            "دوازدهم",
            "سیزدهم",
            "چهاردهم",
            "پانزدهم",
            "شانزدهم",
            "هفدهم",
            "هجدهم",
            "نوزدهم",
            "بیستم",
            "بیست و یکم",
            "بیست و دوم",
            "بیست و سوم",
            "بیست و چهارم",
            "بیست و پنجم",
            "بیست و ششم",
            "بیست و هفتم",
            "بیست و هشتم",
            "بیست و نهم",
            "سی ام",
            "سی و یکم",
        };
        public enum YearNumberList
        {
            [Display(Name = "هزاروچهارصد")]
            ThisYear = 1400,
            [Display(Name = "هزاروچهارصد ویک")]
            NextYear = 1401,
            [Display(Name = "هزاروچهارصد ودو")]
            TwoYearsLater = 1402,

        }
        public static string GetYears(this DateTime time)
        {
            var persian = GregorianToPersian(time);

            var year = persian.Split('/')[0];

            return year.EnglishToPersianNumber();
        }
        public static int GetYearsInt(this DateTime time)
        {
            var persian = GregorianToPersian(time);

            var year = persian.Split('/')[0];

            return int.Parse(year);
        }
        public static string GetYearName(this DateTime time)
        {
            var persian = GregorianToPersian(time);

            var year = persian.Split('/')[0];

            var enumValue = (YearNumberList)Enum.Parse(typeof(ConvertDateTime.YearNumberList), year);

            var result = EnumHelper<YearNumberList>.GetDisplayValue(enumValue);

            return result;
        }
        public static string GetDaysName(this DateTime time)
        {
            var persian = GregorianToPersian(time);

            var days = int.Parse(persian.Split('/')[2]);

            return DaysList[days];

        }

        public static string GetDays(this DateTime time)
        {
            var persian = GregorianToPersian(time);

            var days = int.Parse(persian.Split('/')[2]);

            return days.EnglishToPersianNumber();
        }


        public static string GetNightName(this int night)
        {
            try
            {
                return nights[night];
            }
            catch (Exception)
            {
                return night + " ام ";
            }

        }
        public static PersianDayOfWeek PersionDayOfWeek(this DateTime date)
        {
            switch (date.DayOfWeek)
            {
                case DayOfWeek.Saturday:
                    return PersianDayOfWeek.Shanbe;
                case DayOfWeek.Sunday:
                    return PersianDayOfWeek.Yekshanbe;
                case DayOfWeek.Monday:
                    return PersianDayOfWeek.Doshanbe;
                case DayOfWeek.Tuesday:
                    return PersianDayOfWeek.Seshanbe;
                case DayOfWeek.Wednesday:
                    return PersianDayOfWeek.Charshanbe;
                case DayOfWeek.Thursday:
                    return PersianDayOfWeek.Panjshanbe;
                case DayOfWeek.Friday:
                    return PersianDayOfWeek.Jome;
                default:
                    throw new Exception();
            }
        }

        public static string PersionDayOfWeekAsString(this DateTime date)
        {
            switch (date.DayOfWeek)
            {
                case DayOfWeek.Saturday:
                    return "شنبه";
                case DayOfWeek.Sunday:
                    return "یک شنبه";
                case DayOfWeek.Monday:
                    return "دوشنبه";
                case DayOfWeek.Tuesday:
                    return "سه شنبه";
                case DayOfWeek.Wednesday:
                    return "چهار شنبه";
                case DayOfWeek.Thursday:
                    return "پنج شنبه";
                case DayOfWeek.Friday:
                    return "جمعه";
                default:
                    throw new Exception();
            }
        }

        public enum PersianDayOfWeek
        {
            Shanbe = 1,
            Yekshanbe = 2,
            Doshanbe = 3,
            Seshanbe = 4,
            Charshanbe = 5,
            Panjshanbe = 6,
            Jome = 7
        }

        public static DateTime PersianToGregorian(string persian)
        {
            persian = persian.Replace('-', '/');
            string[] str = persian.Split(new char[] { '/' });

            PersianCalendar pc = new PersianCalendar();
            DateTime dt = new DateTime();
            try
            {
                dt = pc.ToDateTime(Convert.ToInt32(str[2]), Convert.ToInt32(str[1]),
                    Convert.ToInt32(str[0]), 0, 0, 0, 0);
            }
            catch (Exception )
            {
                dt = pc.ToDateTime(Convert.ToInt32(str[0]), Convert.ToInt32(str[1]),
                    Convert.ToInt32(str[2]), 0, 0, 0, 0);
            }
            return dt;
        }

        public static DateTime? PersianToGregorianNullable(string persian)
        {
            if (string.IsNullOrEmpty(persian))
                return null;
            string[] str = persian.Split(new char[] { '/' });

            PersianCalendar pc = new PersianCalendar();
            DateTime dt = new DateTime();
            try
            {
                dt = pc.ToDateTime(Convert.ToInt32(str[2]), Convert.ToInt32(str[1]), Convert.ToInt32(str[0]), 0, 0, 0, 0);
            }
            catch (Exception)
            {
                dt = pc.ToDateTime(Convert.ToInt32(str[0]), Convert.ToInt32(str[1]), Convert.ToInt32(str[2]), 0, 0, 0, 0);
            }
            return dt;
        }


        public static string GregorianToPersian(this DateTime? dt)
        {
            try
            {
                if (dt is null || dt.Value.Year==1)
                {
                    return "";
                }
                else
                {
                    var pc = new PersianCalendar();
                    return pc.GetYear((DateTime)dt) + "/" + pc.GetMonth((DateTime)dt) + "/" +
                           pc.GetDayOfMonth((DateTime)dt);

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
          

        }

        public static DateTime PersianToGregorianNew(string date)
        {
            var time = new DateTime();
            if (date != null)
            {
                var sp = date.Split('/');
                var persianDate = new PersianCalendar();
                var day = int.Parse(sp[2]);
                var month = int.Parse(sp[1]);
                var year = int.Parse(sp[0]);

                time = persianDate.ToDateTime(year, month, day,
                    0, 0, 0, 0);


                return time;
            }
            else
            {
                return time;
            }
        }

        public static int GetSolarMonth(this DateTime time)
        {
            try
            {
                var pc = new PersianCalendar();

                var persianDate = new DateTime(pc.GetYear(time), pc.GetMonth(time), pc.GetDayOfMonth(time));

                return persianDate.Month;
            }
            catch (Exception)
            {

                return 0;
            }
        }


        public static double ConvertToUnixTimestamp(DateTime date)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            TimeSpan diff = date.ToUniversalTime() - origin;
            return Math.Floor(diff.TotalSeconds);
        }

        public static int PersionDayOfWeekNumber(this DateTime date)
        {
            switch (date.DayOfWeek)
            {
                case DayOfWeek.Saturday:
                    return 1;
                case DayOfWeek.Sunday:
                    return 2;
                case DayOfWeek.Monday:
                    return 3;
                case DayOfWeek.Tuesday:
                    return 4;
                case DayOfWeek.Wednesday:
                    return 5;
                case DayOfWeek.Thursday:
                    return 6;
                case DayOfWeek.Friday:
                    return 7;
                default:
                    throw new Exception();
            }
        }
    }


}
