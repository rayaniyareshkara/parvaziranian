﻿
namespace CMS.Schema.Hotel
{
    public class TenderFileSchema
    {
        public string Title { get; set; }

        public string File { get; set; }
        public int Id { get; set; }
    }
}
