﻿using System;
using System.Linq.Expressions;
using CMS.FrameWork.Model;
using CMS.FrameWork.Statute.DBA;
using CMS.Infrastructure.Aseman.Interfaces;

namespace CMS.Infrastructure.Aseman.Classes
{
 public   class MainCourseTermStudentDataServices : ConversionMain<MainCourseTermStudent, int>, IMainCourseTermStudent
    {
        public MainCourseTermStudentDataServices(EntitysModelCMS Context) : base(Context)
        {
        }

        public override Expression<Func<MainCourseTermStudent, int>> GetKey()
        {
            return a => a.Id;
        }
    }
}
