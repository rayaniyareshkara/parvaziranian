﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.PortalAmio.Exhibition
{
public    class ExhibitorCardSchema
    {
        public int Id { get; set; }
        public Guid UserId { get; set; }
        public string CompanyName{ get; set; }
        public string   Mobile{ get; set; }
        public string FullNameFa { get; set; }
        public string FullNameEn { get; set; }
        public int Status { get; set; }
        public string StatusStirng { get; set; }
        public string FileName { get; set; }
        public string Time { get; set; }
        public DateTime CreateDate { get; set; }

    }
}
