﻿namespace CMS.Schema.PortalAmio.ExhibitionUi
{
    public class ExhibitionGalleryDto
    {
        public string Title { get; set; }

        public string Image { get; set; }
    }
}
