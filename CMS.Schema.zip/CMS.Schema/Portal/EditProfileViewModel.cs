﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Portal
{
    public class EditProfileViewModel
    {
        [Required]
        [Display(Name = @"نام")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = @"نام خانوادگی")]
        public string lastName { get; set; }
    }

}
