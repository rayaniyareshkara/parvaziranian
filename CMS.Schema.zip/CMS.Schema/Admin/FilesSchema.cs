﻿
namespace CMS.Schema.Admin
{
    public class FilesSchema
    {
        public int Id { get; set; }
        public string Mime { get; set; }
        public string NewName { get; set; }
        public string OriginalName { get; set; }
        public int? Type { get; set; }
    }
}
