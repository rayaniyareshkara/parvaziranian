﻿
namespace CMS.Schema.Hotel
{
    public class TimeServices
    {
        public  int Id { get; set; }
        public string To { get; set; }
        public string From { get; set; }
        
    }
}
