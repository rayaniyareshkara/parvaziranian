﻿
namespace CMS.Schema.Mohandesan
{
    public class UserTypeGradeSchema
    {
        public int Id { get; set; }
        public string Grade { get; set; }
        public int Capacity  { get; set; }
    }
}
