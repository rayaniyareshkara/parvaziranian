﻿
using System.Web.Mvc;

namespace CMS.Schema.API
{
    public class EmailShema
    {
        public string Email { get; set; }

        [AllowHtml]
        public string Message { get; set; }

        public string Subject { get; set; }
    }
    public class EmailMultipleShema
    {
        public int GroupId { get; set; }
        public string Subject { get; set; }

        [AllowHtml]
        public string Message { get; set; }
    }
}
