﻿


using System;

namespace CMS.Schema.Hotel
{
    public class HomaCart 
    {
        public int ProductId { get; set; }
        public int Type { get; set; }
        public int Count { get; set; }
        public int Price { get; set; }
        public string Desc { get; set; }
        public string Image { get; set; }
        public string Title { get; set; }
        public string Hotel { get; set; }
        public DateTime? Date { get; set; }

        public string PersianDate { get; set; }
        public string Time { get; set; }

    }
}
