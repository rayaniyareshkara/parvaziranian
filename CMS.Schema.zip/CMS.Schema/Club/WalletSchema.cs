﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Schema.Club
{
   public class WalletSchema
    {
        public List<WalletCoinSchema> Coins { get; set; } = new List<WalletCoinSchema>();
        public int balance { get; set; }
        public int Credit { get; set; }
    }
}
