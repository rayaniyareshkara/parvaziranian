﻿using System.ComponentModel.DataAnnotations;

namespace CMS.Schema.Enum
{
    public enum TypeOfPaymentEnum : byte
    {
        [Display(Name = "پرداخت نشد")]
        Unpaid = 1,
        [Display(Name = "پرداخت شده با چک")]
        PaidByCheck = 2,
        [Display(Name = "پرداخت آنلاین")]
        OnlinePayment = 3,
        [Display(Name = "پرداخت با فیش")]
        PaymentByReceipt = 4
    }
}
