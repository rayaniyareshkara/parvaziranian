﻿
namespace CMS.Schema.jsTree
{
    public class JsTreeNodeAAttributes
    {
        public string href { set; get; }
    }
}
